
-- Fix the trigger function to remove balance update since it's now auto-generated
CREATE OR REPLACE FUNCTION public.update_student_fees_on_payment()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  -- Update the student_fees record with new totals (balance auto-calculates)
  UPDATE student_fees 
  SET 
    total_paid = (
      SELECT COALESCE(SUM(amount), 0) 
      FROM fee_transactions 
      WHERE student_fee_id = NEW.student_fee_id 
      AND status = 'completed'
    ),
    payment_status = CASE 
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_fee_id = NEW.student_fee_id 
        AND status = 'completed'
      ) >= total_assigned_fees THEN 'Paid'
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_fee_id = NEW.student_fee_id 
        AND status = 'completed'
      ) > 0 THEN 'Partial'
      ELSE 'Unpaid'
    END,
    updated_at = NOW()
  WHERE id = NEW.student_fee_id;
  
  RETURN NEW;
END;
$function$
