
-- First, let's drop the existing check constraint that's causing the issue
ALTER TABLE fee_structures DROP CONSTRAINT IF EXISTS fee_structures_boarding_status_check;

-- Add a new check constraint that allows the values used by the application
ALTER TABLE fee_structures ADD CONSTRAINT fee_structures_boarding_status_check 
CHECK (boarding_status IN ('Day', 'Boarding', 'Both'));

-- Also ensure that RLS policies are properly set up for fee_structures
ALTER TABLE fee_structures ENABLE ROW LEVEL SECURITY;

-- Create RLS policies to allow all operations (since this seems to be a school management system)
CREATE POLICY "Allow all operations on fee_structures" ON fee_structures
FOR ALL USING (true) WITH CHECK (true);
