
-- First, let's check what columns exist and add missing ones to fee_structures
DO $$ 
BEGIN
    -- Add structure_group column if it doesn't exist
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'fee_structures' AND column_name = 'structure_group') THEN
        ALTER TABLE fee_structures ADD COLUMN structure_group TEXT;
    END IF;
    
    -- Add term column if it doesn't exist
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'fee_structures' AND column_name = 'term') THEN
        ALTER TABLE fee_structures ADD COLUMN term TEXT;
    END IF;
    
    -- Add year column if it doesn't exist
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'fee_structures' AND column_name = 'year') THEN
        ALTER TABLE fee_structures ADD COLUMN year TEXT;
    END IF;
    
    -- Add day_fee column if it doesn't exist
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'fee_structures' AND column_name = 'day_fee') THEN
        ALTER TABLE fee_structures ADD COLUMN day_fee NUMERIC DEFAULT 0;
    END IF;
    
    -- Add misc_fee column if it doesn't exist
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'fee_structures' AND column_name = 'misc_fee') THEN
        ALTER TABLE fee_structures ADD COLUMN misc_fee NUMERIC DEFAULT 0;
    END IF;
END $$;

-- Create class_fee_mappings table to map classes to structure groups
CREATE TABLE IF NOT EXISTS class_fee_mappings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class_name TEXT NOT NULL UNIQUE,
  structure_group TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create student_balances table to track student fee balances
CREATE TABLE IF NOT EXISTS student_balances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  fee_structure_id UUID NOT NULL REFERENCES fee_structures(id),
  term TEXT NOT NULL,
  year TEXT NOT NULL,
  total_required NUMERIC NOT NULL DEFAULT 0,
  total_paid NUMERIC NOT NULL DEFAULT 0,
  balance NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Prevent duplicate balance records for same student/term/year
  UNIQUE(student_id, term, year)
);

-- Create function to automatically calculate and assign fees when student is added
CREATE OR REPLACE FUNCTION auto_assign_student_fees()
RETURNS TRIGGER AS $$
DECLARE
  fee_structure_record fee_structures%ROWTYPE;
  class_mapping_record class_fee_mappings%ROWTYPE;
  current_term TEXT := 'Term 1'; -- You can modify this logic based on your academic calendar
  current_year TEXT := EXTRACT(YEAR FROM NOW())::TEXT;
  calculated_fee NUMERIC := 0;
BEGIN
  -- Find the structure group for the student's class
  SELECT * INTO class_mapping_record
  FROM class_fee_mappings
  WHERE class_name = NEW.class;
  
  -- If no mapping found, exit without creating balance record
  IF NOT FOUND THEN
    RAISE NOTICE 'No fee structure mapping found for class: %', NEW.class;
    RETURN NEW;
  END IF;
  
  -- Find the fee structure for current term/year and structure group
  SELECT * INTO fee_structure_record
  FROM fee_structures
  WHERE structure_group = class_mapping_record.structure_group
    AND term = current_term
    AND year = current_year;
  
  -- If no fee structure found, exit without creating balance record
  IF NOT FOUND THEN
    RAISE NOTICE 'No fee structure found for group: %, term: %, year: %', 
      class_mapping_record.structure_group, current_term, current_year;
    RETURN NEW;
  END IF;
  
  -- Calculate total fee based on student's status
  calculated_fee := COALESCE(fee_structure_record.day_fee, 0); -- Base fee (day student)
  
  -- Add boarding fee if student is a boarder
  IF NEW.boarding_status = 'Boarding' THEN
    calculated_fee := calculated_fee + COALESCE(fee_structure_record.boarding_fee, 0);
  END IF;
  
  -- Add transport fee if student uses transport
  IF NEW.transport = 'Yes' THEN
    calculated_fee := calculated_fee + COALESCE(fee_structure_record.transport_fee, 0);
  END IF;
  
  -- Add miscellaneous fees (always included)
  calculated_fee := calculated_fee + COALESCE(fee_structure_record.misc_fee, 0);
  
  -- Insert student balance record
  INSERT INTO student_balances (
    student_id,
    fee_structure_id,
    term,
    year,
    total_required,
    total_paid,
    balance
  ) VALUES (
    NEW.id,
    fee_structure_record.id,
    current_term,
    current_year,
    calculated_fee,
    0,
    calculated_fee
  )
  ON CONFLICT (student_id, term, year) 
  DO UPDATE SET
    fee_structure_id = fee_structure_record.id,
    total_required = calculated_fee,
    balance = calculated_fee - student_balances.total_paid,
    updated_at = NOW();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically assign fees when student is added or updated
DROP TRIGGER IF EXISTS trigger_auto_assign_fees ON students;
CREATE TRIGGER trigger_auto_assign_fees
  AFTER INSERT OR UPDATE OF class, boarding_status, transport ON students
  FOR EACH ROW
  EXECUTE FUNCTION auto_assign_student_fees();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_student_balances_student_id ON student_balances(student_id);
CREATE INDEX IF NOT EXISTS idx_student_balances_term_year ON student_balances(term, year);
CREATE INDEX IF NOT EXISTS idx_class_fee_mappings_class_name ON class_fee_mappings(class_name);

-- Add unique constraint after adding required columns
DO $$ 
BEGIN
    -- Only add constraint if all required columns exist
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'fee_structures' AND column_name = 'structure_group')
       AND EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'fee_structures' AND column_name = 'term')
       AND EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'fee_structures' AND column_name = 'year') THEN
        BEGIN
            ALTER TABLE fee_structures ADD CONSTRAINT unique_structure_term_year UNIQUE(structure_group, term, year);
        EXCEPTION
            WHEN duplicate_table THEN NULL; -- Constraint already exists
        END;
    END IF;
END $$;

-- Insert some sample fee structures and class mappings for testing (without total_fee since it's generated)
INSERT INTO fee_structures (structure_group, term, year, day_fee, boarding_fee, transport_fee, misc_fee, name, academic_year, academic_term) VALUES
('Primary Lower', 'Term 1', '2024', 400000, 200000, 50000, 25000, 'Primary Lower Structure', '2024', 'Term 1'),
('Primary Upper', 'Term 1', '2024', 500000, 250000, 50000, 30000, 'Primary Upper Structure', '2024', 'Term 1'),
('Secondary Lower', 'Term 1', '2024', 600000, 300000, 75000, 35000, 'Secondary Lower Structure', '2024', 'Term 1'),
('Secondary Upper', 'Term 1', '2024', 700000, 350000, 75000, 40000, 'Secondary Upper Structure', '2024', 'Term 1')
ON CONFLICT (structure_group, term, year) DO NOTHING;

INSERT INTO class_fee_mappings (class_name, structure_group) VALUES
('Primary 1', 'Primary Lower'),
('Primary 2', 'Primary Lower'),
('Primary 3', 'Primary Lower'),
('Primary 4', 'Primary Upper'),
('Primary 5', 'Primary Upper'),
('Primary 6', 'Primary Upper'),
('Primary 7', 'Primary Upper'),
('Secondary 1', 'Secondary Lower'),
('Secondary 2', 'Secondary Lower'),
('Secondary 3', 'Secondary Upper'),
('Secondary 4', 'Secondary Upper')
ON CONFLICT (class_name) DO NOTHING;
