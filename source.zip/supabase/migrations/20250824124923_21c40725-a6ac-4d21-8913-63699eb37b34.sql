
-- Create enum types for various settings
CREATE TYPE user_role_type AS ENUM ('owner', 'admin', 'teacher', 'student', 'parent');
CREATE TYPE attendance_policy_type AS ENUM ('strict', 'flexible', 'custom');
CREATE TYPE transport_status AS ENUM ('active', 'inactive', 'maintenance');
CREATE TYPE boarding_status AS ENUM ('day', 'boarding', 'mixed');

-- User roles table
CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  role user_role_type NOT NULL,
  permissions JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, role)
);

-- School profile table
CREATE TABLE IF NOT EXISTS public.school_profile (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  motto TEXT,
  email TEXT,
  phone TEXT,
  website TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  country TEXT,
  postal_code TEXT,
  logo_url TEXT,
  term_start_date DATE,
  term_end_date DATE,
  academic_year TEXT,
  current_term TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Communication preferences table
CREATE TABLE IF NOT EXISTS public.communication_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email_provider TEXT DEFAULT 'smtp',
  email_config JSONB DEFAULT '{}',
  sms_provider TEXT DEFAULT 'twilio',
  sms_config JSONB DEFAULT '{}',
  notification_frequency TEXT DEFAULT 'daily',
  notification_categories JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Attendance policies table
CREATE TABLE IF NOT EXISTS public.attendance_policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  policy_type attendance_policy_type DEFAULT 'flexible',
  late_threshold_minutes INTEGER DEFAULT 15,
  absent_threshold_minutes INTEGER DEFAULT 60,
  auto_mark_absent BOOLEAN DEFAULT true,
  require_reason BOOLEAN DEFAULT false,
  notification_settings JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Transport management table
CREATE TABLE IF NOT EXISTS public.transport_vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_number TEXT NOT NULL,
  driver_name TEXT,
  driver_phone TEXT,
  route_name TEXT,
  capacity INTEGER,
  status transport_status DEFAULT 'active',
  maintenance_schedule JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Transport routes table
CREATE TABLE IF NOT EXISTS public.transport_routes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_name TEXT NOT NULL,
  stops JSONB DEFAULT '[]',
  vehicle_id UUID REFERENCES transport_vehicles(id),
  schedule JSONB DEFAULT '{}',
  fee_amount NUMERIC DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Boarding facilities table
CREATE TABLE IF NOT EXISTS public.boarding_facilities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  facility_name TEXT NOT NULL,
  facility_type TEXT, -- dormitory, dining_hall, etc.
  capacity INTEGER,
  supervisor_name TEXT,
  supervisor_phone TEXT,
  rules JSONB DEFAULT '{}',
  fee_amount NUMERIC DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Security settings table
CREATE TABLE IF NOT EXISTS public.security_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  auto_logout_minutes INTEGER DEFAULT 30,
  password_policy JSONB DEFAULT '{"min_length": 8, "require_uppercase": true, "require_numbers": true}',
  two_factor_enabled BOOLEAN DEFAULT false,
  session_settings JSONB DEFAULT '{}',
  audit_logging BOOLEAN DEFAULT true,
  log_retention_days INTEGER DEFAULT 90,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- System backups table
CREATE TABLE IF NOT EXISTS public.system_backups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  backup_name TEXT NOT NULL,
  backup_type TEXT DEFAULT 'manual', -- manual, scheduled
  file_path TEXT,
  file_size BIGINT,
  status TEXT DEFAULT 'completed',
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

-- Customization themes table
CREATE TABLE IF NOT EXISTS public.customization_themes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  theme_name TEXT NOT NULL,
  primary_color TEXT,
  secondary_color TEXT,
  logo_url TEXT,
  custom_css TEXT,
  is_active BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.school_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.communication_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transport_vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transport_routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.boarding_facilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.security_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_backups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customization_themes ENABLE ROW LEVEL SECURITY;

-- Create RLS policies (allowing all operations for authenticated users for now)
CREATE POLICY "Allow all operations on user_roles" ON public.user_roles FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all operations on school_profile" ON public.school_profile FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all operations on communication_preferences" ON public.communication_preferences FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all operations on attendance_policies" ON public.attendance_policies FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all operations on transport_vehicles" ON public.transport_vehicles FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all operations on transport_routes" ON public.transport_routes FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all operations on boarding_facilities" ON public.boarding_facilities FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all operations on security_settings" ON public.security_settings FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all operations on system_backups" ON public.system_backups FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all operations on customization_themes" ON public.customization_themes FOR ALL TO authenticated USING (true);

-- Insert default records
INSERT INTO public.school_profile (name, academic_year, current_term) 
VALUES ('School Name', '2024', 'Term 1') 
ON CONFLICT DO NOTHING;

INSERT INTO public.communication_preferences DEFAULT VALUES ON CONFLICT DO NOTHING;
INSERT INTO public.attendance_policies DEFAULT VALUES ON CONFLICT DO NOTHING;
INSERT INTO public.security_settings DEFAULT VALUES ON CONFLICT DO NOTHING;

-- Create triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_user_roles_updated_at BEFORE UPDATE ON public.user_roles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_school_profile_updated_at BEFORE UPDATE ON public.school_profile FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_communication_preferences_updated_at BEFORE UPDATE ON public.communication_preferences FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_attendance_policies_updated_at BEFORE UPDATE ON public.attendance_policies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_transport_vehicles_updated_at BEFORE UPDATE ON public.transport_vehicles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_transport_routes_updated_at BEFORE UPDATE ON public.transport_routes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_boarding_facilities_updated_at BEFORE UPDATE ON public.boarding_facilities FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_security_settings_updated_at BEFORE UPDATE ON public.security_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_customization_themes_updated_at BEFORE UPDATE ON public.customization_themes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
