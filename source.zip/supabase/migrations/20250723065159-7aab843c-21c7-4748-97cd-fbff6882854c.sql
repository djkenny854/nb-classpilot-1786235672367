
-- Create inventory categories table
CREATE TABLE public.inventory_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create fees usage table for tracking item purchases paid using collected fees
CREATE TABLE public.fees_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  category TEXT NOT NULL,
  notes TEXT,
  inventory_item_id UUID REFERENCES inventory_items(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add new columns to existing inventory_items table
ALTER TABLE public.inventory_items 
ADD COLUMN IF NOT EXISTS category_id UUID REFERENCES inventory_categories(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS quantity INTEGER DEFAULT 1,
ADD COLUMN IF NOT EXISTS cost NUMERIC(10,2),
ADD COLUMN IF NOT EXISTS paid_from_fees BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS date_purchased DATE,
ADD COLUMN IF NOT EXISTS google_device_id TEXT,
ADD COLUMN IF NOT EXISTS enrollment_status TEXT DEFAULT 'not_enrolled';

-- Create indexes for better performance
CREATE INDEX idx_inventory_items_category_id ON inventory_items(category_id);
CREATE INDEX idx_inventory_items_paid_from_fees ON inventory_items(paid_from_fees);
CREATE INDEX idx_fees_usage_category ON fees_usage(category);
CREATE INDEX idx_fees_usage_date ON fees_usage(date);

-- Enable RLS on new tables
ALTER TABLE public.inventory_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fees_usage ENABLE ROW LEVEL SECURITY;

-- Create policies for inventory_categories
CREATE POLICY "Allow all operations on inventory_categories" ON public.inventory_categories FOR ALL TO public WITH CHECK (true);

-- Create policies for fees_usage
CREATE POLICY "Allow all operations on fees_usage" ON public.fees_usage FOR ALL TO public WITH CHECK (true);

-- Insert default inventory categories
INSERT INTO public.inventory_categories (name, description) VALUES
('Computers', 'Laptops, desktops, tablets, and computer accessories'),
('Furniture', 'Desks, chairs, tables, and classroom furniture'),
('Books', 'Textbooks, library books, and educational materials'),
('Printers', 'Printers, scanners, and printing equipment'),
('Projectors', 'Classroom projectors and presentation equipment'),
('Electronics', 'Electronic devices and equipment'),
('Sports Equipment', 'Sports gear and physical education equipment'),
('Lab Equipment', 'Science lab equipment and instruments'),
('Office Supplies', 'Stationery, paper, and office materials'),
('Vehicles', 'School vehicles and transportation equipment');

-- Create trigger to update updated_at timestamp for inventory_categories
CREATE TRIGGER update_inventory_categories_updated_at
    BEFORE UPDATE ON inventory_categories
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Create trigger to update updated_at timestamp for fees_usage
CREATE TRIGGER update_fees_usage_updated_at
    BEFORE UPDATE ON fees_usage
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Function to handle fee deduction when inventory item is paid from fees
CREATE OR REPLACE FUNCTION handle_fee_deduction()
RETURNS TRIGGER AS $$
BEGIN
  -- If item is paid from fees, create a fees_usage record
  IF NEW.paid_from_fees = TRUE AND NEW.cost > 0 THEN
    INSERT INTO fees_usage (
      title,
      amount,
      date,
      category,
      notes,
      inventory_item_id
    ) VALUES (
      'Purchase: ' || NEW.name,
      NEW.cost * NEW.quantity,
      COALESCE(NEW.date_purchased, CURRENT_DATE),
      'Inventory Purchase',
      'Item purchased using collected student fees',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for fee deduction
CREATE TRIGGER inventory_fee_deduction_trigger
    AFTER INSERT OR UPDATE ON inventory_items
    FOR EACH ROW
    WHEN (NEW.paid_from_fees = TRUE)
    EXECUTE FUNCTION handle_fee_deduction();
