-- Create assessment types enum
CREATE TYPE assessment_type AS ENUM ('exam', 'assignment', 'test', 'quiz', 'project', 'presentation', 'practical', 'homework', 'classwork', 'other');

-- Create assessment categories table
CREATE TABLE public.assessment_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  weight NUMERIC DEFAULT 1.0, -- For weighted averages
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create assessments table
CREATE TABLE public.assessments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  subject_id UUID REFERENCES enhanced_subjects(id),
  class_name TEXT NOT NULL,
  assessment_type assessment_type NOT NULL,
  category_id UUID REFERENCES assessment_categories(id),
  total_marks NUMERIC NOT NULL DEFAULT 100,
  due_date DATE,
  assessment_date DATE NOT NULL,
  is_published BOOLEAN DEFAULT false,
  instructions TEXT,
  created_by TEXT,
  academic_year TEXT NOT NULL,
  academic_term TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create assessment grades table
CREATE TABLE public.assessment_grades (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  assessment_id UUID NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  marks_obtained NUMERIC NOT NULL DEFAULT 0,
  percentage NUMERIC GENERATED ALWAYS AS (
    CASE 
      WHEN (SELECT total_marks FROM assessments WHERE id = assessment_id) > 0 
      THEN (marks_obtained / (SELECT total_marks FROM assessments WHERE id = assessment_id)) * 100
      ELSE 0 
    END
  ) STORED,
  grade TEXT,
  teacher_comment TEXT,
  submitted_at TIMESTAMP WITH TIME ZONE,
  graded_at TIMESTAMP WITH TIME ZONE,
  graded_by TEXT,
  is_absent BOOLEAN DEFAULT false,
  late_submission BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(assessment_id, student_id)
);

-- Create continuous assessment summary table
CREATE TABLE public.student_assessment_summary (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES enhanced_subjects(id) ON DELETE CASCADE,
  class_name TEXT NOT NULL,
  academic_year TEXT NOT NULL,
  academic_term TEXT NOT NULL,
  total_assessments INTEGER DEFAULT 0,
  completed_assessments INTEGER DEFAULT 0,
  average_percentage NUMERIC DEFAULT 0,
  current_grade TEXT,
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(student_id, subject_id, academic_year, academic_term)
);

-- Enable RLS
ALTER TABLE public.assessment_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assessment_grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_assessment_summary ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Allow all operations on assessment_categories" ON public.assessment_categories FOR ALL USING (true);
CREATE POLICY "Allow all operations on assessments" ON public.assessments FOR ALL USING (true);
CREATE POLICY "Allow all operations on assessment_grades" ON public.assessment_grades FOR ALL USING (true);
CREATE POLICY "Allow all operations on student_assessment_summary" ON public.student_assessment_summary FOR ALL USING (true);

-- Create update triggers
CREATE TRIGGER update_assessment_categories_updated_at
    BEFORE UPDATE ON public.assessment_categories
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_assessments_updated_at
    BEFORE UPDATE ON public.assessments
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_assessment_grades_updated_at
    BEFORE UPDATE ON public.assessment_grades
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_student_assessment_summary_updated_at
    BEFORE UPDATE ON public.student_assessment_summary
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default assessment categories
INSERT INTO public.assessment_categories (name, description, weight) VALUES
  ('Continuous Assessment', 'Regular assessments throughout the term', 0.4),
  ('Mid-term Exams', 'Mid-term examinations', 0.3),
  ('Final Exams', 'End of term examinations', 0.3),
  ('Projects', 'Long-term projects and assignments', 0.2),
  ('Participation', 'Class participation and engagement', 0.1);

-- Create function to auto-calculate student assessment summary
CREATE OR REPLACE FUNCTION update_student_assessment_summary()
RETURNS TRIGGER AS $$
BEGIN
  -- Update or insert summary for the affected student/subject/term
  INSERT INTO student_assessment_summary (
    student_id,
    subject_id,
    class_name,
    academic_year,
    academic_term,
    total_assessments,
    completed_assessments,
    average_percentage,
    current_grade,
    last_updated
  )
  SELECT 
    ag.student_id,
    a.subject_id,
    a.class_name,
    a.academic_year,
    a.academic_term,
    COUNT(*) as total_assessments,
    COUNT(CASE WHEN ag.marks_obtained IS NOT NULL AND NOT ag.is_absent THEN 1 END) as completed_assessments,
    COALESCE(AVG(CASE WHEN NOT ag.is_absent THEN ag.percentage END), 0) as average_percentage,
    CASE 
      WHEN AVG(CASE WHEN NOT ag.is_absent THEN ag.percentage END) >= 80 THEN 'A'
      WHEN AVG(CASE WHEN NOT ag.is_absent THEN ag.percentage END) >= 70 THEN 'B'
      WHEN AVG(CASE WHEN NOT ag.is_absent THEN ag.percentage END) >= 60 THEN 'C'
      WHEN AVG(CASE WHEN NOT ag.is_absent THEN ag.percentage END) >= 50 THEN 'D'
      ELSE 'F'
    END as current_grade,
    NOW() as last_updated
  FROM assessment_grades ag
  JOIN assessments a ON ag.assessment_id = a.id
  WHERE ag.student_id = COALESCE(NEW.student_id, OLD.student_id)
    AND a.subject_id = (SELECT subject_id FROM assessments WHERE id = COALESCE(NEW.assessment_id, OLD.assessment_id))
    AND a.academic_year = (SELECT academic_year FROM assessments WHERE id = COALESCE(NEW.assessment_id, OLD.assessment_id))
    AND a.academic_term = (SELECT academic_term FROM assessments WHERE id = COALESCE(NEW.assessment_id, OLD.assessment_id))
  GROUP BY ag.student_id, a.subject_id, a.class_name, a.academic_year, a.academic_term
  ON CONFLICT (student_id, subject_id, academic_year, academic_term)
  DO UPDATE SET
    total_assessments = EXCLUDED.total_assessments,
    completed_assessments = EXCLUDED.completed_assessments,
    average_percentage = EXCLUDED.average_percentage,
    current_grade = EXCLUDED.current_grade,
    last_updated = EXCLUDED.last_updated,
    updated_at = NOW();

  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update summary when grades change
CREATE TRIGGER update_assessment_summary_trigger
  AFTER INSERT OR UPDATE OR DELETE ON assessment_grades
  FOR EACH ROW
  EXECUTE FUNCTION update_student_assessment_summary();