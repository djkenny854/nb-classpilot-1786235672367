
-- Add missing columns to student_fees table for better tracking
ALTER TABLE student_fees ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'Unpaid';

-- Add missing columns to fee_transactions for better tracking
ALTER TABLE fee_transactions ADD COLUMN IF NOT EXISTS transaction_type TEXT DEFAULT 'payment';
ALTER TABLE fee_transactions ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'completed';

-- Add trigger to automatically update student_fees when a payment is made
CREATE OR REPLACE FUNCTION update_student_fees_on_payment()
RETURNS TRIGGER AS $$
BEGIN
  -- Update the student_fees record with new totals
  UPDATE student_fees 
  SET 
    total_paid = (
      SELECT COALESCE(SUM(amount), 0) 
      FROM fee_transactions 
      WHERE student_fee_id = NEW.student_fee_id 
      AND status = 'completed'
    ),
    payment_status = CASE 
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_fee_id = NEW.student_fee_id 
        AND status = 'completed'
      ) >= total_assigned_fees THEN 'Paid'
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_fee_id = NEW.student_fee_id 
        AND status = 'completed'
      ) > 0 THEN 'Partial'
      ELSE 'Unpaid'
    END,
    balance = total_assigned_fees - (
      SELECT COALESCE(SUM(amount), 0) 
      FROM fee_transactions 
      WHERE student_fee_id = NEW.student_fee_id 
      AND status = 'completed'
    ),
    updated_at = NOW()
  WHERE id = NEW.student_fee_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS trigger_update_student_fees_on_payment ON fee_transactions;
CREATE TRIGGER trigger_update_student_fees_on_payment
  AFTER INSERT OR UPDATE ON fee_transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_student_fees_on_payment();

-- Add index for better performance
CREATE INDEX IF NOT EXISTS idx_fee_transactions_student_fee_id ON fee_transactions(student_fee_id);
CREATE INDEX IF NOT EXISTS idx_student_fees_student_id ON student_fees(student_id);
