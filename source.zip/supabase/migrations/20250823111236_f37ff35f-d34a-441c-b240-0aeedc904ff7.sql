
-- Create messaging tables for comprehensive communication system

-- Core messages table to store all outgoing messages
CREATE TABLE public.messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  channel TEXT NOT NULL CHECK (channel IN ('sms', 'email', 'whatsapp')),
  sender_id UUID REFERENCES auth.users(id),
  recipient_type TEXT NOT NULL CHECK (recipient_type IN ('individual', 'group', 'broadcast')),
  recipient_ids TEXT[] NOT NULL, -- Array of student/teacher IDs
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'delivered', 'failed', 'cancelled')),
  scheduled_at TIMESTAMP WITH TIME ZONE,
  sent_at TIMESTAMP WITH TIME ZONE,
  delivery_status JSONB DEFAULT '{}', -- Track individual recipient delivery status
  metadata JSONB DEFAULT '{}', -- Store channel-specific data
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Message templates for reusable content
CREATE TABLE public.message_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('fee_reminder', 'attendance_alert', 'exam_result', 'event_reminder', 'announcement', 'custom')),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  variables TEXT[] DEFAULT '{}', -- Available template variables like [STUDENT_NAME], [AMOUNT]
  channels TEXT[] NOT NULL, -- Which channels this template supports
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Communication preferences and provider settings
CREATE TABLE public.communication_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  setting_type TEXT NOT NULL CHECK (setting_type IN ('email_provider', 'sms_provider', 'whatsapp_config', 'general')),
  provider_name TEXT, -- e.g., 'sendgrid', 'twilio', 'whatsapp_business'
  configuration JSONB NOT NULL DEFAULT '{}', -- Store provider-specific settings
  is_active BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Message logs for tracking and analytics
CREATE TABLE public.message_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  message_id UUID REFERENCES public.messages(id) ON DELETE CASCADE,
  recipient_id TEXT NOT NULL, -- student/teacher ID
  recipient_contact TEXT NOT NULL, -- phone/email
  channel TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('queued', 'sent', 'delivered', 'failed', 'bounced')),
  provider_response JSONB DEFAULT '{}',
  delivery_time TIMESTAMP WITH TIME ZONE,
  error_message TEXT,
  cost_amount NUMERIC(10,4) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Contact groups for bulk messaging
CREATE TABLE public.contact_groups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  group_type TEXT NOT NULL CHECK (group_type IN ('class', 'custom', 'all_parents', 'all_teachers', 'fee_defaulters')),
  criteria JSONB DEFAULT '{}', -- Store dynamic group criteria
  member_ids TEXT[] DEFAULT '{}', -- Static member list for custom groups
  is_dynamic BOOLEAN DEFAULT false, -- Whether group membership is calculated dynamically
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Automated message triggers
CREATE TABLE public.message_triggers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  trigger_type TEXT NOT NULL CHECK (trigger_type IN ('fee_overdue', 'attendance_absent', 'exam_result', 'scheduled', 'event_reminder')),
  condition_criteria JSONB NOT NULL DEFAULT '{}', -- When to trigger
  template_id UUID REFERENCES public.message_templates(id),
  channels TEXT[] NOT NULL,
  target_groups TEXT[] DEFAULT '{}', -- Which groups to target
  is_active BOOLEAN DEFAULT true,
  last_triggered_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.communication_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_triggers ENABLE ROW LEVEL SECURITY;

-- Create RLS policies (allow all operations for now)
CREATE POLICY "Allow all operations on messages" ON public.messages FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on message_templates" ON public.message_templates FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on communication_settings" ON public.communication_settings FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on message_logs" ON public.message_logs FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on contact_groups" ON public.contact_groups FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on message_triggers" ON public.message_triggers FOR ALL USING (true) WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX idx_messages_status ON public.messages(status);
CREATE INDEX idx_messages_channel ON public.messages(channel);
CREATE INDEX idx_messages_scheduled_at ON public.messages(scheduled_at);
CREATE INDEX idx_message_logs_message_id ON public.message_logs(message_id);
CREATE INDEX idx_message_logs_status ON public.message_logs(status);
CREATE INDEX idx_message_logs_channel ON public.message_logs(channel);

-- Insert default message templates
INSERT INTO public.message_templates (name, category, title, content, variables, channels) VALUES
('Fee Reminder Basic', 'fee_reminder', 'Fee Payment Reminder', 'Dear [PARENT_NAME], this is a reminder that [STUDENT_NAME] has an outstanding fee balance of UGX [AMOUNT]. Please make payment at your earliest convenience. Thank you. - [SCHOOL_NAME]', ARRAY['PARENT_NAME', 'STUDENT_NAME', 'AMOUNT', 'SCHOOL_NAME'], ARRAY['sms', 'email', 'whatsapp']),
('Attendance Alert', 'attendance_alert', 'Student Absence Notification', 'Dear [PARENT_NAME], [STUDENT_NAME] was absent from school today ([DATE]). If this is unexpected, please contact the school office. - [SCHOOL_NAME]', ARRAY['PARENT_NAME', 'STUDENT_NAME', 'DATE', 'SCHOOL_NAME'], ARRAY['sms', 'whatsapp']),
('Fee Overdue Warning', 'fee_reminder', 'Urgent: Fee Payment Overdue', 'URGENT: Dear [PARENT_NAME], [STUDENT_NAME]''s school fees of UGX [AMOUNT] are now [DAYS_OVERDUE] days overdue. Please settle immediately to avoid any inconvenience. Contact: [CONTACT_NUMBER] - [SCHOOL_NAME]', ARRAY['PARENT_NAME', 'STUDENT_NAME', 'AMOUNT', 'DAYS_OVERDUE', 'CONTACT_NUMBER', 'SCHOOL_NAME'], ARRAY['sms', 'email', 'whatsapp']),
('Exam Results Available', 'exam_result', 'Exam Results Released', 'Dear [PARENT_NAME], [STUDENT_NAME]''s [EXAM_NAME] results are now available. Please log into the parent portal or contact the school to access the results. - [SCHOOL_NAME]', ARRAY['PARENT_NAME', 'STUDENT_NAME', 'EXAM_NAME', 'SCHOOL_NAME'], ARRAY['sms', 'email', 'whatsapp']),
('Event Reminder', 'event_reminder', 'Upcoming School Event', 'Dear [PARENT_NAME], reminder that [EVENT_NAME] is scheduled for [EVENT_DATE] at [EVENT_TIME]. [STUDENT_NAME] is expected to attend. For details, contact the school. - [SCHOOL_NAME]', ARRAY['PARENT_NAME', 'EVENT_NAME', 'EVENT_DATE', 'EVENT_TIME', 'STUDENT_NAME', 'SCHOOL_NAME'], ARRAY['sms', 'email', 'whatsapp']),
('Welcome New Student', 'announcement', 'Welcome to Our School', 'Dear [PARENT_NAME], welcome to [SCHOOL_NAME]! We are delighted to have [STUDENT_NAME] join us in [CLASS]. Orientation details will be shared soon. Contact us at [CONTACT_NUMBER] for any questions.', ARRAY['PARENT_NAME', 'SCHOOL_NAME', 'STUDENT_NAME', 'CLASS', 'CONTACT_NUMBER'], ARRAY['sms', 'email', 'whatsapp']);

-- Insert default contact groups
INSERT INTO public.contact_groups (name, description, group_type, is_dynamic) VALUES
('All Parents', 'All parents in the school', 'all_parents', true),
('All Teachers', 'All teaching staff', 'all_teachers', true),
('Fee Defaulters', 'Students with outstanding fee balances', 'fee_defaulters', true),
('Boarding Students Parents', 'Parents of boarding students', 'custom', true),
('Day Students Parents', 'Parents of day students', 'custom', true);

-- Insert default communication settings
INSERT INTO public.communication_settings (setting_type, provider_name, configuration, is_active) VALUES
('general', 'default', '{"school_name": "School Name", "contact_number": "+256700000000", "default_sender": "School"}', true),
('email_provider', 'sendgrid', '{"api_key": "", "sender_email": "", "sender_name": ""}', false),
('sms_provider', 'twilio', '{"account_sid": "", "auth_token": "", "from_number": ""}', false),
('whatsapp_config', 'whatsapp_business', '{"access_token": "", "phone_number_id": "", "webhook_verify_token": ""}', false);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_messages_updated_at BEFORE UPDATE ON public.messages FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_message_templates_updated_at BEFORE UPDATE ON public.message_templates FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_communication_settings_updated_at BEFORE UPDATE ON public.communication_settings FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_contact_groups_updated_at BEFORE UPDATE ON public.contact_groups FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_message_triggers_updated_at BEFORE UPDATE ON public.message_triggers FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
