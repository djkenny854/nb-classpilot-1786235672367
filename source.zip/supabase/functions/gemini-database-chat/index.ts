import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { message, conversationHistory } = await req.json();
    console.log('Gemini chat request:', message);

    const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
    if (!GEMINI_API_KEY) {
      throw new Error('GEMINI_API_KEY not configured');
    }

    // Initialize Supabase client to query database schema
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Build schema context with available tables
    const tableNames = [
      'students', 'teachers', 'classes', 'class_streams', 'attendance', 'attendance_records',
      'fee_structures', 'fee_transactions', 'student_fees', 'student_balances',
      'payments', 'exams', 'exam_results', 'assessments', 'assessment_grades',
      'enhanced_subjects', 'messages', 'message_queue', 'inventory_items',
      'staff_attendance', 'staff_leave_requests', 'payroll_records'
    ];

    // Define AI tools for database operations
    const tools = [
      {
        name: "query_students",
        description: "Query student information including enrollment, class, fees, and personal details",
        parameters: {
          type: "object",
          properties: {
            limit: { type: "number", description: "Number of records to return" },
            class_name: { type: "string", description: "Filter by specific class" },
            fee_status: { type: "string", description: "Filter by fee status (Paid/Partial/Unpaid)" }
          }
        }
      },
      {
        name: "query_fee_balances",
        description: "Check fee balances and payment status for students",
        parameters: {
          type: "object",
          properties: {
            student_id: { type: "string", description: "Specific student ID" },
            status: { type: "string", description: "Payment status filter" }
          }
        }
      },
      {
        name: "query_attendance",
        description: "Get attendance records and statistics",
        parameters: {
          type: "object",
          properties: {
            date: { type: "string", description: "Date to check (YYYY-MM-DD)" },
            class_name: { type: "string", description: "Filter by class" }
          }
        }
      },
      {
        name: "query_teachers",
        description: "Get teacher information, assignments, and salary details",
        parameters: {
          type: "object",
          properties: {
            limit: { type: "number", description: "Number of records to return" }
          }
        }
      },
      {
        name: "query_exam_results",
        description: "Retrieve exam results and student performance data",
        parameters: {
          type: "object",
          properties: {
            student_id: { type: "string", description: "Specific student ID" },
            exam_id: { type: "string", description: "Specific exam ID" }
          }
        }
      },
      {
        name: "get_statistics",
        description: "Get overall statistics about students, classes, fees, attendance",
        parameters: {
          type: "object",
          properties: {
            category: { type: "string", description: "Category: students, fees, attendance, classes" }
          }
        }
      }
    ];

    // Build schema context for Gemini
    let schemaContext = `You are an AI assistant with direct access to a ClassPilot school management database. You have tools to execute queries and perform operations.

Available Tables: ${tableNames.join(', ')}

When users ask questions, use the appropriate tool to fetch real data and provide accurate answers. You can:
- Query student information, enrollment, and demographics
- Check fee balances, payment history, and outstanding amounts
- Analyze attendance patterns and generate reports
- View exam results and student performance
- Access teacher information and payroll data
- Generate statistics and insights from the database

Always use tools to get real data rather than making assumptions.`;

    // Prepare messages for Gemini
    const messages = [
      {
        role: 'user',
        parts: [{ text: schemaContext }]
      },
      ...(conversationHistory || []).slice(-10).map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }]
      })),
      {
        role: 'user',
        parts: [{ text: message }]
      }
    ];

    console.log('Calling Gemini API with', messages.length, 'messages');

    // Call Gemini API with tool support
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: messages,
          tools: [{
            functionDeclarations: tools.map(tool => ({
              name: tool.name,
              description: tool.description,
              parameters: tool.parameters
            }))
          }],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 2048,
          },
          safetySettings: [
            {
              category: "HARM_CATEGORY_HARASSMENT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
              category: "HARM_CATEGORY_HATE_SPEECH",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
              category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
              category: "HARM_CATEGORY_DANGEROUS_CONTENT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            }
          ]
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Gemini API error:', response.status, errorText);
      
      // Handle quota exceeded error
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ 
            response: '⚠️ API quota exceeded. The free tier limit has been reached. Please wait a moment and try again, or upgrade your Gemini API plan at https://ai.google.dev/pricing for higher limits.'
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      throw new Error(`Gemini API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    console.log('Gemini API response received');

    // Handle tool calls
    const candidate = data.candidates?.[0];
    const functionCall = candidate?.content?.parts?.[0]?.functionCall;

    if (functionCall) {
      console.log('Tool call detected:', functionCall.name);
      let toolResult;

      try {
        switch (functionCall.name) {
          case 'query_students': {
            const { limit = 10, class_name, fee_status } = functionCall.args || {};
            let query = supabase.from('students').select('id, first_name, last_name, class, fee_status, boarding_status, transport').limit(limit);
            if (class_name) query = query.eq('class', class_name);
            if (fee_status) query = query.eq('fee_status', fee_status);
            const { data: students } = await query;
            toolResult = JSON.stringify(students || []);
            break;
          }
          case 'query_fee_balances': {
            const { student_id, status } = functionCall.args || {};
            let query = supabase.from('student_fees').select('*, students(first_name, last_name, class)');
            if (student_id) query = query.eq('student_id', student_id);
            if (status) query = query.eq('payment_status', status);
            const { data: fees } = await query.limit(20);
            toolResult = JSON.stringify(fees || []);
            break;
          }
          case 'query_attendance': {
            const { date, class_name } = functionCall.args || {};
            let query = supabase.from('attendance').select('*, students(first_name, last_name, class)').limit(50);
            if (date) query = query.eq('date', date);
            const { data: attendance } = await query;
            toolResult = JSON.stringify(attendance || []);
            break;
          }
          case 'query_teachers': {
            const { limit = 10 } = functionCall.args || {};
            const { data: teachers } = await supabase.from('teachers').select('*').limit(limit);
            toolResult = JSON.stringify(teachers || []);
            break;
          }
          case 'query_exam_results': {
            const { student_id, exam_id } = functionCall.args || {};
            let query = supabase.from('exam_results').select('*');
            if (student_id) query = query.eq('student_id', student_id);
            if (exam_id) query = query.eq('exam_id', exam_id);
            const { data: results } = await query.limit(20);
            toolResult = JSON.stringify(results || []);
            break;
          }
          case 'get_statistics': {
            const { category } = functionCall.args || {};
            const stats: Record<string, unknown> = {};
            if (category === 'students' || !category) {
              const { count: totalStudents } = await supabase.from('students').select('*', { count: 'exact', head: true });
              stats.total_students = totalStudents;
            }
            if (category === 'fees' || !category) {
              const { data: feeData } = await supabase.from('student_fees').select('total_assigned_fees, total_paid, balance');
              const totalAssigned = feeData?.reduce((sum, f) => sum + (f.total_assigned_fees || 0), 0) || 0;
              const totalPaid = feeData?.reduce((sum, f) => sum + (f.total_paid || 0), 0) || 0;
              stats.fees = { total_assigned: totalAssigned, total_paid: totalPaid, balance: totalAssigned - totalPaid };
            }
            toolResult = JSON.stringify(stats);
            break;
          }
          default:
            toolResult = JSON.stringify({ error: 'Unknown tool' });
        }

        // Make follow-up call with tool result
        const followUpResponse = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${GEMINI_API_KEY}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [
                ...messages,
                {
                  role: 'model',
                  parts: [{ functionCall }]
                },
                {
                  role: 'user',
                  parts: [{
                    functionResponse: {
                      name: functionCall.name,
                      response: { result: toolResult }
                    }
                  }]
                }
              ],
              generationConfig: {
                temperature: 0.7,
                topK: 40,
                topP: 0.95,
                maxOutputTokens: 2048,
              }
            })
          }
        );

        if (!followUpResponse.ok && followUpResponse.status === 429) {
          return new Response(
            JSON.stringify({ 
              response: '⚠️ API quota exceeded. The free tier limit has been reached. Please wait a moment and try again, or upgrade your Gemini API plan for higher limits.'
            }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const followUpData = await followUpResponse.json();
        const aiResponse = followUpData.candidates?.[0]?.content?.parts?.[0]?.text || 'I processed the data but could not generate a response.';
        
        return new Response(
          JSON.stringify({ response: aiResponse }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );

      } catch (toolError: any) {
        console.error('Tool execution error:', toolError);
        return new Response(
          JSON.stringify({ response: `I encountered an error accessing the database: ${toolError.message}` }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // No tool call - return direct text response
    const aiResponse = candidate?.content?.parts?.[0]?.text || 
                      'I apologize, but I could not generate a response. Please try again.';

    return new Response(
      JSON.stringify({ response: aiResponse }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );
  } catch (error: any) {
    console.error('Error in gemini-database-chat:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Internal server error',
        response: 'I encountered an error processing your request. Please try again.'
      }),
      { 
        status: 500,
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );
  }
});
