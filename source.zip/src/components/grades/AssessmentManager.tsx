import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Plus, Eye, Edit, Trash2, BookOpen } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { getAssessments, deleteAssessment } from '@/utils/gradingService';
import type { Assessment } from '@/types/grading';
import AssessmentDialog from './AssessmentDialog';

const AssessmentManager = () => {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAssessment, setSelectedAssessment] = useState<Assessment | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadAssessments();
  }, []);

  const loadAssessments = async () => {
    try {
      const data = await getAssessments({
        academic_year: '2024',
        academic_term: 'Term 1'
      });
      setAssessments(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load assessments",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this assessment?')) return;
    
    try {
      await deleteAssessment(id);
      setAssessments(prev => prev.filter(a => a.id !== id));
      toast({
        title: "Success",
        description: "Assessment deleted successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete assessment",
        variant: "destructive"
      });
    }
  };

  const getTypeColor = (type: string) => {
    const colors = {
      exam: 'bg-red-100 text-red-800',
      assignment: 'bg-blue-100 text-blue-800',
      test: 'bg-green-100 text-green-800',
      quiz: 'bg-yellow-100 text-yellow-800',
      project: 'bg-purple-100 text-purple-800',
      practical: 'bg-orange-100 text-orange-800'
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="h-3 bg-muted rounded w-1/2"></div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="h-3 bg-muted rounded"></div>
                <div className="h-3 bg-muted rounded w-2/3"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Assessment Management</h2>
          <p className="text-muted-foreground">Create and manage assessments for your classes</p>
        </div>
        <Button onClick={() => {
          setSelectedAssessment(null);
          setDialogOpen(true);
        }}>
          <Plus className="mr-2 h-4 w-4" />
          New Assessment
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {assessments.map((assessment) => (
          <Card key={assessment.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <CardTitle className="text-lg">{assessment.title}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge className={getTypeColor(assessment.assessment_type)}>
                      {assessment.assessment_type}
                    </Badge>
                    {assessment.is_published ? (
                      <Badge variant="outline">Published</Badge>
                    ) : (
                      <Badge variant="secondary">Draft</Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {new Date(assessment.assessment_date).toLocaleDateString()}
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <Clock className="h-4 w-4" />
                  Total Marks: {assessment.total_marks}
                </div>
              </div>
              
              <div className="text-sm">
                <p><strong>Subject:</strong> {assessment.subject_name || 'N/A'}</p>
                <p><strong>Class:</strong> {assessment.class_name}</p>
              </div>

              {assessment.description && (
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {assessment.description}
                </p>
              )}

              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedAssessment(assessment);
                    setDialogOpen(true);
                  }}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDelete(assessment.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {assessments.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No assessments found</h3>
            <p className="text-muted-foreground text-center mb-6 max-w-sm">
              Create your first assessment to start tracking student performance.
            </p>
            <Button onClick={() => {
              setSelectedAssessment(null);
              setDialogOpen(true);
            }}>
              <Plus className="mr-2 h-4 w-4" />
              Create Assessment
            </Button>
          </CardContent>
        </Card>
      )}

      <AssessmentDialog
        assessment={selectedAssessment}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSave={loadAssessments}
      />
    </div>
  );
};

export default AssessmentManager;