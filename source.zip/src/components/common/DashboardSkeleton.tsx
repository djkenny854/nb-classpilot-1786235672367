
import React from 'react';
import { Skeleton } from "@/components/ui/skeleton";
import MainLayout from '@/components/layout/MainLayout';

const DashboardSkeleton = () => {
  return (
    <MainLayout>
      <div className="space-y-8 p-6">
        {/* Header Skeleton */}
        <div className="animate-fade-in">
          <Skeleton className="h-10 w-64 mb-3" />
          <Skeleton className="h-6 w-96" />
        </div>

        {/* Enhanced Stats Cards Skeleton */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="border-0 shadow-soft bg-white/80 backdrop-blur-sm rounded-2xl p-8 animate-fade-in" style={{ animationDelay: `${i * 100}ms` }}>
              <div className="flex flex-row items-center justify-between pb-4 space-y-0">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-12 w-12 rounded-2xl" />
              </div>
              <div className="space-y-3">
                <Skeleton className="h-8 w-20" />
                <Skeleton className="h-4 w-32" />
                <div className="flex items-center gap-2 mt-4">
                  <Skeleton className="h-6 w-12 rounded-full" />
                  <Skeleton className="h-3 w-20" />
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Main Content Grid Skeleton */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Revenue Chart Skeleton */}
          <div className="lg:col-span-2 border-0 shadow-soft bg-white/80 backdrop-blur-sm rounded-2xl p-8">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-6 w-40" />
                  <Skeleton className="h-4 w-56" />
                </div>
                <Skeleton className="h-8 w-24 rounded-full" />
              </div>
              <Skeleton className="h-80 w-full rounded-lg" />
            </div>
          </div>
          
          {/* AI Insights Skeleton */}
          <div className="lg:col-span-1 border-0 shadow-soft bg-white/80 backdrop-blur-sm rounded-2xl p-8">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Skeleton className="h-5 w-5" />
                  <Skeleton className="h-5 w-24" />
                </div>
                <Skeleton className="h-6 w-20 rounded-full" />
              </div>
              {[...Array(4)].map((_, i) => (
                <div key={i} className="p-4 rounded-lg border bg-white/50 space-y-3">
                  <div className="flex items-start gap-3">
                    <Skeleton className="h-5 w-5 mt-0.5" />
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center justify-between">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-5 w-16 rounded-full" />
                      </div>
                      <Skeleton className="h-3 w-full" />
                      <Skeleton className="h-3 w-3/4" />
                      <Skeleton className="h-3 w-28" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Secondary Widgets Skeleton */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="border-0 shadow-soft bg-white/80 backdrop-blur-sm rounded-2xl p-6 animate-fade-in" style={{ animationDelay: `${i * 150}ms` }}>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Skeleton className="h-5 w-5" />
                    <Skeleton className="h-5 w-32" />
                  </div>
                  <Skeleton className="h-6 w-16 rounded-full" />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  {[...Array(3)].map((_, j) => (
                    <div key={j} className="text-center space-y-1">
                      <Skeleton className="h-6 w-8 mx-auto" />
                      <Skeleton className="h-3 w-12 mx-auto" />
                    </div>
                  ))}
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Skeleton className="h-3 w-20" />
                    <Skeleton className="h-3 w-8" />
                  </div>
                  <Skeleton className="h-2 w-full rounded-full" />
                </div>
                
                <div className="space-y-2">
                  <Skeleton className="h-4 w-32" />
                  {[...Array(3)].map((_, k) => (
                    <div key={k} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                      <Skeleton className="h-3 w-24" />
                      <Skeleton className="h-5 w-12 rounded-full" />
                    </div>
                  ))}
                </div>
                
                <Skeleton className="h-9 w-full rounded-lg" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </MainLayout>
  );
};

export default DashboardSkeleton;
