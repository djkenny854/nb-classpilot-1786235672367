import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, User, GraduationCap, BookOpen, Users } from 'lucide-react';
import SearchLoadingSkeleton from './SearchLoadingSkeleton';

const GlobalSearch = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (query.length > 2) {
      setIsLoading(true);
      // Simulate search delay
      const timer = setTimeout(() => {
        // Mock search results
        const mockResults = [
          { id: 1, type: 'student', name: 'John Doe', class: 'Grade 10A', avatar: null },
          { id: 2, type: 'teacher', name: 'Jane Smith', subject: 'Mathematics', avatar: null },
          { id: 3, type: 'class', name: 'Grade 10A', students: 25 },
          { id: 4, type: 'subject', name: 'Mathematics', classes: 5 },
        ].filter(item => 
          item.name.toLowerCase().includes(query.toLowerCase())
        );
        
        setResults(mockResults);
        setIsLoading(false);
        setIsOpen(true);
      }, 800);

      return () => clearTimeout(timer);
    } else {
      setResults([]);
      setIsOpen(false);
      setIsLoading(false);
    }
  }, [query]);

  const getIcon = (type: string) => {
    switch (type) {
      case 'student': return <User className="h-4 w-4" />;
      case 'teacher': return <GraduationCap className="h-4 w-4" />;
      case 'class': return <Users className="h-4 w-4" />;
      case 'subject': return <BookOpen className="h-4 w-4" />;
      default: return <Search className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'student': return 'bg-primary/10 text-primary dark:bg-primary/20';
      case 'teacher': return 'bg-green-500/10 text-green-600 dark:bg-green-500/20 dark:text-green-400';
      case 'class': return 'bg-purple-500/10 text-purple-600 dark:bg-purple-500/20 dark:text-purple-400';
      case 'subject': return 'bg-orange-500/10 text-orange-600 dark:bg-orange-500/20 dark:text-orange-400';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="relative w-full max-w-md">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-10 h-10 bg-secondary border-border rounded-full text-sm"
        />
      </div>

      {(isOpen || isLoading) && (
        <div className="absolute top-full left-0 right-0 bg-popover border border-border rounded-lg shadow-lg z-50 mt-1 max-h-96 overflow-y-auto">
          {isLoading ? (
            <SearchLoadingSkeleton />
          ) : results.length > 0 ? (
            <div className="p-2">
              <div className="text-sm text-muted-foreground mb-2 px-2">
                {results.length} result{results.length !== 1 ? 's' : ''} found
              </div>
              {results.map((result) => (
                <div
                  key={`${result.type}-${result.id}`}
                  className="flex items-center space-x-3 p-3 hover:bg-accent rounded-lg cursor-pointer transition-colors"
                  onClick={() => {
                    setIsOpen(false);
                    setQuery('');
                  }}
                >
                  <div className="flex-shrink-0">
                    {result.avatar ? (
                      <img src={result.avatar} alt="" className="h-8 w-8 rounded-full" />
                    ) : (
                      <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center text-muted-foreground">
                        {getIcon(result.type)}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">
                      {result.name}
                    </p>
                    <p className="text-sm text-muted-foreground truncate">
                      {result.type === 'student' && result.class}
                      {result.type === 'teacher' && result.subject}
                      {result.type === 'class' && `${result.students} students`}
                      {result.type === 'subject' && `${result.classes} classes`}
                    </p>
                  </div>
                  <Badge className={getTypeColor(result.type)}>
                    {result.type}
                  </Badge>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-muted-foreground">
              No results found for "{query}"
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default GlobalSearch;
