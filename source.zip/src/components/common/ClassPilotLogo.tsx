import React from 'react';
import { cn } from '@/lib/utils';
interface ClassPilotLogoProps {
  size?: number;
  className?: string;
  showText?: boolean;
}
const ClassPilotLogo: React.FC<ClassPilotLogoProps> = ({
  size = 40,
  className,
  showText = true
}) => {
  return <div className={cn("flex items-center gap-3", className)}>
      <div className="relative">
        
      </div>
      
      {showText}
    </div>;
};
export default ClassPilotLogo;