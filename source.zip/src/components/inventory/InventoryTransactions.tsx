
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Search, ArrowRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface InventoryTransaction {
  id: string;
  inventory_item_id: string;
  transaction_type: string;
  from_location: string;
  to_location: string;
  assigned_from: string;
  assigned_to: string;
  notes: string;
  transaction_date: string;
  performed_by: string;
  inventory_items: {
    name: string;
    category: string;
  };
}

const InventoryTransactions = () => {
  const [transactions, setTransactions] = useState<InventoryTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const { toast } = useToast();

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    try {
      const { data, error } = await supabase
        .from('inventory_transactions')
        .select(`
          *,
          inventory_items (
            name,
            category
          )
        `)
        .order('transaction_date', { ascending: false });

      if (error) throw error;
      setTransactions(data || []);
    } catch (error) {
      console.error('Error fetching transactions:', error);
      toast({
        title: "Error",
        description: "Failed to fetch inventory transactions",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'assignment': return 'bg-blue-100 text-blue-800';
      case 'return': return 'bg-green-100 text-green-800';
      case 'maintenance': return 'bg-yellow-100 text-yellow-800';
      case 'transfer': return 'bg-purple-100 text-purple-800';
      case 'disposal': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.inventory_items?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.notes?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.performed_by?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || transaction.transaction_type === typeFilter;
    
    return matchesSearch && matchesType;
  });

  if (loading) {
    return <div className="flex justify-center p-8">Loading transactions...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="assignment">Assignment</SelectItem>
              <SelectItem value="return">Return</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem>
              <SelectItem value="transfer">Transfer</SelectItem>
              <SelectItem value="disposal">Disposal</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-4">
        {filteredTransactions.map((transaction) => (
          <Card key={transaction.id}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">
                  {transaction.inventory_items?.name || 'Unknown Item'}
                </CardTitle>
                <Badge className={getTransactionTypeColor(transaction.transaction_type)}>
                  {transaction.transaction_type}
                </Badge>
              </div>
              <CardDescription>
                {new Date(transaction.transaction_date).toLocaleString()}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {(transaction.from_location || transaction.to_location) && (
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">Location:</span>
                  <span className="text-sm">{transaction.from_location || 'N/A'}</span>
                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{transaction.to_location || 'N/A'}</span>
                </div>
              )}

              {(transaction.assigned_from || transaction.assigned_to) && (
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">Assignment:</span>
                  <span className="text-sm">{transaction.assigned_from || 'N/A'}</span>
                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{transaction.assigned_to || 'N/A'}</span>
                </div>
              )}

              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">Performed by:</span>
                <span className="text-sm font-medium">{transaction.performed_by}</span>
              </div>

              {transaction.notes && (
                <div className="space-y-1">
                  <span className="text-sm text-muted-foreground">Notes:</span>
                  <p className="text-sm bg-gray-50 p-2 rounded">{transaction.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTransactions.length === 0 && (
        <div className="text-center py-8">
          <h3 className="text-lg font-medium text-muted-foreground">No transactions found</h3>
          <p className="text-muted-foreground">No inventory transactions match your current filters.</p>
        </div>
      )}
    </div>
  );
};

export default InventoryTransactions;
