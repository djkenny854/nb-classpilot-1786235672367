
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Monitor, AlertTriangle, Eye, Edit } from 'lucide-react';

interface InventoryItem {
  id: string;
  name: string;
  description?: string;
  category: string;
  quantity: number;
  cost?: number;
  paid_from_fees: boolean;
  condition: string;
  status: string;
  date_purchased?: string;
  google_device_id?: string;
  enrollment_status: string;
  category_id?: string;
  serial_number?: string;
  location?: string;
  assigned_to?: string;
  warranty_expiry?: string;
  notes?: string;
}

interface InventoryCardProps {
  item: InventoryItem;
  onEdit: (item: InventoryItem) => void;
  onEnroll: (item: InventoryItem) => void;
  onViewDetails: (item: InventoryItem) => void;
}

const InventoryCard: React.FC<InventoryCardProps> = ({ item, onEdit, onEnroll, onViewDetails }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-100 text-green-800';
      case 'in_use': return 'bg-blue-100 text-blue-800';
      case 'maintenance': return 'bg-yellow-100 text-yellow-800';
      case 'retired': return 'bg-gray-100 text-gray-800';
      case 'lost': return 'bg-red-100 text-red-800';
      case 'stolen': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'fair': return 'bg-yellow-100 text-yellow-800';
      case 'poor': return 'bg-orange-100 text-orange-800';
      case 'damaged': return 'bg-red-100 text-red-800';
      case 'obsolete': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const supportsGoogleEnrollment = (category: string) => {
    return ['Computers', 'Laptops', 'Tablets'].includes(category);
  };

  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer">
      <CardContent className="p-4">
        <div className="flex items-center justify-between space-x-4">
          {/* Item Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-2">
              <h3 className="font-semibold text-lg truncate">{item.name}</h3>
              <div className="flex items-center space-x-2 flex-shrink-0">
                {item.paid_from_fees && (
                  <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                    Fee Funded
                  </Badge>
                )}
                {supportsGoogleEnrollment(item.category) && (
                  <Monitor className="h-4 w-4 text-blue-600" />
                )}
              </div>
            </div>
            
            <p className="text-sm text-muted-foreground mb-2 line-clamp-1">
              {item.description || 'No description'}
            </p>
            
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-1">
                <span className="text-muted-foreground">Category:</span>
                <Badge variant="outline" className="capitalize">
                  {item.category.replace('_', ' ')}
                </Badge>
              </div>
              
              <div className="flex items-center space-x-1">
                <span className="text-muted-foreground">Qty:</span>
                <span className="font-medium">{item.quantity}</span>
              </div>
              
              <div className="flex items-center space-x-1">
                <span className="text-muted-foreground">Cost:</span>
                <span className="font-medium">UGX {(item.cost || 0).toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Status and Condition */}
          <div className="flex flex-col items-center space-y-2">
            <Badge className={getStatusColor(item.status)}>
              {item.status.replace('_', ' ')}
            </Badge>
            <Badge className={getConditionColor(item.condition)}>
              {item.condition}
            </Badge>
          </div>

          {/* Additional Info */}
          <div className="flex flex-col items-end space-y-1 text-sm min-w-0">
            {item.assigned_to && (
              <div className="flex items-center space-x-1">
                <span className="text-muted-foreground">Assigned:</span>
                <span className="font-medium truncate">{item.assigned_to}</span>
              </div>
            )}
            
            {item.location && (
              <div className="flex items-center space-x-1">
                <span className="text-muted-foreground">Location:</span>
                <span className="truncate">{item.location}</span>
              </div>
            )}
            
            {item.serial_number && (
              <div className="flex items-center space-x-1">
                <span className="text-muted-foreground">S/N:</span>
                <span className="font-mono text-xs">{item.serial_number}</span>
              </div>
            )}
            
            {item.google_device_id && (
              <div className="flex items-center space-x-1">
                <Monitor className="h-3 w-3 text-green-600" />
                <Badge className="bg-green-100 text-green-800 text-xs">
                  Enrolled
                </Badge>
              </div>
            )}
            
            {item.warranty_expiry && new Date(item.warranty_expiry) < new Date() && (
              <div className="flex items-center text-orange-600">
                <AlertTriangle className="h-3 w-3 mr-1" />
                <span className="text-xs">Warranty Expired</span>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex flex-col space-y-2 flex-shrink-0">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => onViewDetails(item)}
              className="w-full"
            >
              <Eye className="h-4 w-4 mr-1" />
              View
            </Button>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => onEdit(item)}
              className="w-full"
            >
              <Edit className="h-4 w-4 mr-1" />
              Edit
            </Button>
            
            {supportsGoogleEnrollment(item.category) && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => onEnroll(item)}
                className="w-full"
              >
                <Monitor className="h-4 w-4 mr-1" />
                Enroll
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default InventoryCard;
