
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, DollarSign, AlertTriangle, TrendingUp } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface InventoryStats {
  totalItems: number;
  totalValue: number;
  itemsByCategory: Record<string, number>;
  itemsByStatus: Record<string, number>;
  itemsByCondition: Record<string, number>;
  expiredWarranties: number;
  maintenanceRequired: number;
}

const InventoryReports = () => {
  const [stats, setStats] = useState<InventoryStats>({
    totalItems: 0,
    totalValue: 0,
    itemsByCategory: {},
    itemsByStatus: {},
    itemsByCondition: {},
    expiredWarranties: 0,
    maintenanceRequired: 0
  });
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { data: items, error } = await supabase
        .from('inventory_items')
        .select('*');

      if (error) throw error;

      const totalItems = items?.length || 0;
      const totalValue = items?.reduce((sum, item) => sum + (item.current_value || 0), 0) || 0;

      const itemsByCategory = items?.reduce((acc, item) => {
        acc[item.category] = (acc[item.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>) || {};

      const itemsByStatus = items?.reduce((acc, item) => {
        acc[item.status] = (acc[item.status] || 0) + 1;
        return acc;
      }, {} as Record<string, number>) || {};

      const itemsByCondition = items?.reduce((acc, item) => {
        acc[item.condition] = (acc[item.condition] || 0) + 1;
        return acc;
      }, {} as Record<string, number>) || {};

      const today = new Date();
      const expiredWarranties = items?.filter(item => 
        item.warranty_expiry && new Date(item.warranty_expiry) < today
      ).length || 0;

      const maintenanceRequired = items?.filter(item => 
        item.status === 'maintenance' || item.condition === 'poor' || item.condition === 'damaged'
      ).length || 0;

      setStats({
        totalItems,
        totalValue,
        itemsByCategory,
        itemsByStatus,
        itemsByCondition,
        expiredWarranties,
        maintenanceRequired
      });
    } catch (error) {
      console.error('Error fetching inventory stats:', error);
      toast({
        title: "Error",
        description: "Failed to fetch inventory statistics",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return `UGX ${amount.toLocaleString()}`;
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading reports...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Items</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalItems}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Value</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalValue)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expired Warranties</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.expiredWarranties}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Needs Maintenance</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.maintenanceRequired}</div>
          </CardContent>
        </Card>
      </div>

      {/* Category Breakdown */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Items by Category</CardTitle>
            <CardDescription>Distribution of inventory items by category</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(stats.itemsByCategory).map(([category, count]) => (
              <div key={category} className="flex justify-between items-center">
                <span className="text-sm capitalize">{category.replace('_', ' ')}</span>
                <Badge variant="outline">{count}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Items by Status</CardTitle>
            <CardDescription>Current status of all inventory items</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(stats.itemsByStatus).map(([status, count]) => (
              <div key={status} className="flex justify-between items-center">
                <span className="text-sm capitalize">{status.replace('_', ' ')}</span>
                <Badge variant="outline">{count}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Items by Condition</CardTitle>
            <CardDescription>Physical condition of inventory items</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(stats.itemsByCondition).map(([condition, count]) => (
              <div key={condition} className="flex justify-between items-center">
                <span className="text-sm capitalize">{condition}</span>
                <Badge variant="outline">{count}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InventoryReports;
