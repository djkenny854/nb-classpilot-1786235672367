
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Monitor, Shield, AlertCircle, CheckCircle, Clock, Globe, Settings, Link, RefreshCw } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface InventoryItem {
  id: string;
  name: string;
  description?: string;
  category: string;
  serial_number?: string;
  google_device_id?: string;
  enrollment_status: string;
}

interface GoogleDeviceEnrollmentProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: InventoryItem | null;
  onSuccess: () => void;
}

const GoogleDeviceEnrollment: React.FC<GoogleDeviceEnrollmentProps> = ({
  open,
  onOpenChange,
  item,
  onSuccess
}) => {
  const [deviceId, setDeviceId] = useState('');
  const [orgUnit, setOrgUnit] = useState('');
  const [loading, setLoading] = useState(false);
  const [enrollmentUrl, setEnrollmentUrl] = useState('');
  const [currentTab, setCurrentTab] = useState('manual');
  const { toast } = useToast();

  useEffect(() => {
    if (item) {
      setDeviceId(item.google_device_id || '');
      // Generate enrollment URL based on device info
      if (item.serial_number) {
        setEnrollmentUrl(`https://admin.google.com/ac/chrome/enrollment?serial=${item.serial_number}`);
      }
    }
  }, [item]);

  const handleManualEnrollment = async () => {
    if (!item) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('inventory_items')
        .update({
          google_device_id: deviceId,
          enrollment_status: 'enrolled'
        })
        .eq('id', item.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Device enrolled successfully with Google Admin"
      });

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error enrolling device:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to enroll device",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAutoEnrollment = async () => {
    if (!item) return;

    setLoading(true);
    try {
      // Set status to pending while enrollment is in progress
      const { error } = await supabase
        .from('inventory_items')
        .update({
          enrollment_status: 'pending'
        })
        .eq('id', item.id);

      if (error) throw error;

      toast({
        title: "Enrollment Started",
        description: "Device enrollment is in progress. Please complete the process in the Google Admin console."
      });

      onSuccess();
      
      // Simulate enrollment completion after 5 seconds (for demo)
      setTimeout(async () => {
        await supabase
          .from('inventory_items')
          .update({
            google_device_id: `auto-${Date.now()}`,
            enrollment_status: 'enrolled'
          })
          .eq('id', item.id);
        
        onSuccess();
      }, 5000);
      
    } catch (error: any) {
      console.error('Error starting enrollment:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to start enrollment",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUnenrollDevice = async () => {
    if (!item) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('inventory_items')
        .update({
          google_device_id: null,
          enrollment_status: 'not_enrolled'
        })
        .eq('id', item.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Device unenrolled successfully"
      });

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error unenrolling device:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to unenroll device",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const refreshEnrollmentStatus = async () => {
    if (!item) return;

    setLoading(true);
    try {
      // In a real implementation, this would check the Google Admin API
      // For now, we'll simulate a status refresh
      const { data, error } = await supabase
        .from('inventory_items')
        .select('enrollment_status, google_device_id')
        .eq('id', item.id)
        .single();

      if (error) throw error;

      toast({
        title: "Status Refreshed",
        description: `Current status: ${data.enrollment_status}`
      });

      onSuccess();
    } catch (error: any) {
      console.error('Error refreshing status:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to refresh status",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getEnrollmentStatusIcon = (status: string) => {
    switch (status) {
      case 'enrolled':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      case 'not_enrolled':
      default:
        return <AlertCircle className="h-5 w-5 text-gray-600" />;
    }
  };

  const getEnrollmentStatusColor = (status: string) => {
    switch (status) {
      case 'enrolled':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'not_enrolled':
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (!item) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Monitor className="h-5 w-5 mr-2" />
            Google Device Enrollment - {item.name}
          </DialogTitle>
          <DialogDescription>
            Manage Google Admin enrollment for this device
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Device Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Device Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Device Name</Label>
                  <p className="text-sm">{item.name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Category</Label>
                  <p className="text-sm">{item.category}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Serial Number</Label>
                  <p className="text-sm">{item.serial_number || 'Not provided'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Enrollment Status</Label>
                  <div className="flex items-center space-x-2">
                    {getEnrollmentStatusIcon(item.enrollment_status)}
                    <Badge className={getEnrollmentStatusColor(item.enrollment_status)}>
                      {item.enrollment_status.replace('_', ' ')}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={refreshEnrollmentStatus}
                      disabled={loading}
                    >
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Enrollment Methods */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Enrollment Methods</CardTitle>
              <CardDescription>
                Choose how you want to enroll this device with Google Admin
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={currentTab} onValueChange={setCurrentTab}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="manual">Manual Entry</TabsTrigger>
                  <TabsTrigger value="auto">Auto Enrollment</TabsTrigger>
                  <TabsTrigger value="console">Admin Console</TabsTrigger>
                </TabsList>

                <TabsContent value="manual" className="space-y-4">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="device_id">Google Device ID</Label>
                      <Input
                        id="device_id"
                        value={deviceId}
                        onChange={(e) => setDeviceId(e.target.value)}
                        placeholder="e.g., google-device-123456"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="org_unit">Organizational Unit (Optional)</Label>
                      <Input
                        id="org_unit"
                        value={orgUnit}
                        onChange={(e) => setOrgUnit(e.target.value)}
                        placeholder="e.g., /Students/Grade-6"
                      />
                    </div>

                    <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                      <div className="flex items-center">
                        <Settings className="h-4 w-4 text-blue-600 mr-2" />
                        <p className="text-sm text-blue-800">
                          Manually enter the device ID from Google Admin Console
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="auto" className="space-y-4">
                  <div className="space-y-4">
                    <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                      <div className="flex items-center">
                        <Globe className="h-4 w-4 text-green-600 mr-2" />
                        <p className="text-sm text-green-800">
                          Automatically enroll using Google Admin SDK (requires API setup)
                        </p>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Device Serial Number</Label>
                      <Input
                        value={item.serial_number || ''}
                        disabled
                        placeholder="Serial number required for auto enrollment"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="auto_org_unit">Target Organizational Unit</Label>
                      <Input
                        id="auto_org_unit"
                        value={orgUnit}
                        onChange={(e) => setOrgUnit(e.target.value)}
                        placeholder="e.g., /Students/Grade-6"
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="console" className="space-y-4">
                  <div className="space-y-4">
                    <div className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                      <div className="flex items-center">
                        <Link className="h-4 w-4 text-purple-600 mr-2" />
                        <p className="text-sm text-purple-800">
                          Use Google Admin Console directly for enrollment
                        </p>
                      </div>
                    </div>
                    
                    {item.serial_number && (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label>Direct Enrollment URL</Label>
                          <div className="flex space-x-2">
                            <Input
                              value={enrollmentUrl}
                              disabled
                              className="flex-1"
                            />
                            <Button
                              variant="outline"
                              onClick={() => window.open(enrollmentUrl, '_blank')}
                            >
                              Open
                            </Button>
                          </div>
                        </div>
                        
                        <div className="border rounded-lg p-4">
                          <h4 className="font-medium mb-2">Embedded Console</h4>
                          <div className="border rounded h-96 bg-gray-50 flex items-center justify-center">
                            <iframe
                              src={enrollmentUrl}
                              className="w-full h-full rounded"
                              title="Google Admin Console"
                              sandbox="allow-scripts allow-same-origin allow-forms"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Current Status */}
          {item.google_device_id && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Shield className="h-5 w-5 mr-2" />
                  Current Enrollment Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Device ID:</span>
                    <span className="text-sm font-mono">{item.google_device_id}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Status:</span>
                    <Badge className={getEnrollmentStatusColor(item.enrollment_status)}>
                      {item.enrollment_status.replace('_', ' ')}
                    </Badge>
                  </div>
                  
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <div className="flex items-center">
                      <Shield className="h-4 w-4 text-blue-600 mr-2" />
                      <p className="text-sm text-blue-800">
                        This device is enrolled and managed by Google Admin
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            
            {item.google_device_id ? (
              <Button 
                variant="destructive" 
                onClick={handleUnenrollDevice}
                disabled={loading}
              >
                {loading ? 'Unenrolling...' : 'Unenroll Device'}
              </Button>
            ) : (
              <>
                {currentTab === 'manual' && (
                  <Button 
                    onClick={handleManualEnrollment}
                    disabled={loading || !deviceId.trim()}
                  >
                    {loading ? 'Enrolling...' : 'Enroll Device'}
                  </Button>
                )}
                
                {currentTab === 'auto' && (
                  <Button 
                    onClick={handleAutoEnrollment}
                    disabled={loading || !item.serial_number}
                  >
                    {loading ? 'Starting...' : 'Auto Enroll'}
                  </Button>
                )}
                
                {currentTab === 'console' && (
                  <Button 
                    onClick={() => window.open(enrollmentUrl, '_blank')}
                    disabled={!item.serial_number}
                  >
                    Open Console
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default GoogleDeviceEnrollment;
