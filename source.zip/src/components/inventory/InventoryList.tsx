
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Search, Package } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import InventoryItemForm from './InventoryItemForm';
import GoogleDeviceEnrollment from './GoogleDeviceEnrollment';
import InventoryCard from './InventoryCard';
import InventoryItemDetails from './InventoryItemDetails';

interface InventoryItem {
  id: string;
  name: string;
  description?: string;
  category: string;
  quantity: number;
  cost?: number;
  paid_from_fees: boolean;
  condition: string;
  status: string;
  date_purchased?: string;
  google_device_id?: string;
  enrollment_status: string;
  category_id?: string;
  serial_number?: string;
  location?: string;
  assigned_to?: string;
  warranty_expiry?: string;
  notes?: string;
}

interface InventoryCategory {
  id: string;
  name: string;
  description?: string;
}

const InventoryList = () => {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [categories, setCategories] = useState<InventoryCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [enrollmentOpen, setEnrollmentOpen] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const { toast } = useToast();

  // All available categories
  const allCategories = [
    { id: '1', name: 'Computers', description: 'Desktops, laptops, tablets, and computer accessories' },
    { id: '2', name: 'Laptops', description: 'Portable computers and laptop accessories' },
    { id: '3', name: 'Tablets', description: 'Tablets and mobile computing devices' },
    { id: '4', name: 'Smartphones', description: 'Mobile phones and smartphone accessories' },
    { id: '5', name: 'Printers', description: 'Printers, scanners, and printing equipment' },
    { id: '6', name: 'Projectors', description: 'Classroom projectors and presentation equipment' },
    { id: '7', name: 'Electronics', description: 'General electronic devices and equipment' },
    { id: '8', name: 'Lab Equipment', description: 'Science lab equipment and instruments' },
    { id: '9', name: 'Sports Equipment', description: 'Sports gear and physical education equipment' },
    { id: '10', name: 'Vehicles', description: 'School vehicles and transportation equipment' },
    { id: '11', name: 'Furniture', description: 'Desks, chairs, tables, and classroom furniture' },
    { id: '12', name: 'Books', description: 'Textbooks, library books, and educational materials' },
    { id: '13', name: 'Office Supplies', description: 'Stationery, paper, and office materials' },
    { id: '14', name: 'Musical Instruments', description: 'Instruments for music education' },
    { id: '15', name: 'Art Supplies', description: 'Materials for art and craft activities' },
    { id: '16', name: 'Kitchen Equipment', description: 'Cafeteria and kitchen appliances' },
    { id: '17', name: 'Cleaning Supplies', description: 'Maintenance and cleaning equipment' },
    { id: '18', name: 'Medical Equipment', description: 'First aid and medical supplies' },
    { id: '19', name: 'Security Equipment', description: 'Cameras, locks, and security devices' },
    { id: '20', name: 'Tools', description: 'Maintenance and repair tools' }
  ];

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [itemsResponse, categoriesResponse] = await Promise.all([
        supabase.from('inventory_items').select('*').order('created_at', { ascending: false }),
        supabase.from('inventory_categories').select('*').order('name')
      ]);

      if (itemsResponse.error) throw itemsResponse.error;
      if (categoriesResponse.error) throw categoriesResponse.error;

      setItems(itemsResponse.data || []);
      setCategories(categoriesResponse.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to fetch inventory data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddItem = () => {
    setSelectedItem(null);
    setFormOpen(true);
  };

  const handleEditItem = (item: InventoryItem) => {
    setSelectedItem(item);
    setFormOpen(true);
  };

  const handleEnrollDevice = (item: InventoryItem) => {
    setSelectedItem(item);
    setEnrollmentOpen(true);
  };

  const handleViewDetails = (item: InventoryItem) => {
    setSelectedItem(item);
    setDetailsOpen(true);
  };

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.serial_number?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  if (loading) {
    return <div className="flex justify-center p-8">Loading inventory items...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {allCategories.map((category) => (
                <SelectItem key={category.id} value={category.name}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="available">Available</SelectItem>
              <SelectItem value="in_use">In Use</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem>
              <SelectItem value="retired">Retired</SelectItem>
              <SelectItem value="lost">Lost</SelectItem>
              <SelectItem value="stolen">Stolen</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button onClick={handleAddItem}>
          <Plus className="h-4 w-4 mr-2" />
          Add Item
        </Button>
      </div>

      {/* Horizontal Card Layout */}
      <div className="space-y-3">
        {filteredItems.map((item) => (
          <InventoryCard
            key={item.id}
            item={item}
            onEdit={handleEditItem}
            onEnroll={handleEnrollDevice}
            onViewDetails={handleViewDetails}
          />
        ))}
      </div>

      {filteredItems.length === 0 && (
        <div className="text-center py-8">
          <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-muted-foreground">No items found</h3>
          <p className="text-muted-foreground">Try adjusting your filters or add a new item.</p>
        </div>
      )}

      {/* Modals */}
      <InventoryItemForm
        open={formOpen}
        onOpenChange={setFormOpen}
        item={selectedItem}
        categories={allCategories}
        onSuccess={fetchData}
      />

      <GoogleDeviceEnrollment
        open={enrollmentOpen}
        onOpenChange={setEnrollmentOpen}
        item={selectedItem}
        onSuccess={fetchData}
      />

      <InventoryItemDetails
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        item={selectedItem}
        onEdit={handleEditItem}
        onEnroll={handleEnrollDevice}
      />
    </div>
  );
};

export default InventoryList;
