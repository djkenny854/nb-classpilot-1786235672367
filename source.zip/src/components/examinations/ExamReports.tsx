
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Download, TrendingUp, Users, Award, Target } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface Exam {
  id: string;
  name: string;
  term: string;
  year: string;
}

interface PerformanceData {
  grade: string;
  count: number;
  percentage: number;
}

interface ClassPerformance {
  class: string;
  average: number;
  students: number;
}

const COLORS = ['#10B981', '#3B82F6', '#F59E0B', '#EF4444', '#6B7280'];

const ExamReports = () => {
  const [exams, setExams] = useState<Exam[]>([]);
  const [selectedExam, setSelectedExam] = useState<string>('');
  const [gradeDistribution, setGradeDistribution] = useState<PerformanceData[]>([]);
  const [classPerformance, setClassPerformance] = useState<ClassPerformance[]>([]);
  const [stats, setStats] = useState({
    totalStudents: 0,
    averageScore: 0,
    passRate: 0,
    highestScore: 0
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchExams();
  }, []);

  useEffect(() => {
    if (selectedExam) {
      fetchReportData();
    }
  }, [selectedExam]);

  const fetchExams = async () => {
    try {
      const { data, error } = await supabase
        .from('exams')
        .select('id, name, term, year')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setExams(data || []);
    } catch (error) {
      console.error('Error fetching exams:', error);
      toast({
        title: "Error",
        description: "Failed to fetch exams",
        variant: "destructive"
      });
    }
  };

  const fetchReportData = async () => {
    if (!selectedExam) return;
    
    setLoading(true);
    try {
      const { data: results, error } = await supabase
        .from('exam_results')
        .select('*')
        .eq('exam_id', selectedExam);

      if (error) throw error;

      if (results && results.length > 0) {
        // Calculate grade distribution
        const grades = ['A', 'B', 'C', 'D', 'F'];
        const gradeData = grades.map(grade => {
          const count = results.filter(r => r.grade === grade).length;
          return {
            grade,
            count,
            percentage: Math.round((count / results.length) * 100)
          };
        });
        setGradeDistribution(gradeData);

        // Calculate class performance
        const classSummary = results.reduce((acc: any, result) => {
          if (!acc[result.class_name]) {
            acc[result.class_name] = {
              totalMarks: 0,
              count: 0
            };
          }
          acc[result.class_name].totalMarks += result.average_marks;
          acc[result.class_name].count += 1;
          return acc;
        }, {});

        const classData = Object.entries(classSummary).map(([className, data]: [string, any]) => ({
          class: className,
          average: Math.round(data.totalMarks / data.count),
          students: data.count
        }));
        setClassPerformance(classData);

        // Calculate overall stats
        const totalStudents = results.length;
        const averageScore = Math.round(results.reduce((sum, r) => sum + r.average_marks, 0) / totalStudents);
        const passCount = results.filter(r => r.grade !== 'F').length;
        const passRate = Math.round((passCount / totalStudents) * 100);
        const highestScore = Math.max(...results.map(r => r.average_marks));

        setStats({
          totalStudents,
          averageScore,
          passRate,
          highestScore
        });
      } else {
        // Reset data if no results
        setGradeDistribution([]);
        setClassPerformance([]);
        setStats({
          totalStudents: 0,
          averageScore: 0,
          passRate: 0,
          highestScore: 0
        });
      }
    } catch (error) {
      console.error('Error fetching report data:', error);
      toast({
        title: "Error",
        description: "Failed to fetch report data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const downloadReport = () => {
    toast({
      title: "Feature Coming Soon",
      description: "Report download functionality will be available soon"
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Exam Analysis & Reports</h2>
          <p className="text-gray-600 mt-1">Comprehensive performance analysis and reporting</p>
        </div>
        <Button onClick={downloadReport} className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Download Report
        </Button>
      </div>

      {/* Exam Selection */}
      <Card>
        <CardContent className="p-4">
          <div className="max-w-md">
            <label className="block text-sm font-medium mb-2">Select Exam for Analysis</label>
            <Select value={selectedExam} onValueChange={setSelectedExam}>
              <SelectTrigger>
                <SelectValue placeholder="Choose an exam to analyze" />
              </SelectTrigger>
              <SelectContent>
                {exams.map((exam) => (
                  <SelectItem key={exam.id} value={exam.id}>
                    {exam.name} - {exam.term} {exam.year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {!selectedExam ? (
        <Card>
          <CardContent className="py-12 text-center">
            <TrendingUp className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500">Select an exam to view analysis</p>
            <p className="text-sm text-gray-400 mt-2">Choose an exam from the dropdown above to see detailed reports</p>
          </CardContent>
        </Card>
      ) : loading ? (
        <Card>
          <CardContent className="py-12 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-gray-500 mt-4">Generating analysis...</p>
          </CardContent>
        </Card>
      ) : stats.totalStudents === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Award className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500">No results data available</p>
            <p className="text-sm text-gray-400 mt-2">Enter exam results to generate analysis reports</p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Key Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <Users className="h-8 w-8 mx-auto text-blue-600 mb-2" />
                <div className="text-2xl font-bold text-blue-600">{stats.totalStudents}</div>
                <div className="text-sm text-gray-600">Total Students</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <Target className="h-8 w-8 mx-auto text-green-600 mb-2" />
                <div className="text-2xl font-bold text-green-600">{stats.averageScore}%</div>
                <div className="text-sm text-gray-600">Average Score</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <Award className="h-8 w-8 mx-auto text-purple-600 mb-2" />
                <div className="text-2xl font-bold text-purple-600">{stats.passRate}%</div>
                <div className="text-sm text-gray-600">Pass Rate</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <TrendingUp className="h-8 w-8 mx-auto text-orange-600 mb-2" />
                <div className="text-2xl font-bold text-orange-600">{stats.highestScore}%</div>
                <div className="text-sm text-gray-600">Highest Score</div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Grade Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Grade Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={gradeDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ grade, percentage }) => `${grade}: ${percentage}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {gradeDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Class Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Performance by Class</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={classPerformance}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="class" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="average" fill="#3B82F6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Grade Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Grade Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3">Grade</th>
                      <th className="text-left p-3">Students</th>
                      <th className="text-left p-3">Percentage</th>
                      <th className="text-left p-3">Performance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {gradeDistribution.map((grade) => (
                      <tr key={grade.grade} className="border-b">
                        <td className="p-3 font-semibold">{grade.grade}</td>
                        <td className="p-3">{grade.count}</td>
                        <td className="p-3">{grade.percentage}%</td>
                        <td className="p-3">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${grade.percentage}%` }}
                            ></div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
};

export default ExamReports;
