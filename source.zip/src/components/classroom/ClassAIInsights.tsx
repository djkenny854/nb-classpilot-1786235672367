
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Brain, 
  TrendingUp, 
  TrendingDown, 
  AlertCircle, 
  Users, 
  GraduationCap,
  RefreshCw
} from 'lucide-react';

interface ClassAIInsightsProps {
  className: string;
  students: Array<{
    id: string;
    full_name: string;
    fee_status?: string;
    gender?: string;
    boarding_status?: string;
  }>;
  feeStats: {
    totalExpected: number;
    totalCollected: number;
    averageBalance: number;
    defaulters: Array<{ name: string; balance: number }>;
  };
}

const ClassAIInsights: React.FC<ClassAIInsightsProps> = ({ 
  className, 
  students, 
  feeStats 
}) => {
  const [insights, setInsights] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);

  const generateInsights = async () => {
    setAnalyzing(true);
    
    // Simulate AI analysis with realistic delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const totalStudents = students.length;
    const collectionRate = feeStats.totalExpected ? 
      (feeStats.totalCollected / feeStats.totalExpected) * 100 : 0;
    const genderBalance = {
      boys: students.filter(s => s.gender?.toLowerCase() === 'male').length,
      girls: students.filter(s => s.gender?.toLowerCase() === 'female').length
    };
    
    const generatedInsights = [
      {
        type: 'financial',
        priority: collectionRate < 70 ? 'high' : collectionRate < 85 ? 'medium' : 'low',
        title: 'Fee Collection Analysis',
        description: `Collection rate is ${collectionRate.toFixed(1)}%. ${
          collectionRate < 70 ? 'Immediate attention needed for fee follow-ups.' :
          collectionRate < 85 ? 'Good progress but room for improvement.' :
          'Excellent collection performance!'
        }`,
        icon: collectionRate < 70 ? TrendingDown : TrendingUp,
        color: collectionRate < 70 ? 'text-red-500' : collectionRate < 85 ? 'text-yellow-500' : 'text-green-500'
      },
      {
        type: 'demographics',
        priority: Math.abs(genderBalance.boys - genderBalance.girls) > totalStudents * 0.3 ? 'medium' : 'low',
        title: 'Class Composition',
        description: `${genderBalance.boys} boys, ${genderBalance.girls} girls. ${
          Math.abs(genderBalance.boys - genderBalance.girls) > totalStudents * 0.3 ? 
          'Consider gender balance in activities.' : 'Well-balanced class composition.'
        }`,
        icon: Users,
        color: 'text-blue-500'
      },
      {
        type: 'performance',
        priority: 'medium',
        title: 'Academic Recommendations',
        description: `With ${totalStudents} students, consider ${
          totalStudents > 30 ? 'smaller group activities and more individual attention.' :
          totalStudents < 15 ? 'collaborative projects to encourage peer learning.' :
          'maintaining current teaching strategies.'
        }`,
        icon: GraduationCap,
        color: 'text-purple-500'
      }
    ];

    if (feeStats.defaulters.length > 0) {
      generatedInsights.unshift({
        type: 'urgent',
        priority: 'high',
        title: 'Fee Defaulters Alert',
        description: `${feeStats.defaulters.length} students have outstanding balances. Top defaulter owes $${feeStats.defaulters[0]?.balance.toLocaleString() || 0}.`,
        icon: AlertCircle,
        color: 'text-red-500'
      });
    }

    setInsights(generatedInsights);
    setAnalyzing(false);
    setLoading(false);
  };

  useEffect(() => {
    generateInsights();
  }, [className, students.length, feeStats]);

  const getPriorityBadge = (priority: string) => {
    const colors = {
      high: 'bg-red-100 text-red-800',
      medium: 'bg-yellow-100 text-yellow-800',
      low: 'bg-green-100 text-green-800'
    };
    return colors[priority as keyof typeof colors] || colors.low;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-500" />
            AI Class Insights
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={generateInsights}
            disabled={analyzing}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${analyzing ? 'animate-spin' : ''}`} />
            {analyzing ? 'Analyzing...' : 'Refresh'}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading || analyzing ? (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Brain className="h-6 w-6 text-purple-500 animate-pulse" />
              <div className="text-sm text-muted-foreground">
                {analyzing ? 'Analyzing class data with AI...' : 'Loading insights...'}
              </div>
            </div>
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-4 bg-gray-200 rounded animate-pulse" style={{
                  width: `${60 + Math.random() * 40}%`
                }} />
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {insights.map((insight, index) => {
              const IconComponent = insight.icon;
              return (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg border bg-gray-50">
                  <IconComponent className={`w-5 h-5 mt-0.5 ${insight.color}`} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-sm">{insight.title}</h4>
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${getPriorityBadge(insight.priority)}`}
                      >
                        {insight.priority}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {insight.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ClassAIInsights;
