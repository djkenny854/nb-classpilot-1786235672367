
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  User, 
  Phone, 
  MapPin, 
  Calendar,
  UserX,
  Move,
  Eye
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Student {
  id: string;
  full_name: string;
  student_id: string;
  profile_image_url?: string;
  gender?: string;
  fee_status?: string;
  boarding_status?: string;
  transport?: string;
  parent_contact?: string;
  address?: string;
}

interface SeatAssignment {
  id: string;
  seat_position: string;
  student_id: string;
  student?: Student;
}

interface ClassSeatingLayoutProps {
  className: string;
}

const ClassSeatingLayout: React.FC<ClassSeatingLayoutProps> = ({ className }) => {
  const [assignments, setAssignments] = useState<SeatAssignment[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showStudentModal, setShowStudentModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Default layout: 6 rows, varying columns to create curved effect
  const seatLayout = [
    { row: 0, seats: 8, offset: 4 }, // Front row - fewer seats, more centered
    { row: 1, seats: 10, offset: 3 },
    { row: 2, seats: 12, offset: 2 },
    { row: 3, seats: 12, offset: 2 },
    { row: 4, seats: 10, offset: 3 },
    { row: 5, seats: 8, offset: 4 }  // Back row
  ];

  const generateSeatPosition = (row: number, seat: number) => {
    const rowLetter = String.fromCharCode(65 + row);
    return `${rowLetter}${seat + 1}`;
  };

  const fetchSeatingData = async () => {
    try {
      setLoading(true);

      // Get or create seat layout
      let { data: layoutData, error: layoutError } = await supabase
        .from('seat_layouts')
        .select('*')
        .eq('class_name', className)
        .single();

      if (layoutError && layoutError.code === 'PGRST116') {
        const { data: newLayout, error: createError } = await supabase
          .from('seat_layouts')
          .insert({
            class_name: className,
            rows: 6,
            columns: 12
          })
          .select()
          .single();

        if (createError) throw createError;
        layoutData = newLayout;
      } else if (layoutError) {
        throw layoutError;
      }

      // Get seat assignments
      const { data: assignmentData, error: assignmentError } = await supabase
        .from('seat_assignments')
        .select(`
          *,
          students (*)
        `)
        .eq('seat_layout_id', layoutData.id);

      if (assignmentError) throw assignmentError;

      const assignmentsWithStudents = assignmentData.map(assignment => ({
        ...assignment,
        student: assignment.students
      }));

      setAssignments(assignmentsWithStudents);

      // Get all students in this class
      const { data: studentsData, error: studentsError } = await supabase
        .from('students')
        .select('*')
        .eq('class', className);

      if (studentsError) throw studentsError;
      setStudents(studentsData || []);

    } catch (error) {
      console.error('Error fetching seating data:', error);
      toast({
        title: "Error",
        description: "Failed to load seating layout",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getStudentForSeat = (seatPosition: string) => {
    return assignments.find(a => a.seat_position === seatPosition)?.student;
  };

  const getFeeStatusColor = (status?: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'ring-green-400';
      case 'partial':
        return 'ring-yellow-400';
      case 'unpaid':
        return 'ring-red-400';
      default:
        return 'ring-gray-300';
    }
  };

  const handleSeatClick = (student: Student | null, seatPosition: string) => {
    if (student) {
      setSelectedStudent(student);
      setShowStudentModal(true);
    } else {
      // Handle empty seat assignment
      toast({
        title: "Empty Seat",
        description: `Seat ${seatPosition} is available for assignment`,
      });
    }
  };

  useEffect(() => {
    fetchSeatingData();
  }, [className]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Teacher's Desk */}
      <div className="flex justify-center mb-8">
        <div className="bg-gradient-to-r from-primary/10 to-primary/20 rounded-lg p-4 px-8 border-2 border-primary/30">
          <div className="text-center">
            <div className="text-sm font-medium text-primary">Teacher's Desk</div>
            <div className="text-xs text-muted-foreground mt-1">Front of Class</div>
          </div>
        </div>
      </div>

      {/* Seating Area */}
      <div className="relative bg-gradient-to-b from-blue-50/30 to-blue-100/20 rounded-3xl p-8 border border-blue-200/50">
        <div className="space-y-4">
          {seatLayout.map((rowConfig, rowIndex) => (
            <div key={rowIndex} className="flex justify-center">
              <div 
                className="flex space-x-2"
                style={{ 
                  marginLeft: `${rowConfig.offset * 0.5}rem`,
                  marginRight: `${rowConfig.offset * 0.5}rem`
                }}
              >
                {Array.from({ length: rowConfig.seats }, (_, seatIndex) => {
                  const seatPosition = generateSeatPosition(rowIndex, seatIndex);
                  const student = getStudentForSeat(seatPosition);
                  const isMiddleGap = seatIndex === Math.floor(rowConfig.seats / 2);

                  return (
                    <React.Fragment key={seatIndex}>
                      {/* Add gap in the middle for aisle */}
                      {isMiddleGap && <div className="w-8" />}
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div
                              className={`
                                relative w-12 h-12 rounded-full cursor-pointer
                                transition-all duration-300 hover:scale-110
                                ${student ? 'ring-2 ' + getFeeStatusColor(student.fee_status) : 'ring-2 ring-dashed ring-gray-300'}
                                ${student ? 'shadow-lg hover:shadow-xl' : 'hover:shadow-md'}
                                ${student ? 'bg-white' : 'bg-gray-50 hover:bg-gray-100'}
                                flex items-center justify-center
                              `}
                              onClick={() => handleSeatClick(student, seatPosition)}
                            >
                              {student ? (
                                <Avatar className="w-10 h-10">
                                  <AvatarImage src={student.profile_image_url} />
                                  <AvatarFallback className="text-xs bg-gradient-to-br from-blue-100 to-purple-100">
                                    {student.full_name.split(' ').map(n => n[0]).join('')}
                                  </AvatarFallback>
                                </Avatar>
                              ) : (
                                <div className="w-10 h-10 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center">
                                  <Plus className="w-4 h-4 text-gray-400" />
                                </div>
                              )}
                              
                              {/* Seat label */}
                              <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2">
                                <div className="text-xs font-mono text-gray-500 bg-white px-1 rounded shadow-sm">
                                  {seatPosition}
                                </div>
                              </div>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            {student ? (
                              <div className="text-center">
                                <p className="font-medium">{student.full_name}</p>
                                <p className="text-sm text-muted-foreground">ID: {student.student_id}</p>
                                <p className="text-sm">Fee: {student.fee_status}</p>
                                <p className="text-xs text-muted-foreground mt-1">Click for details</p>
                              </div>
                            ) : (
                              <div className="text-center">
                                <p className="font-medium">Empty Seat</p>
                                <p className="text-sm text-muted-foreground">Position: {seatPosition}</p>
                                <p className="text-xs text-muted-foreground mt-1">Click to assign</p>
                              </div>
                            )}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </React.Fragment>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="mt-8 flex justify-center">
          <div className="flex items-center space-x-6 text-xs text-muted-foreground">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 rounded-full ring-2 ring-green-400 bg-white"></div>
              <span>Fee Paid</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 rounded-full ring-2 ring-yellow-400 bg-white"></div>
              <span>Partial Payment</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 rounded-full ring-2 ring-red-400 bg-white"></div>
              <span>Fee Unpaid</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 rounded-full ring-2 ring-dashed ring-gray-300 bg-gray-50"></div>
              <span>Empty Seat</span>
            </div>
          </div>
        </div>
      </div>

      {/* Student Detail Modal */}
      <Dialog open={showStudentModal} onOpenChange={setShowStudentModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Student Actions</DialogTitle>
          </DialogHeader>
          {selectedStudent && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={selectedStudent.profile_image_url} />
                  <AvatarFallback>
                    {selectedStudent.full_name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">{selectedStudent.full_name}</h3>
                  <p className="text-sm text-muted-foreground">ID: {selectedStudent.student_id}</p>
                  <Badge variant="outline" className="mt-1">
                    {selectedStudent.gender || 'Unknown'}
                  </Badge>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  View Profile
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <UserX className="w-4 h-4" />
                  Mark Absent
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Move className="w-4 h-4" />
                  Move Seat
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  Contact
                </Button>
              </div>

              <div className="text-sm space-y-2 pt-2 border-t">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Fee Status:</span>
                  <Badge variant={selectedStudent.fee_status === 'paid' ? 'default' : 'destructive'}>
                    {selectedStudent.fee_status}
                  </Badge>
                </div>
                {selectedStudent.boarding_status && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">Boarding:</span>
                    <span>{selectedStudent.boarding_status}</span>
                  </div>
                )}
                {selectedStudent.transport && (
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">Transport:</span>
                    <span>{selectedStudent.transport}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ClassSeatingLayout;
