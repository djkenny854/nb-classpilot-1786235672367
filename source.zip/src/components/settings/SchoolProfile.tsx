
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { School, MapPin, Phone, Mail, Globe, Calendar, Save, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const SchoolProfile = () => {
  const [schoolName, setSchoolName] = useState('ClassPilot Academy');
  const [schoolType, setSchoolType] = useState('primary-secondary');
  const [academicYear, setAcademicYear] = useState('2024-2025');
  const [termSystem, setTermSystem] = useState('3-term');
  const [website, setWebsite] = useState('');
  const [showPublicProfile, setShowPublicProfile] = useState(true);
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: "Profile updated",
      description: "School profile has been saved successfully."
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">School Profile</h2>
        <p className="text-muted-foreground">Manage your school's basic information and settings.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <School className="mr-2 h-5 w-5" />
              Basic Information
            </CardTitle>
            <CardDescription>Configure your school's core details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>School Name</Label>
              <Input 
                value={schoolName} 
                onChange={(e) => setSchoolName(e.target.value)}
                placeholder="Enter school name" 
              />
            </div>

            <div className="space-y-2">
              <Label>School Type</Label>
              <Select value={schoolType || 'primary-secondary'} onValueChange={setSchoolType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select school type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nursery">Nursery School</SelectItem>
                  <SelectItem value="primary">Primary School</SelectItem>
                  <SelectItem value="secondary">Secondary School</SelectItem>
                  <SelectItem value="primary-secondary">Primary & Secondary</SelectItem>
                  <SelectItem value="college">College</SelectItem>
                  <SelectItem value="university">University</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Registration Number</Label>
              <Input placeholder="Official registration number" />
            </div>

            <div className="space-y-2">
              <Label>Established Year</Label>
              <Input type="number" placeholder="e.g., 1995" />
            </div>

            <div className="space-y-2">
              <Label>School Description</Label>
              <Textarea 
                placeholder="Brief description of your school..."
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MapPin className="mr-2 h-5 w-5" />
              Contact Information
            </CardTitle>
            <CardDescription>School contact details and location</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Physical Address</Label>
              <Textarea 
                placeholder="Enter complete address..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>City</Label>
                <Input placeholder="City" />
              </div>
              <div className="space-y-2">
                <Label>District/State</Label>
                <Input placeholder="District/State" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Postal Code</Label>
                <Input placeholder="Postal code" />
              </div>
              <div className="space-y-2">
                <Label>Country</Label>
                <Select defaultValue="uganda">
                  <SelectTrigger>
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="uganda">Uganda</SelectItem>
                    <SelectItem value="kenya">Kenya</SelectItem>
                    <SelectItem value="tanzania">Tanzania</SelectItem>
                    <SelectItem value="rwanda">Rwanda</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Phone Number</Label>
              <Input placeholder="+256 xxx xxx xxx" />
            </div>

            <div className="space-y-2">
              <Label>Email Address</Label>
              <Input type="email" placeholder="info@school.edu" />
            </div>

            <div className="space-y-2">
              <Label>Website</Label>
              <Input 
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                placeholder="https://www.school.edu" 
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="mr-2 h-5 w-5" />
              Academic Configuration
            </CardTitle>
            <CardDescription>Configure academic year and term structure</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Current Academic Year</Label>
              <Select value={academicYear || '2024-2025'} onValueChange={setAcademicYear}>
                <SelectTrigger>
                  <SelectValue placeholder="Select academic year" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2023-2024">2023-2024</SelectItem>
                  <SelectItem value="2024-2025">2024-2025</SelectItem>
                  <SelectItem value="2025-2026">2025-2026</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Term System</Label>
              <Select value={termSystem || '3-term'} onValueChange={setTermSystem}>
                <SelectTrigger>
                  <SelectValue placeholder="Select term system" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2-term">2 Terms per Year</SelectItem>
                  <SelectItem value="3-term">3 Terms per Year</SelectItem>
                  <SelectItem value="4-term">4 Terms per Year</SelectItem>
                  <SelectItem value="semester">Semester System</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Current Term</Label>
              <Select defaultValue="term-1">
                <SelectTrigger>
                  <SelectValue placeholder="Select current term" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="term-1">Term 1</SelectItem>
                  <SelectItem value="term-2">Term 2</SelectItem>
                  <SelectItem value="term-3">Term 3</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Term Start Date</Label>
                <Input type="date" />
              </div>
              <div className="space-y-2">
                <Label>Term End Date</Label>
                <Input type="date" />
              </div>
            </div>

            <div className="space-y-2">
              <Label>School Currency</Label>
              <Select defaultValue="ugx">
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ugx">Ugandan Shilling (UGX)</SelectItem>
                  <SelectItem value="kes">Kenyan Shilling (KES)</SelectItem>
                  <SelectItem value="tzs">Tanzanian Shilling (TZS)</SelectItem>
                  <SelectItem value="usd">US Dollar (USD)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Globe className="mr-2 h-5 w-5" />
              Public Profile & Branding
            </CardTitle>
            <CardDescription>Manage how your school appears publicly</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>School Logo</Label>
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                    <School className="h-8 w-8 text-gray-400" />
                  </div>
                  <Button variant="outline">
                    <Upload className="mr-2 h-4 w-4" />
                    Upload Logo
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>Show Public Profile</Label>
                  <p className="text-xs text-muted-foreground">
                    Make school information visible to public
                  </p>
                </div>
                <Switch checked={showPublicProfile} onCheckedChange={setShowPublicProfile} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>Allow Online Applications</Label>
                  <p className="text-xs text-muted-foreground">
                    Enable online admission applications
                  </p>
                </div>
                <Switch />
              </div>

              <div className="space-y-2">
                <Label>School Colors</Label>
                <div className="flex space-x-2">
                  <div className="space-y-1">
                    <Label className="text-xs">Primary Color</Label>
                    <Input type="color" value="#3B82F6" className="w-16 h-8" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Secondary Color</Label>
                    <Input type="color" value="#10B981" className="w-16 h-8" />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end pt-4">
        <Button onClick={handleSave} className="min-w-32">
          <Save className="h-4 w-4 mr-2" />
          Save Profile
        </Button>
      </div>
    </div>
  );
};

export default SchoolProfile;
