
import React, { useState } from 'react';
import { ScrollText } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface ExamConfigCardProps {
  examTypes: string[];
  setExamTypes: (types: string[]) => void;
}

const ExamConfigCard = ({ examTypes, setExamTypes }: ExamConfigCardProps) => {
  const [newExamType, setNewExamType] = useState('');
  
  const addExamType = () => {
    if (newExamType && !examTypes.includes(newExamType)) {
      setExamTypes([...examTypes, newExamType]);
      setNewExamType('');
    }
  };
  
  const removeExamType = (type: string) => {
    setExamTypes(examTypes.filter(item => item !== type));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <ScrollText className="mr-2 h-5 w-5" />
          Exam Configuration
        </CardTitle>
        <CardDescription>Set up exam types and weightings</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Exam Types</label>
          <div className="flex gap-2 flex-wrap">
            {examTypes.map(type => (
              <div key={type} className="bg-primary/10 px-3 py-1 rounded-full text-sm flex items-center gap-2">
                {type}
                <button 
                  onClick={() => removeExamType(type)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>
        
        <div className="flex gap-2">
          <Input 
            placeholder="Add new exam type..." 
            value={newExamType}
            onChange={(e) => setNewExamType(e.target.value)}
            className="flex-1"
          />
          <Button onClick={addExamType}>Add</Button>
        </div>
        
        <div className="space-y-2 pt-2">
          <label className="text-sm font-medium">Default Exam Weightings</label>
          <div className="space-y-2">
            {examTypes.map(type => (
              <div key={`weight-${type}`} className="flex items-center gap-2">
                <span className="min-w-24 capitalize">{type}</span>
                <Input type="number" min="0" max="100" defaultValue="50" className="w-20" />
                <span>%</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExamConfigCard;
