import React from 'react';
import { Menu, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useSiteSettings } from '@/context/SiteSettingsContext';
import { useIsMobile } from '@/hooks/use-mobile';
import ClassPilotLogo from '@/components/common/ClassPilotLogo';

const TopBar: React.FC = () => {
  const { toggleSidebar } = useSiteSettings();
  const isMobile = useIsMobile();
  
  return (
    <header className="h-14 bg-background border-b border-border px-3 md:px-4 flex items-center justify-between sticky top-0 z-30">
      {/* Left Section */}
      <div className="flex items-center gap-2 flex-shrink-0">
        {isMobile && (
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={toggleSidebar} 
            className="h-10 w-10 rounded-full hover:bg-accent"
          >
            <Menu className="h-5 w-5" strokeWidth={1.75} />
          </Button>
        )}
        {isMobile && <ClassPilotLogo size={24} showText={false} />}
      </div>

      {/* Center Section - Empty now (search removed) */}
      <div className="flex-1" />

      {/* Right Section */}
      <div className="flex items-center gap-1 flex-shrink-0">
        {/* Notifications */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-10 w-10 rounded-full hover:bg-accent relative"
        >
          <Bell className="h-5 w-5" strokeWidth={1.75} />
          <Badge 
            variant="destructive" 
            className="absolute -top-0.5 -right-0.5 h-4 w-4 p-0 flex items-center justify-center text-[10px] rounded-full"
          >
            3
          </Badge>
        </Button>

        {/* Profile */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-10 w-10 rounded-full hover:bg-accent"
        >
          <Avatar className="h-8 w-8">
            <AvatarImage src="" alt="User" />
            <AvatarFallback className="bg-primary text-primary-foreground text-xs">
              AD
            </AvatarFallback>
          </Avatar>
        </Button>
      </div>
    </header>
  );
};

export default TopBar;
