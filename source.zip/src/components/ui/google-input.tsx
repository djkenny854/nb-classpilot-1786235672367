
import React, { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface GoogleInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  helperText?: string;
}

const GoogleInput = React.forwardRef<HTMLInputElement, GoogleInputProps>(
  ({ label, error, helperText, className, value, onChange, onFocus, onBlur, ...props }, ref) => {
    const [isFocused, setIsFocused] = useState(false);
    const [hasValue, setHasValue] = useState(!!value || !!props.defaultValue);
    const inputRef = useRef<HTMLInputElement>(null);

    React.useImperativeHandle(ref, () => inputRef.current!);

    useEffect(() => {
      setHasValue(!!value);
    }, [value]);

    const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
      setIsFocused(true);
      onFocus?.(e);
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
      setIsFocused(false);
      setHasValue(!!e.target.value);
      onBlur?.(e);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setHasValue(!!e.target.value);
      onChange?.(e);
    };

    const isFloating = isFocused || hasValue;

    return (
      <div className="relative">
        <div className="relative">
          <input
            ref={inputRef}
            {...props}
            value={value}
            onFocus={handleFocus}
            onBlur={handleBlur}
            onChange={handleChange}
            className={cn(
              "w-full px-4 pt-6 pb-2 text-base bg-white border rounded-lg transition-all duration-200 outline-none peer",
              "border-gray-300 hover:border-gray-400",
              "focus:border-primary focus:ring-2 focus:ring-primary/20",
              error && "border-destructive focus:border-destructive focus:ring-destructive/20",
              className
            )}
            placeholder=""
          />
          <label
            className={cn(
              "absolute left-4 text-gray-500 transition-all duration-200 pointer-events-none select-none",
              isFloating
                ? "top-2 text-xs transform scale-90 origin-left"
                : "top-1/2 -translate-y-1/2 text-base",
              isFocused && "text-primary",
              error && isFloating && "text-destructive"
            )}
          >
            {label}
          </label>
        </div>
        
        {(error || helperText) && (
          <div className="mt-1 text-xs">
            {error ? (
              <span className="text-destructive">{error}</span>
            ) : (
              <span className="text-muted-foreground">{helperText}</span>
            )}
          </div>
        )}
      </div>
    );
  }
);

GoogleInput.displayName = 'GoogleInput';

export { GoogleInput };
