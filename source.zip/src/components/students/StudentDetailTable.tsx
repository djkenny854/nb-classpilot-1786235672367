
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Eye, Edit, Trash2 } from 'lucide-react';
import { Student } from '@/types';
import StudentFeeBalance from './StudentFeeBalance';

interface StudentDetailTableProps {
  students: Student[];
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (studentId: string) => void;
  loading: boolean;
}

const StudentDetailTable = ({ students, onEditStudent, onDeleteStudent, loading }: StudentDetailTableProps) => {
  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="flex items-center space-x-4">
                <div className="rounded-full bg-gray-200 h-12 w-12"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (students.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-gray-500">No students found matching your filters.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {students.map((student) => (
        <Card key={student.id} className="hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-start gap-4">
              {/* Student Avatar and Basic Info */}
              <div className="flex items-center gap-3 flex-1">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={student.profileImage} alt={student.name} />
                  <AvatarFallback className="bg-blue-100 text-blue-600">
                    {student.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-lg">{student.name}</h3>
                    <Badge variant="outline" className="text-xs">
                      {student.className}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-gray-600">
                    <div>
                      <span className="font-medium">ID:</span> {student.enrollmentNumber}
                    </div>
                    <div>
                      <span className="font-medium">Gender:</span> {student.gender || 'Not specified'}
                    </div>
                    <div>
                      <span className="font-medium">Status:</span>
                      <Badge 
                        variant={student.boardingStatus === 'Boarding' ? 'default' : 'outline'}
                        className="ml-1 text-xs"
                      >
                        {student.boardingStatus}
                      </Badge>
                    </div>
                  </div>
                  
                  {student.parentName && (
                    <div className="mt-2 text-sm text-gray-600">
                      <span className="font-medium">Parent:</span> {student.parentName}
                      {student.parentContact && (
                        <span className="ml-2">• {student.parentContact}</span>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Fee Balance */}
              <div className="w-64">
                <StudentFeeBalance studentId={student.id} />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onEditStudent(student)}
                  className="w-full"
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDeleteStudent(student.id)}
                  className="w-full text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default StudentDetailTable;
