
import React from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Search, Filter, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface StudentFiltersProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  classFilter: string;
  setClassFilter: (classId: string) => void;
  feeStatusFilter: string;
  setFeeStatusFilter: (status: string) => void;
  boardingStatusFilter: string;
  setBoardingStatusFilter: (status: string) => void;
  transportFilter: string;
  setTransportFilter: (transport: string) => void;
  genderFilter: string;
  setGenderFilter: (gender: string) => void;
  onClearFilters: () => void;
  classes: Array<{ id: string; full_name: string }>;
}

const StudentFilters = ({
  searchTerm,
  setSearchTerm,
  classFilter,
  setClassFilter,
  feeStatusFilter,
  setFeeStatusFilter,
  boardingStatusFilter,
  setBoardingStatusFilter,
  transportFilter,
  setTransportFilter,
  genderFilter,
  setGenderFilter,
  onClearFilters,
  classes
}: StudentFiltersProps) => {
  const hasActiveFilters = searchTerm || (classFilter && classFilter !== 'all') || (feeStatusFilter && feeStatusFilter !== 'all') || (boardingStatusFilter && boardingStatusFilter !== 'all') || (transportFilter && transportFilter !== 'all') || (genderFilter && genderFilter !== 'all');

  const handleClearFilters = () => {
    setSearchTerm('');
    setClassFilter('all');
    setFeeStatusFilter('all');
    setBoardingStatusFilter('all');
    setTransportFilter('all');
    setGenderFilter('all');
    onClearFilters();
  };

  return (
    <div className="bg-card border border-border p-3 sm:p-4 rounded-lg space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-foreground">
          <Filter className="h-4 w-4" />
          <h3 className="font-medium text-sm">Filters</h3>
        </div>
        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={handleClearFilters} className="flex items-center gap-1 h-7 text-xs">
            <X className="h-3 w-3" />
            Clear
          </Button>
        )}
      </div>

      {/* Filters Grid - Responsive */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 sm:gap-3">
        {/* Search */}
        <div className="col-span-2 sm:col-span-1 space-y-1">
          <Label htmlFor="search" className="text-xs text-muted-foreground">Search</Label>
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              id="search"
              placeholder="Name, ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 h-9 text-sm bg-secondary border-border text-foreground"
            />
          </div>
        </div>

        {/* Class Filter */}
        <div className="space-y-1">
          <Label htmlFor="class" className="text-xs text-muted-foreground">Class</Label>
          <Select value={classFilter || 'all'} onValueChange={setClassFilter}>
            <SelectTrigger className="h-9 text-sm bg-secondary border-border">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border z-50">
              <SelectItem value="all">All</SelectItem>
              {classes.map((cls) => (
                <SelectItem key={cls.id} value={cls.full_name || `unknown-class-${cls.id}`}>
                  {cls.full_name || 'Unknown'}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Fee Status Filter */}
        <div className="space-y-1">
          <Label htmlFor="fee-status" className="text-xs text-muted-foreground">Fee</Label>
          <Select value={feeStatusFilter || 'all'} onValueChange={setFeeStatusFilter}>
            <SelectTrigger className="h-9 text-sm bg-secondary border-border">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border z-50">
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="Paid">Paid</SelectItem>
              <SelectItem value="Partial">Partial</SelectItem>
              <SelectItem value="Unpaid">Unpaid</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Boarding Status Filter */}
        <div className="space-y-1">
          <Label htmlFor="boarding-status" className="text-xs text-muted-foreground">Boarding</Label>
          <Select value={boardingStatusFilter || 'all'} onValueChange={setBoardingStatusFilter}>
            <SelectTrigger className="h-9 text-sm bg-secondary border-border">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border z-50">
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="Day">Day</SelectItem>
              <SelectItem value="Boarding">Boarding</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Transport Filter */}
        <div className="space-y-1">
          <Label htmlFor="transport" className="text-xs text-muted-foreground">Transport</Label>
          <Select value={transportFilter || 'all'} onValueChange={setTransportFilter}>
            <SelectTrigger className="h-9 text-sm bg-secondary border-border">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border z-50">
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="Yes">Yes</SelectItem>
              <SelectItem value="No">No</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Gender Filter */}
        <div className="space-y-1">
          <Label htmlFor="gender" className="text-xs text-muted-foreground">Gender</Label>
          <Select value={genderFilter || 'all'} onValueChange={setGenderFilter}>
            <SelectTrigger className="h-9 text-sm bg-secondary border-border">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent className="bg-popover border-border z-50">
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="Male">Male</SelectItem>
              <SelectItem value="Female">Female</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-1.5 pt-2 border-t border-border">
          {searchTerm && (
            <Badge variant="secondary" className="text-[10px] px-1.5 py-0.5">
              "{searchTerm}"
            </Badge>
          )}
          {classFilter && classFilter !== 'all' && (
            <Badge variant="secondary" className="text-[10px] px-1.5 py-0.5 bg-green-500/20 text-green-500">
              {classFilter}
            </Badge>
          )}
          {feeStatusFilter && feeStatusFilter !== 'all' && (
            <Badge variant="secondary" className="text-[10px] px-1.5 py-0.5 bg-yellow-500/20 text-yellow-500">
              {feeStatusFilter}
            </Badge>
          )}
          {boardingStatusFilter && boardingStatusFilter !== 'all' && (
            <Badge variant="secondary" className="text-[10px] px-1.5 py-0.5 bg-purple-500/20 text-purple-500">
              {boardingStatusFilter}
            </Badge>
          )}
          {transportFilter && transportFilter !== 'all' && (
            <Badge variant="secondary" className="text-[10px] px-1.5 py-0.5 bg-orange-500/20 text-orange-500">
              Transport: {transportFilter}
            </Badge>
          )}
          {genderFilter && genderFilter !== 'all' && (
            <Badge variant="secondary" className="text-[10px] px-1.5 py-0.5 bg-pink-500/20 text-pink-500">
              {genderFilter}
            </Badge>
          )}
        </div>
      )}
    </div>
  );
};

export default StudentFilters;
