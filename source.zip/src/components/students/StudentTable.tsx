import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Users, Filter } from 'lucide-react';
import { Student } from '@/types';
import StudentFilters from './StudentFilters';
import StudentListView from './StudentListView';

interface StudentTableProps {
  onViewStudent: (student: Student) => void;
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (studentId: string) => void;
  refreshTrigger: number;
  selectedStudents: Student[];
  onStudentSelect: (students: Student[]) => void;
}

const StudentTable = ({ 
  onViewStudent, 
  onEditStudent, 
  onDeleteStudent, 
  refreshTrigger,
  selectedStudents,
  onStudentSelect
}: StudentTableProps) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [classes, setClasses] = useState<Array<{ id: string; full_name: string }>>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const { toast } = useToast();

  const [searchTerm, setSearchTerm] = useState('');
  const [classFilter, setClassFilter] = useState('');
  const [feeStatusFilter, setFeeStatusFilter] = useState('');
  const [boardingStatusFilter, setBoardingStatusFilter] = useState('');
  const [transportFilter, setTransportFilter] = useState('');
  const [genderFilter, setGenderFilter] = useState('');

  useEffect(() => {
    fetchStudents();
    fetchClasses();
  }, [refreshTrigger]);

  useEffect(() => {
    applyFilters();
  }, [students, searchTerm, classFilter, feeStatusFilter, boardingStatusFilter, transportFilter, genderFilter]);

  const fetchStudents = async () => {
    try {
      setLoading(true);
      const { data: studentsData, error: studentsError } = await supabase
        .from('students')
        .select(`
          *,
          student_balances(
            total_required,
            total_paid,
            balance
          )
        `)
        .order('full_name');

      if (studentsError) throw studentsError;

      const transformedStudents: Student[] = (studentsData || []).map(student => {
        const latestBalance = student.student_balances?.[0];
        return {
          id: student.id,
          name: student.full_name,
          enrollmentNumber: student.student_id,
          classId: student.class,
          className: student.class,
          parentName: student.parent_name || '',
          parentContact: student.parent_contact || '',
          gender: student.gender || '',
          profileImage: student.profile_image_url || student.profile_image || '',
          fees: {
            paid: latestBalance?.total_paid || 0,
            due: latestBalance?.balance || 0,
            lastPaymentDate: ''
          },
          boardingStatus: (student.boarding_status as 'Boarding' | 'Day') || 'Day',
          transportUse: (student.transport as 'Yes' | 'No') || 'No',
          dateOfBirth: student.date_of_birth || '',
          address: student.address || '',
          joinDate: student.join_date || '',
          email: student.email || '',
          bloodGroup: student.blood_group || '',
          emergencyContact: student.emergency_contact || '',
          medicalConditions: student.medical_conditions || '',
          bestColor: student.best_color || '',
          clubsActivities: student.clubs_activities || [],
        };
      });

      setStudents(transformedStudents);
    } catch (error) {
      console.error('Error fetching students:', error);
      toast({
        title: "Error",
        description: "Failed to fetch students",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchClasses = async () => {
    try {
      const { data, error } = await supabase
        .from('class_streams')
        .select('id, full_name')
        .order('class_level, stream_name');

      if (error) throw error;
      setClasses(data || []);
    } catch (error) {
      console.error('Error fetching classes:', error);
    }
  };

  const applyFilters = () => {
    let filtered = [...students];

    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(student =>
        student.name.toLowerCase().includes(searchLower) ||
        student.enrollmentNumber.toLowerCase().includes(searchLower) ||
        student.parentName.toLowerCase().includes(searchLower) ||
        student.parentContact.includes(searchTerm)
      );
    }

    if (classFilter) {
      filtered = filtered.filter(student => student.className === classFilter);
    }

    if (feeStatusFilter) {
      filtered = filtered.filter(student => {
        if (feeStatusFilter === 'Paid') return student.fees.due <= 0 && student.fees.paid > 0;
        if (feeStatusFilter === 'Unpaid') return student.fees.paid === 0;
        if (feeStatusFilter === 'Partial') return student.fees.paid > 0 && student.fees.due > 0;
        return true;
      });
    }

    if (boardingStatusFilter) {
      filtered = filtered.filter(student => student.boardingStatus === boardingStatusFilter);
    }

    if (transportFilter) {
      filtered = filtered.filter(student => student.transportUse === transportFilter);
    }

    if (genderFilter) {
      filtered = filtered.filter(student => student.gender === genderFilter);
    }

    setFilteredStudents(filtered);
  };

  const clearFilters = () => {
    setSearchTerm('');
    setClassFilter('');
    setFeeStatusFilter('');
    setBoardingStatusFilter('');
    setTransportFilter('');
    setGenderFilter('');
  };

  const handleStudentClick = (student: Student) => {
    onViewStudent(student);
  };

  const handleEditStudent = (student: Student) => {
    onEditStudent(student);
  };

  return (
    <div className="space-y-6">
      {/* Header with Filter Toggle */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-secondary rounded-xl">
            <Users className="h-5 w-5 text-muted-foreground" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground">
              Students
            </h2>
            <p className="text-sm text-muted-foreground">
              {filteredStudents.length} of {students.length} students
            </p>
          </div>
        </div>
        
        <Button
          variant="outline"
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 rounded-xl"
        >
          <Filter className="h-4 w-4" />
          {showFilters ? 'Hide Filters' : 'Show Filters'}
        </Button>
      </div>

      {/* Filters */}
      {showFilters && (
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">Filter Students</CardTitle>
            <CardDescription>
              Use the filters below to find specific students
            </CardDescription>
          </CardHeader>
          <CardContent>
            <StudentFilters
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              classFilter={classFilter}
              setClassFilter={setClassFilter}
              feeStatusFilter={feeStatusFilter}
              setFeeStatusFilter={setFeeStatusFilter}
              boardingStatusFilter={boardingStatusFilter}
              setBoardingStatusFilter={setBoardingStatusFilter}
              transportFilter={transportFilter}
              setTransportFilter={setTransportFilter}
              genderFilter={genderFilter}
              setGenderFilter={setGenderFilter}
              onClearFilters={clearFilters}
              classes={classes}
            />
          </CardContent>
        </Card>
      )}

      {/* Students List */}
      <StudentListView
        students={filteredStudents}
        onStudentClick={handleStudentClick}
        onEditStudent={handleEditStudent}
        loading={loading}
      />
    </div>
  );
};

export default StudentTable;
