import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DollarSign, Users, TrendingUp, AlertCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useData } from '@/context/DataSyncContext';

interface FeeSummaryStats {
  totalStudents: number;
  totalExpectedFees: number;
  totalCollectedFees: number;
  outstandingFees: number;
  collectionRate: number;
}

const FeesOverview = () => {
  const { students } = useData();
  const [stats, setStats] = useState<FeeSummaryStats>({
    totalStudents: 0,
    totalExpectedFees: 0,
    totalCollectedFees: 0,
    outstandingFees: 0,
    collectionRate: 0
  });
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Fetch student fees and payments
      const { data: studentFees, error: feesError } = await supabase
        .from('student_fees')
        .select('*');
      
      if (feesError) throw feesError;

      const { data: payments, error: paymentsError } = await supabase
        .from('fee_transactions')
        .select('*');
      
      if (paymentsError) throw paymentsError;

      // Calculate statistics
      const totalStudents = students.length;
      let totalExpectedFees = 0;
      let totalCollectedFees = 0;

      // Sum up expected fees from student_fees
      studentFees?.forEach(fee => {
        totalExpectedFees += fee.total_assigned_fees || 0;
      });

      // Sum up collected fees from fee_transactions
      payments?.forEach(payment => {
        totalCollectedFees += payment.amount || 0;
      });

      const outstandingFees = totalExpectedFees - totalCollectedFees;
      const collectionRate = totalExpectedFees > 0 ? (totalCollectedFees / totalExpectedFees) * 100 : 0;

      setStats({
        totalStudents,
        totalExpectedFees,
        totalCollectedFees,
        outstandingFees,
        collectionRate
      });
    } catch (error) {
      console.error('Error loading fees overview data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [students]);

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="h-4 w-20 bg-muted rounded animate-pulse" />
              <div className="h-4 w-4 bg-muted rounded animate-pulse" />
            </CardHeader>
            <CardContent>
              <div className="h-8 w-24 bg-muted rounded animate-pulse mb-2" />
              <div className="h-3 w-32 bg-muted rounded animate-pulse" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalStudents}</div>
            <p className="text-xs text-muted-foreground">
              Enrolled students
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expected Fees</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">UGX {stats.totalExpectedFees.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Total fees expected
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Collected Fees</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600 dark:text-green-400">UGX {stats.totalCollectedFees.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Total fees collected
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">UGX {stats.outstandingFees.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {stats.collectionRate.toFixed(1)}% collection rate
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Fee Collection Summary</CardTitle>
          <CardDescription>
            Overview of fee collection status across all students
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Collection Progress</span>
              <span className="text-sm text-muted-foreground">
                {stats.collectionRate.toFixed(1)}%
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(stats.collectionRate, 100)}%` }}
              />
            </div>
            <div className="grid grid-cols-2 gap-4 mt-4">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Total Expected</p>
                <p className="text-lg font-semibold text-foreground">UGX {stats.totalExpectedFees.toLocaleString()}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Total Collected</p>
                <p className="text-lg font-semibold text-green-600 dark:text-green-400">UGX {stats.totalCollectedFees.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FeesOverview;
