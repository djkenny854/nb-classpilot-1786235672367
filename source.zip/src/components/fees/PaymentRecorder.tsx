
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { Search, CreditCard, Receipt, AlertCircle } from 'lucide-react';

interface Student {
  id: string;
  full_name: string;
  student_id: string;
  class: string;
  balance: number;
  total_expected: number;
  total_paid: number;
}

const PaymentRecorder = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [paymentData, setPaymentData] = useState({
    amount: '',
    method: 'Cash',
    notes: '',
    receiptNumber: ''
  });
  const [isRecording, setIsRecording] = useState(false);
  const [showReceipt, setShowReceipt] = useState(false);
  const [lastPayment, setLastPayment] = useState<any>(null);

  useEffect(() => {
    fetchStudents();
  }, []);

  useEffect(() => {
    if (searchTerm) {
      setFilteredStudents(
        students.filter(student =>
          student.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          student.student_id.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    } else {
      setFilteredStudents([]);
    }
  }, [searchTerm, students]);

  const fetchStudents = async () => {
    try {
      const { data, error } = await supabase
        .from('students')
        .select(`
          id,
          full_name,
          student_id,
          class,
          student_fees(
            total_assigned_fees,
            total_paid,
            balance
          )
        `);

      if (error) throw error;

      const processedStudents: Student[] = data.map(student => ({
        id: student.id,
        full_name: student.full_name,
        student_id: student.student_id,
        class: student.class,
        balance: student.student_fees?.[0]?.balance || 0,
        total_expected: student.student_fees?.[0]?.total_assigned_fees || 0,
        total_paid: student.student_fees?.[0]?.total_paid || 0
      }));

      setStudents(processedStudents);
    } catch (error) {
      console.error('Error fetching students:', error);
      toast.error('Failed to fetch students');
    }
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent || !paymentData.amount) {
      toast.error('Please select a student and enter an amount');
      return;
    }

    const amount = parseFloat(paymentData.amount);
    if (amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    setIsRecording(true);
    try {
      // Generate receipt number
      const receiptNumber = `RCP-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

      // Record the payment
      const { data: transaction, error } = await supabase
        .from('fee_transactions')
        .insert({
          student_id: selectedStudent.id,
          amount: amount,
          payment_method: paymentData.method,
          notes: paymentData.notes,
          receipt_number: receiptNumber,
          academic_year: new Date().getFullYear().toString(),
          academic_term: 'Term 1' // This should be dynamic
        })
        .select()
        .single();

      if (error) throw error;

      // Update student balance
      const newBalance = selectedStudent.balance - amount;
      const newTotalPaid = selectedStudent.total_paid + amount;

      await supabase
        .from('student_fees')
        .update({
          total_paid: newTotalPaid,
          balance: newBalance
        })
        .eq('student_id', selectedStudent.id);

      // Update fee status
      const feeStatus = newBalance <= 0 ? 'Paid' : newBalance < selectedStudent.total_expected ? 'Partial' : 'Unpaid';
      await supabase
        .from('students')
        .update({ fee_status: feeStatus })
        .eq('id', selectedStudent.id);

      setLastPayment({
        ...transaction,
        student: selectedStudent,
        receiptNumber
      });

      // Handle overpayment
      if (newBalance < 0) {
        toast.success(`Payment recorded! Student has overpaid by UGX ${Math.abs(newBalance).toLocaleString()}`);
      } else {
        toast.success('Payment recorded successfully!');
      }

      setShowReceipt(true);
      resetForm();
      fetchStudents(); // Refresh data
    } catch (error) {
      console.error('Error recording payment:', error);
      toast.error('Failed to record payment');
    } finally {
      setIsRecording(false);
    }
  };

  const resetForm = () => {
    setPaymentData({
      amount: '',
      method: 'Cash',
      notes: '',
      receiptNumber: ''
    });
    setSelectedStudent(null);
    setSearchTerm('');
  };

  const printReceipt = () => {
    window.print();
  };

  if (showReceipt && lastPayment) {
    return (
      <Card>
        <CardHeader className="bg-green-50">
          <CardTitle className="flex items-center gap-2">
            <Receipt className="h-5 w-5" />
            Payment Receipt
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-6 max-w-md mx-auto">
            <div className="text-center">
              <h2 className="text-xl font-bold">School Fee Receipt</h2>
              <p className="text-sm text-gray-600">Receipt #{lastPayment.receiptNumber}</p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Student:</span>
                <span className="font-medium">{lastPayment.student.full_name}</span>
              </div>
              <div className="flex justify-between">
                <span>Student ID:</span>
                <span>{lastPayment.student.student_id}</span>
              </div>
              <div className="flex justify-between">
                <span>Class:</span>
                <span>{lastPayment.student.class}</span>
              </div>
              <div className="flex justify-between">
                <span>Date:</span>
                <span>{new Date().toLocaleDateString()}</span>
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="flex justify-between text-lg font-semibold">
                <span>Amount Paid:</span>
                <span className="text-green-600">UGX {lastPayment.amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Payment Method:</span>
                <span>{lastPayment.payment_method}</span>
              </div>
            </div>

            <div className="border-t pt-4 text-center text-sm text-gray-600">
              <p>Thank you for your payment!</p>
              <p>Keep this receipt for your records.</p>
            </div>

            <div className="flex gap-2 justify-center">
              <Button onClick={printReceipt} variant="outline">
                Print Receipt
              </Button>
              <Button onClick={() => setShowReceipt(false)}>
                Record Another Payment
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          Record Fee Payment
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handlePaymentSubmit} className="space-y-6">
          {/* Student Search */}
          <div className="space-y-2">
            <Label>Search Student</Label>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Type student name or ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>
            
            {filteredStudents.length > 0 && (
              <div className="border rounded-md max-h-60 overflow-y-auto">
                {filteredStudents.map((student) => (
                  <div
                    key={student.id}
                    className="p-3 hover:bg-gray-50 cursor-pointer border-b last:border-b-0"
                    onClick={() => {
                      setSelectedStudent(student);
                      setSearchTerm(student.full_name);
                      setFilteredStudents([]);
                    }}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">{student.full_name}</div>
                        <div className="text-sm text-gray-500">
                          {student.student_id} • {student.class}
                        </div>
                      </div>
                      <Badge variant={student.balance > 0 ? "destructive" : "default"}>
                        Balance: UGX {student.balance.toLocaleString()}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Selected Student Info */}
          {selectedStudent && (
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Selected Student</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Name:</span>
                  <div className="font-medium">{selectedStudent.full_name}</div>
                </div>
                <div>
                  <span className="text-gray-600">Class:</span>
                  <div>{selectedStudent.class}</div>
                </div>
                <div>
                  <span className="text-gray-600">Total Expected:</span>
                  <div>UGX {selectedStudent.total_expected.toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-gray-600">Outstanding Balance:</span>
                  <div className="font-semibold text-red-600">
                    UGX {selectedStudent.balance.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Payment Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Amount Paid (UGX)</Label>
              <Input
                type="number"
                placeholder="0"
                value={paymentData.amount}
                onChange={(e) => setPaymentData({...paymentData, amount: e.target.value})}
                required
              />
              {selectedStudent && paymentData.amount && 
                parseFloat(paymentData.amount) > selectedStudent.balance && (
                <div className="flex items-center gap-2 text-amber-600 text-sm">
                  <AlertCircle className="h-4 w-4" />
                  <span>Amount exceeds balance by UGX {(parseFloat(paymentData.amount) - selectedStudent.balance).toLocaleString()}</span>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Payment Method</Label>
              <Select value={paymentData.method} onValueChange={(value) => setPaymentData({...paymentData, method: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Cash">Cash</SelectItem>
                  <SelectItem value="Mobile Money">Mobile Money</SelectItem>
                  <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                  <SelectItem value="Card">Card</SelectItem>
                  <SelectItem value="Cheque">Cheque</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Notes (Optional)</Label>
            <Textarea
              placeholder="Any additional notes about this payment..."
              value={paymentData.notes}
              onChange={(e) => setPaymentData({...paymentData, notes: e.target.value})}
            />
          </div>

          <div className="flex gap-2">
            <Button type="submit" disabled={!selectedStudent || !paymentData.amount || isRecording}>
              {isRecording ? 'Recording...' : 'Record Payment'}
            </Button>
            <Button type="button" variant="outline" onClick={resetForm}>
              Clear
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default PaymentRecorder;
