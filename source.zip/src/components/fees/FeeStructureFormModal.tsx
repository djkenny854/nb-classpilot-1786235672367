
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ClassOption {
  id: string;
  full_name: string;
  class_level: string;
  stream_name: string;
}

interface FeeStructureFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingStructure?: any;
  onSuccess: () => void;
}

const FeeStructureFormModal: React.FC<FeeStructureFormModalProps> = ({
  isOpen,
  onClose,
  editingStructure,
  onSuccess,
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    class_level: '',
    academic_year: new Date().getFullYear().toString(),
    academic_term: 'Term 1',
    boarding_status: 'Both',
    tuition_fee: 0,
    boarding_fee: 0,
    transport_fee: 0,
    meal_fee: 0,
    activity_fee: 0,
    library_fee: 0,
    computer_fee: 0,
    medical_fee: 0,
    development_fee: 0,
    exam_fee: 0,
    uniform_fee: 0,
    misc_fee: 0,
    is_active: true,
    is_default: false,
  });

  const [selectedClasses, setSelectedClasses] = useState<string[]>([]);

  // Fetch classes
  const { data: classOptions = [] } = useQuery({
    queryKey: ['class-streams'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('class_streams')
        .select('id, full_name, class_level, stream_name')
        .order('class_level', { ascending: true });
      if (error) throw error;
      return data;
    }
  });

  // Load editing data
  useEffect(() => {
    if (editingStructure) {
      setFormData({
        name: editingStructure.name || '',
        description: editingStructure.description || '',
        class_level: editingStructure.class_level || '',
        academic_year: editingStructure.academic_year || new Date().getFullYear().toString(),
        academic_term: editingStructure.academic_term || 'Term 1',
        boarding_status: editingStructure.boarding_status || 'Both',
        tuition_fee: Number(editingStructure.tuition_fee || 0),
        boarding_fee: Number(editingStructure.boarding_fee || 0),
        transport_fee: Number(editingStructure.transport_fee || 0),
        meal_fee: Number(editingStructure.meal_fee || 0),
        activity_fee: Number(editingStructure.activity_fee || 0),
        library_fee: Number(editingStructure.library_fee || 0),
        computer_fee: Number(editingStructure.computer_fee || 0),
        medical_fee: Number(editingStructure.medical_fee || 0),
        development_fee: Number(editingStructure.development_fee || 0),
        exam_fee: Number(editingStructure.exam_fee || 0),
        uniform_fee: Number(editingStructure.uniform_fee || 0),
        misc_fee: Number(editingStructure.misc_fee || 0),
        is_active: editingStructure.is_active ?? true,
        is_default: editingStructure.is_default ?? false,
      });

      // Load assigned classes
      const loadAssignedClasses = async () => {
        const { data, error } = await supabase
          .from('fee_structure_classes')
          .select('class_streams!inner(full_name)')
          .eq('fee_structure_id', editingStructure.id);
        
        if (!error && data) {
          setSelectedClasses(data.map(item => item.class_streams.full_name));
        }
      };
      loadAssignedClasses();
    }
  }, [editingStructure]);

  const createOrUpdateStructure = useMutation({
    mutationFn: async (data: any) => {
      if (editingStructure) {
        // Update existing structure
        const { error } = await supabase
          .from('fee_structures')
          .update(data)
          .eq('id', editingStructure.id);
        if (error) throw error;
        return editingStructure.id;
      } else {
        // Create new structure
        const { data: newStructure, error } = await supabase
          .from('fee_structures')
          .insert(data)
          .select()
          .single();
        if (error) throw error;
        return newStructure.id;
      }
    },
    onSuccess: async (structureId) => {
      // Update class assignments
      if (selectedClasses.length > 0) {
        // Delete existing assignments
        await supabase
          .from('fee_structure_classes')
          .delete()
          .eq('fee_structure_id', structureId);

        // Get class IDs
        const { data: classes } = await supabase
          .from('class_streams')
          .select('id, full_name')
          .in('full_name', selectedClasses);

        if (classes) {
          const assignments = classes.map(cls => ({
            fee_structure_id: structureId,
            class_id: cls.id
          }));

          await supabase
            .from('fee_structure_classes')
            .insert(assignments);
        }
      }

      toast({
        title: "Success",
        description: editingStructure ? "Fee structure updated successfully" : "Fee structure created successfully"
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save fee structure",
        variant: "destructive"
      });
    }
  });

  const handleClassToggle = (className: string) => {
    setSelectedClasses(
      selectedClasses.includes(className)
        ? selectedClasses.filter(c => c !== className)
        : [...selectedClasses, className]
    );
  };

  const calculateTotal = () => {
    return Object.keys(formData)
      .filter(key => key.includes('_fee'))
      .reduce((total, key) => total + Number(formData[key] || 0), 0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    createOrUpdateStructure.mutate(formData);
  };

  const feeFields = [
    { key: 'tuition_fee', label: 'Tuition Fee', required: true },
    { key: 'boarding_fee', label: 'Boarding Fee' },
    { key: 'transport_fee', label: 'Transport Fee' },
    { key: 'meal_fee', label: 'Meal Fee' },
    { key: 'activity_fee', label: 'Activity Fee' },
    { key: 'library_fee', label: 'Library Fee' },
    { key: 'computer_fee', label: 'Computer Fee' },
    { key: 'medical_fee', label: 'Medical Fee' },
    { key: 'development_fee', label: 'Development Fee' },
    { key: 'exam_fee', label: 'Exam Fee' },
    { key: 'uniform_fee', label: 'Uniform Fee' },
    { key: 'misc_fee', label: 'Miscellaneous Fee' }
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto m-4">
        <Card className="bg-white border-gray-200">
          <CardHeader className="bg-gray-50 border-b flex flex-row items-center justify-between">
            <CardTitle className="text-gray-900">
              {editingStructure ? 'Edit Fee Structure' : 'Create New Fee Structure'}
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name" className="text-gray-700">Structure Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="e.g., Primary School Term 1 Fees"
                    required
                    className="bg-white border-gray-300"
                  />
                </div>
                <div>
                  <Label htmlFor="class_level" className="text-gray-700">Class Level</Label>
                  <Input
                    id="class_level"
                    value={formData.class_level}
                    onChange={(e) => setFormData({...formData, class_level: e.target.value})}
                    placeholder="e.g., Primary 1-3, Secondary 1-4"
                    className="bg-white border-gray-300"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description" className="text-gray-700">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Brief description of this fee structure"
                  className="bg-white border-gray-300"
                />
              </div>

              {/* Academic Period */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="academic_year" className="text-gray-700">Academic Year *</Label>
                  <Input
                    id="academic_year"
                    value={formData.academic_year}
                    onChange={(e) => setFormData({...formData, academic_year: e.target.value})}
                    required
                    className="bg-white border-gray-300"
                  />
                </div>
                <div>
                  <Label htmlFor="academic_term" className="text-gray-700">Academic Term *</Label>
                  <Select 
                    value={formData.academic_term} 
                    onValueChange={(value) => setFormData({...formData, academic_term: value})}
                  >
                    <SelectTrigger className="bg-white border-gray-300">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-gray-300">
                      <SelectItem value="Term 1">Term 1</SelectItem>
                      <SelectItem value="Term 2">Term 2</SelectItem>
                      <SelectItem value="Term 3">Term 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="boarding_status" className="text-gray-700">Boarding Status</Label>
                  <Select 
                    value={formData.boarding_status} 
                    onValueChange={(value) => setFormData({...formData, boarding_status: value})}
                  >
                    <SelectTrigger className="bg-white border-gray-300">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-gray-300">
                      <SelectItem value="Both">Both Day & Boarding</SelectItem>
                      <SelectItem value="Day">Day Students Only</SelectItem>
                      <SelectItem value="Boarding">Boarding Students Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Class Selection */}
              <div>
                <Label className="text-gray-700 block mb-3">Assign to Classes</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 max-h-48 overflow-y-auto p-4 border border-gray-300 rounded-md bg-gray-50">
                  {classOptions.map((classOption) => (
                    <label key={classOption.id} className="flex items-center space-x-2 cursor-pointer">
                      <Checkbox
                        checked={selectedClasses.includes(classOption.full_name)}
                        onCheckedChange={() => handleClassToggle(classOption.full_name)}
                      />
                      <span className="text-sm text-gray-700">{classOption.full_name}</span>
                    </label>
                  ))}
                </div>
                {selectedClasses.length > 0 && (
                  <p className="text-sm text-gray-600 mt-2">
                    Selected: {selectedClasses.join(', ')}
                  </p>
                )}
              </div>

              {/* Fee Components */}
              <div>
                <Label className="text-gray-700 text-lg font-semibold block mb-4">Fee Components (UGX)</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {feeFields.map((field) => (
                    <div key={field.key}>
                      <Label htmlFor={field.key} className="text-gray-700">
                        {field.label} {field.required && '*'}
                      </Label>
                      <Input
                        id={field.key}
                        type="number"
                        min="0"
                        step="0.01"
                        value={formData[field.key]}
                        onChange={(e) => setFormData({
                          ...formData, 
                          [field.key]: parseFloat(e.target.value) || 0
                        })}
                        required={field.required}
                        className="bg-white border-gray-300"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Status Switches */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
                  />
                  <Label htmlFor="is_active" className="text-gray-700">Active Structure</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_default"
                    checked={formData.is_default}
                    onCheckedChange={(checked) => setFormData({...formData, is_default: checked})}
                  />
                  <Label htmlFor="is_default" className="text-gray-700">Set as Default</Label>
                </div>
              </div>

              {/* Total Display */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold text-gray-700">Total Fee Structure:</span>
                  <span className="text-2xl font-bold text-blue-600">
                    UGX {calculateTotal().toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button 
                  type="submit" 
                  disabled={createOrUpdateStructure.isPending}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6"
                >
                  {createOrUpdateStructure.isPending 
                    ? 'Saving...' 
                    : editingStructure ? 'Update Structure' : 'Create Structure'
                  }
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onClose}
                  className="border-gray-300 text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FeeStructureFormModal;
