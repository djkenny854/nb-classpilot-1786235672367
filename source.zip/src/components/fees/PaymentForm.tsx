
import React, { useState, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Student } from '@/types';
import { CreditCard, Search, Clock, AlertCircle } from 'lucide-react';
import { recordFeePayment, getStudentFeesSummary, getStudentPaymentHistory } from '@/utils/feePaymentHelpers';
import { format } from 'date-fns';

const paymentSchema = z.object({
  studentId: z.string().min(1, { message: "Student is required" }),
  amount: z.coerce.number().positive({ message: "Amount must be greater than 0" }),
  method: z.enum(['Cash', 'Mobile Money', 'Bank Transfer', 'Card', 'Other'], { 
    required_error: "Payment method is required"
  }),
  description: z.string().min(3, { message: "Description is required" }),
  academicTerm: z.string().min(1, { message: "Academic term is required" }),
  academicYear: z.string().min(1, { message: "Academic year is required" }),
});

type PaymentFormValues = z.infer<typeof paymentSchema>;

interface PaymentFormProps {
  students: Student[];
  onPaymentComplete?: () => void;
  selectedStudentId?: string;
  onSuccess?: () => void;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ 
  students, 
  onPaymentComplete,
  selectedStudentId,
  onSuccess
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [studentFeesInfo, setStudentFeesInfo] = useState<any>(null);
  const [lastPayment, setLastPayment] = useState<any>(null);
  const currentYear = new Date().getFullYear();

  const form = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      studentId: selectedStudentId || '',
      amount: undefined,
      method: 'Cash',
      description: 'School Fees Payment',
      academicTerm: 'Term 1',
      academicYear: `${currentYear}`,
    },
  });

  // Filter students based on search term
  const filteredStudents = useMemo(() => {
    if (!searchTerm) return students;
    
    return students.filter(student => {
      const name = student.name || '';
      const studentId = student.enrollmentNumber || '';
      const className = student.className || '';
      
      return name.toLowerCase().includes(searchTerm.toLowerCase()) ||
             studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
             className.toLowerCase().includes(searchTerm.toLowerCase());
    });
  }, [students, searchTerm]);

  // Find the selected student
  const selectedStudent = form.watch('studentId') 
    ? students.find(student => student.id === form.watch('studentId'))
    : null;

  // Load student fees info and last payment when student is selected
  React.useEffect(() => {
    const loadStudentData = async () => {
      if (selectedStudent) {
        try {
          // Get fees summary
          const feesData = await getStudentFeesSummary(
            selectedStudent.id,
            form.watch('academicYear'),
            form.watch('academicTerm')
          );
          setStudentFeesInfo(feesData[0] || null);

          // Get last payment
          const paymentHistory = await getStudentPaymentHistory(selectedStudent.id, 1);
          setLastPayment(paymentHistory[0] || null);
        } catch (error) {
          console.error('Error loading student data:', error);
        }
      } else {
        setStudentFeesInfo(null);
        setLastPayment(null);
      }
    };

    loadStudentData();
  }, [selectedStudent, form.watch('academicYear'), form.watch('academicTerm')]);

  const onSubmit = async (values: PaymentFormValues) => {
    try {
      setIsSubmitting(true);
      
      if (!selectedStudent) {
        throw new Error("Selected student not found");
      }
      
      console.log('Payment form values:', values);

      // Record the fee payment using the new fee system
      const payment = await recordFeePayment(values.studentId, {
        amount: values.amount,
        paymentMethod: values.method,
        notes: values.description,
        academicYear: values.academicYear,
        academicTerm: values.academicTerm,
      });
      
      console.log('Payment recorded:', payment);
      
      // Show success message
      toast.success('Payment recorded successfully', {
        description: `UGX ${values.amount.toLocaleString()} received from ${selectedStudent.name}.`
      });
      
      // Reset form
      form.reset();
      setSearchTerm('');
      setStudentFeesInfo(null);
      setLastPayment(null);
      
      // Call the appropriate callback
      if (onPaymentComplete) {
        onPaymentComplete();
      }
      
      if (onSuccess) {
        onSuccess();
      }
      
    } catch (error) {
      console.error('Error recording payment:', error);
      toast.error('Failed to record payment', { 
        description: error instanceof Error ? error.message : 'Unknown error occurred'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full border-0 rounded-xl shadow-sm">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-slate-800 dark:to-slate-700 rounded-t-xl">
        <CardTitle className="flex items-center">
          <div className="p-2 mr-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
            <CreditCard className="h-5 w-5 text-primary" />
          </div>
          Record Student Payment
        </CardTitle>
      </CardHeader>
      <CardContent className="mt-4">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="studentId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Student*</FormLabel>
                  <div className="space-y-2">
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search students..."
                        className="pl-8"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                      value={field.value}
                      disabled={!!selectedStudentId}
                    >
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="Select student" />
                      </SelectTrigger>
                      <SelectContent>
                        {filteredStudents.map((student) => (
                          <SelectItem key={student.id} value={student.id}>
                            {student.name} ({student.enrollmentNumber}) - {student.className}
                          </SelectItem>
                        ))}
                        {filteredStudents.length === 0 && searchTerm && (
                          <div className="p-2 text-sm text-muted-foreground">
                            No students found matching "{searchTerm}"
                          </div>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {selectedStudent && (
              <div className="space-y-4">
                {/* Student Fee Information */}
                {studentFeesInfo && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Assigned</p>
                      <p className="text-lg font-semibold text-blue-600">UGX {(studentFeesInfo.total_assigned_fees || 0).toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Paid</p>
                      <p className="text-lg font-semibold text-green-600">UGX {(studentFeesInfo.total_paid || 0).toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Balance Due</p>
                      <p className="text-lg font-semibold text-destructive">
                        UGX {((studentFeesInfo.total_assigned_fees || 0) - (studentFeesInfo.total_paid || 0)).toLocaleString()}
                      </p>
                    </div>
                  </div>
                )}

                {/* Last Payment Information */}
                {lastPayment ? (
                  <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Last Payment
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <strong>Amount:</strong> UGX {lastPayment.amount.toLocaleString()}
                      </div>
                      <div>
                        <strong>Date:</strong> {format(new Date(lastPayment.payment_date), 'MMM dd, yyyy')}
                      </div>
                      <div>
                        <strong>Method:</strong> {lastPayment.payment_method}
                      </div>
                    </div>
                    {lastPayment.receipt_number && (
                      <div className="text-sm mt-2">
                        <strong>Receipt:</strong> {lastPayment.receipt_number}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-xl">
                    <div className="flex items-center gap-2 text-yellow-700 dark:text-yellow-300">
                      <AlertCircle className="h-4 w-4" />
                      <span className="text-sm font-medium">No previous payments found for this student</span>
                    </div>
                  </div>
                )}

                {/* Student Details */}
                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Boarding Status</p>
                      <p className="font-medium">{selectedStudent.boardingStatus || 'Day'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Transport</p>
                      <p className="font-medium">{selectedStudent.transportUse || 'No'}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (UGX)*</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="Enter amount" className="h-11" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="method"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Method*</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="Select method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Cash">Cash</SelectItem>
                        <SelectItem value="Mobile Money">Mobile Money</SelectItem>
                        <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                        <SelectItem value="Card">Card</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="academicTerm"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Academic Term*</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="Select term" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Term 1">Term 1</SelectItem>
                        <SelectItem value="Term 2">Term 2</SelectItem>
                        <SelectItem value="Term 3">Term 3</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="academicYear"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Academic Year*</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="Select year" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={`${currentYear-1}`}>
                          {currentYear-1}
                        </SelectItem>
                        <SelectItem value={`${currentYear}`}>
                          {currentYear}
                        </SelectItem>
                        <SelectItem value={`${currentYear+1}`}>
                          {currentYear+1}
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description*</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Enter payment description" 
                      className="min-h-[80px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end">
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="px-6 h-11 rounded-full"
              >
                {isSubmitting ? "Processing..." : "Record Payment"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default PaymentForm;
