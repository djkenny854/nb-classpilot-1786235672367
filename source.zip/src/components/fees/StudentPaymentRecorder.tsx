
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Plus, DollarSign, RefreshCw, Download, Users, TrendingUp } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import PaymentModal from './PaymentModal';
import EnhancedPaymentSkeleton from './EnhancedPaymentSkeleton';

const StudentPaymentRecorder = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [classFilter, setClassFilter] = useState('all');
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const { toast } = useToast();

  // Fetch students with their fee information
  const { data: studentsWithFees, isLoading, refetch } = useQuery({
    queryKey: ['students-with-fees', searchTerm, statusFilter, classFilter],
    queryFn: async () => {
      console.log('Fetching students with fees...');
      
      let query = supabase
        .from('student_fees')
        .select(`
          *,
          students!inner(
            id,
            full_name,
            student_id,
            class,
            boarding_status,
            transport
          )
        `)
        .order('created_at', { ascending: false });

      if (searchTerm) {
        query = query.ilike('students.full_name', `%${searchTerm}%`);
      }

      if (statusFilter !== 'all') {
        query = query.eq('payment_status', statusFilter);
      }

      if (classFilter !== 'all') {
        query = query.eq('students.class', classFilter);
      }

      const { data, error } = await query;
      if (error) {
        console.error('Error fetching students with fees:', error);
        throw error;
      }
      
      console.log('Students with fees:', data);
      return data || [];
    }
  });

  // Get unique classes for filter
  const uniqueClasses = React.useMemo(() => {
    if (!studentsWithFees) return [];
    const classes = [...new Set(studentsWithFees.map(sf => sf.students?.class).filter(Boolean))];
    return classes.sort();
  }, [studentsWithFees]);

  // Calculate summary stats
  const summaryStats = React.useMemo(() => {
    if (!studentsWithFees) return { total: 0, paid: 0, partial: 0, unpaid: 0, totalRequired: 0, totalPaid: 0 };
    
    return studentsWithFees.reduce((acc, sf) => ({
      total: acc.total + 1,
      paid: acc.paid + (sf.payment_status === 'Paid' ? 1 : 0),
      partial: acc.partial + (sf.payment_status === 'Partial' ? 1 : 0),
      unpaid: acc.unpaid + (sf.payment_status === 'Unpaid' ? 1 : 0),
      totalRequired: acc.totalRequired + (sf.total_assigned_fees || 0),
      totalPaid: acc.totalPaid + (sf.total_paid || 0)
    }), { total: 0, paid: 0, partial: 0, unpaid: 0, totalRequired: 0, totalPaid: 0 });
  }, [studentsWithFees]);

  const handleAddPayment = (studentFee) => {
    console.log('Adding payment for student fee:', studentFee);
    setSelectedStudent(studentFee);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentSuccess = () => {
    refetch();
    setIsPaymentModalOpen(false);
    setSelectedStudent(null);
    toast({
      title: "Success",
      description: "Payment recorded successfully"
    });
  };

  const exportData = () => {
    if (!studentsWithFees) return;
    
    const csvData = studentsWithFees.map(sf => ({
      'Student Name': sf.students?.full_name,
      'Student ID': sf.students?.student_id,
      'Class': sf.students?.class,
      'Total Required': sf.total_assigned_fees,
      'Total Paid': sf.total_paid,
      'Balance': (sf.total_assigned_fees || 0) - (sf.total_paid || 0),
      'Status': sf.payment_status,
      'Academic Year': sf.academic_year,
      'Academic Term': sf.academic_term
    }));
    
    const csvContent = [
      Object.keys(csvData[0]).join(','),
      ...csvData.map(row => Object.values(row).join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'student_payments.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Paid': return 'bg-green-500/20 text-green-500 border-green-500/30';
      case 'Partial': return 'bg-blue-500/20 text-blue-500 border-blue-500/30';
      case 'Unpaid': return 'bg-red-500/20 text-red-500 border-red-500/30';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getPaymentProgress = (totalPaid, totalRequired) => {
    if (totalRequired === 0) return 0;
    return Math.min((totalPaid / totalRequired) * 100, 100);
  };

  if (isLoading) {
    return <EnhancedPaymentSkeleton />;
  }

  const collectionRate = summaryStats.total > 0 ? (summaryStats.totalPaid / summaryStats.totalRequired) * 100 : 0;

  return (
    <div className="space-y-4">
      {/* Summary Stats Cards - Compact */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="bg-card border-border">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground truncate">Students</p>
                <p className="text-lg sm:text-xl font-bold text-foreground">{summaryStats.total}</p>
              </div>
              <Users className="h-6 w-6 text-primary flex-shrink-0" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground truncate">Collection</p>
                <p className="text-lg sm:text-xl font-bold text-green-500">{collectionRate.toFixed(0)}%</p>
              </div>
              <TrendingUp className="h-6 w-6 text-green-500 flex-shrink-0" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground truncate">Collected</p>
                <p className="text-sm sm:text-base font-bold text-green-500 truncate">UGX {summaryStats.totalPaid.toLocaleString()}</p>
              </div>
              <DollarSign className="h-6 w-6 text-green-500 flex-shrink-0" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground truncate">Outstanding</p>
                <p className="text-sm sm:text-base font-bold text-destructive truncate">UGX {(summaryStats.totalRequired - summaryStats.totalPaid).toLocaleString()}</p>
              </div>
              <DollarSign className="h-6 w-6 text-destructive flex-shrink-0" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Payment Recorder Card */}
      <Card className="bg-card border-border">
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 px-4 sm:px-6 pb-3">
          <CardTitle className="flex items-center gap-2 text-foreground text-base">
            <DollarSign className="h-4 w-4" />
            Record Payments
          </CardTitle>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Button 
              onClick={exportData}
              variant="outline"
              size="sm"
              className="flex-1 sm:flex-none"
            >
              <Download className="h-4 w-4" />
            </Button>
            <Button 
              onClick={() => refetch()}
              variant="outline"
              size="sm"
              className="flex-1 sm:flex-none"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3 px-3 sm:px-6">
          {/* Filters Row - Stack on mobile */}
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search students..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-secondary border-border text-foreground"
                />
              </div>
            </div>
            
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-32 bg-secondary border-border">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="Unpaid">Unpaid</SelectItem>
                  <SelectItem value="Partial">Partial</SelectItem>
                  <SelectItem value="Paid">Paid</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={classFilter} onValueChange={setClassFilter}>
                <SelectTrigger className="w-full sm:w-32 bg-secondary border-border">
                  <SelectValue placeholder="Class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  {uniqueClasses.map(className => (
                    <SelectItem key={className} value={className}>
                      {className}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Status Summary Badges - Compact */}
          <div className="flex flex-wrap gap-2 text-xs">
            <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/30">
              Paid: {summaryStats.paid}
            </Badge>
            <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/30">
              Partial: {summaryStats.partial}
            </Badge>
            <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/30">
              Unpaid: {summaryStats.unpaid}
            </Badge>
          </div>

          {/* Students List - Compact cards */}
          <div className="space-y-2">
            {!studentsWithFees || studentsWithFees.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <p>No students found with assigned fees</p>
                <p className="text-sm mt-2">Assign fee structures to students first</p>
                <Button 
                  onClick={() => refetch()}
                  className="mt-4"
                  variant="outline"
                  size="sm"
                >
                  Refresh
                </Button>
              </div>
            ) : (
              studentsWithFees.map((studentFee) => {
                const student = studentFee.students;
                const balance = (studentFee.total_assigned_fees || 0) - (studentFee.total_paid || 0);
                const progress = getPaymentProgress(studentFee.total_paid || 0, studentFee.total_assigned_fees || 0);
                
                return (
                  <div key={studentFee.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 border border-border rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors gap-3">
                    <div className="flex-1 min-w-0 w-full">
                      {/* Header row */}
                      <div className="flex flex-wrap items-center gap-1.5 mb-2">
                        <h3 className="font-semibold text-sm text-foreground truncate">{student.full_name}</h3>
                        <Badge className={`${getStatusColor(studentFee.payment_status)} text-[10px]`}>
                          {studentFee.payment_status}
                        </Badge>
                        <Badge variant="outline" className="text-[10px]">{student.class}</Badge>
                      </div>
                      
                      {/* Stats row - Compact */}
                      <div className="grid grid-cols-3 gap-2 text-[10px] sm:text-xs text-muted-foreground mb-2">
                        <span className="truncate">Req: UGX {(studentFee.total_assigned_fees || 0).toLocaleString()}</span>
                        <span className="truncate">Paid: UGX {(studentFee.total_paid || 0).toLocaleString()}</span>
                        <span className={`font-medium truncate ${balance > 0 ? 'text-destructive' : 'text-green-500'}`}>
                          Bal: UGX {balance.toLocaleString()}
                        </span>
                      </div>
                      
                      {/* Progress Bar */}
                      <div className="w-full bg-muted rounded-full h-1.5">
                        <div 
                          className={`h-1.5 rounded-full transition-all duration-300 ${
                            progress === 100 ? 'bg-green-500' :
                            progress > 50 ? 'bg-blue-500' :
                            progress > 0 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => handleAddPayment(studentFee)}
                      disabled={balance <= 0}
                      size="sm"
                      className="bg-green-600 hover:bg-green-700 w-full sm:w-auto text-xs"
                    >
                      <Plus className="h-3.5 w-3.5 mr-1" />
                      Pay
                    </Button>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>

      {/* Payment Modal */}
      {selectedStudent && (
        <PaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          studentFee={selectedStudent}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  );
};

export default StudentPaymentRecorder;
