
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Settings, Save, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useSiteSettings } from '@/context/SiteSettingsContext';

const FeeSettings = () => {
  const { settings } = useSiteSettings();
  const [isSaving, setIsSaving] = useState(false);
  const [feeSettings, setFeeSettings] = useState({
    defaultTuitionFee: 500000,
    boardingFee: 300000,
    transportFee: 50000,
    activitiesFee: 25000,
    latePenaltyRate: 10,
    autoReminders: true,
    reminderDays: 7,
    academicYear: '2024',
    currentTerm: 'Term 1'
  });

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // In a real implementation, this would save to Supabase
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('Saving fee settings:', feeSettings);
      toast.success('Fee settings saved successfully');
    } catch (error) {
      console.error('Error saving fee settings:', error);
      toast.error('Failed to save fee settings');
    } finally {
      setIsSaving(false);
    }
  };

  const handleInputChange = (field: string, value: any) => {
    setFeeSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Fee Structure Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Default Tuition Fee ({settings.currency})</Label>
              <Input
                type="number"
                value={feeSettings.defaultTuitionFee}
                onChange={(e) => handleInputChange('defaultTuitionFee', parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div className="space-y-2">
              <Label>Boarding Fee ({settings.currency})</Label>
              <Input
                type="number"
                value={feeSettings.boardingFee}
                onChange={(e) => handleInputChange('boardingFee', parseInt(e.target.value) || 0)}
              />
            </div>

            <div className="space-y-2">
              <Label>Transport Fee ({settings.currency})</Label>
              <Input
                type="number"
                value={feeSettings.transportFee}
                onChange={(e) => handleInputChange('transportFee', parseInt(e.target.value) || 0)}
              />
            </div>

            <div className="space-y-2">
              <Label>Activities Fee ({settings.currency})</Label>
              <Input
                type="number"
                value={feeSettings.activitiesFee}
                onChange={(e) => handleInputChange('activitiesFee', parseInt(e.target.value) || 0)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Academic Year Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Current Academic Year</Label>
              <Select 
                value={feeSettings.academicYear || "2024"} 
                onValueChange={(value) => handleInputChange('academicYear', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select academic year" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024">2024</SelectItem>
                  <SelectItem value="2025">2025</SelectItem>
                  <SelectItem value="2026">2026</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Current Term</Label>
              <Select 
                value={feeSettings.currentTerm || "term-1"} 
                onValueChange={(value) => handleInputChange('currentTerm', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select current term" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="term-1">Term 1</SelectItem>
                  <SelectItem value="term-2">Term 2</SelectItem>
                  <SelectItem value="term-3">Term 3</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Payment & Reminder Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Enable Automatic Reminders</Label>
            <Switch
              checked={feeSettings.autoReminders}
              onCheckedChange={(checked) => handleInputChange('autoReminders', checked)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Late Payment Penalty (%)</Label>
              <Input
                type="number"
                value={feeSettings.latePenaltyRate}
                onChange={(e) => handleInputChange('latePenaltyRate', parseInt(e.target.value) || 0)}
                min="0"
                max="100"
              />
            </div>

            <div className="space-y-2">
              <Label>Reminder Days Before Due Date</Label>
              <Input
                type="number"
                value={feeSettings.reminderDays}
                onChange={(e) => handleInputChange('reminderDays', parseInt(e.target.value) || 0)}
                min="1"
                max="30"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Button 
        onClick={handleSave} 
        className="w-full"
        disabled={isSaving}
      >
        {isSaving ? (
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
        ) : (
          <Save className="h-4 w-4 mr-2" />
        )}
        {isSaving ? 'Saving...' : 'Save Settings'}
      </Button>
    </div>
  );
};

export default FeeSettings;
