
import React from "react";
import { useQuery } from "@tanstack/react-query";
import { getDashboardFinanceStats, getRecentFeeTransactions, getAllActiveStudents } from "@/utils/feesService";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Users, DollarSign, Activity } from "lucide-react";

export default function FinanceDashboard({ onViewStudent }: { onViewStudent: (id: string) => void }) {
  const { data: stats } = useQuery({ queryKey: ["finance_stats"], queryFn: getDashboardFinanceStats });
  const { data: recent = [] } = useQuery({ queryKey: ["recent_fee_transactions"], queryFn: getRecentFeeTransactions });
  const { data: students = [] } = useQuery({ queryKey: ["all_students"], queryFn: getAllActiveStudents });

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>
              <DollarSign className="inline w-5 h-5 mr-2 text-green-500" />
              <span>Total Collected</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{Number(stats?.collected || 0).toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>
              <Activity className="inline w-5 h-5 mr-2 text-yellow-500" />
              <span>Outstanding</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{Number(stats?.outstanding || 0).toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>
              <Users className="inline w-5 h-5 mr-2 text-blue-500" />
              <span>Students</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{students.length}</div>
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <table className="w-full">
            <thead><tr><th>Date</th><th>Student</th><th>Amount</th></tr></thead>
            <tbody>
              {recent.length ? recent.map(txn => (
                <tr key={txn.id} className="border-t">
                  <td>{txn.payment_date?.slice(0, 10)}</td>
                  <td>
                    <button className="underline text-blue-600" onClick={() => onViewStudent && onViewStudent(txn.student_id)}>
                      {txn.student_name || "-"}
                    </button>
                  </td>
                  <td>{Number(txn.amount).toLocaleString()}</td>
                </tr>
              )) : <tr><td colSpan={3}>No transactions</td></tr>}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  )
}
