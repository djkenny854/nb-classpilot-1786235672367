
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, DollarSign, User, Calendar, CreditCard } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface PaymentConfirmationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  paymentData: {
    studentName: string;
    amount: number;
    method: string;
    notes?: string;
  };
  isProcessing?: boolean;
}

const PaymentConfirmationDialog: React.FC<PaymentConfirmationDialogProps> = ({
  open,
  onOpenChange,
  onConfirm,
  paymentData,
  isProcessing = false
}) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-orange-600">
            <AlertTriangle className="h-5 w-5" />
            Confirm Payment
          </DialogTitle>
        </DialogHeader>

        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-4 space-y-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600 mb-2">
                UGX {paymentData.amount.toLocaleString()}
              </div>
              <Badge variant="outline" className="text-orange-700 border-orange-300">
                Payment Confirmation Required
              </Badge>
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-3">
                <User className="h-4 w-4 text-gray-500" />
                <div>
                  <span className="text-gray-600">Student:</span>
                  <span className="ml-2 font-medium">{paymentData.studentName}</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <DollarSign className="h-4 w-4 text-gray-500" />
                <div>
                  <span className="text-gray-600">Amount:</span>
                  <span className="ml-2 font-bold text-green-600">
                    UGX {paymentData.amount.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <CreditCard className="h-4 w-4 text-gray-500" />
                <div>
                  <span className="text-gray-600">Method:</span>
                  <span className="ml-2 font-medium">{paymentData.method}</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Calendar className="h-4 w-4 text-gray-500" />
                <div>
                  <span className="text-gray-600">Date:</span>
                  <span className="ml-2 font-medium">
                    {new Date().toLocaleDateString()}
                  </span>
                </div>
              </div>

              {paymentData.notes && (
                <div className="pt-2 border-t border-orange-200">
                  <span className="text-gray-600">Notes:</span>
                  <p className="mt-1 text-gray-800 font-medium">{paymentData.notes}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          <div className="flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-yellow-600 mt-0.5" />
            <div className="text-sm text-yellow-800">
              <p className="font-medium">Please confirm this payment</p>
              <p>This action cannot be undone. Make sure all details are correct.</p>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            disabled={isProcessing}
          >
            Cancel
          </Button>
          <Button 
            onClick={onConfirm}
            disabled={isProcessing}
            className="bg-green-600 hover:bg-green-700"
          >
            {isProcessing ? 'Processing...' : 'Confirm Payment'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentConfirmationDialog;
