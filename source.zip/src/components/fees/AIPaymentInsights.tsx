
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, Lightbulb, TrendingUp, AlertCircle, Sparkles } from 'lucide-react';

interface AIPaymentInsightsProps {
  studentFee: any;
  onSuggestionApply: (amount: number) => void;
}

interface SmartSuggestion {
  amount: number;
  label: string;
  description: string;
  confidence: 'high' | 'medium' | 'low';
  reason: string;
}

const AIPaymentInsights: React.FC<AIPaymentInsightsProps> = ({ studentFee, onSuggestionApply }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [smartSuggestions, setSmartSuggestions] = useState<SmartSuggestion[]>([]);
  const [aiInsight, setAiInsight] = useState('');
  const [animatedText, setAnimatedText] = useState('');

  const student = studentFee?.students;
  const balance = (studentFee?.total_assigned_fees || 0) - (studentFee?.total_paid || 0);

  useEffect(() => {
    generateAIAnalysis();
  }, [studentFee]);

  const generateAIAnalysis = () => {
    setIsAnalyzing(true);
    setAnimatedText('');
    
    // Simulate AI analysis with realistic timing
    setTimeout(() => {
      const suggestions = generateSmartSuggestions();
      setSmartSuggestions(suggestions);
      
      const insight = generatePersonalizedInsight();
      setAiInsight(insight);
      animateInsightText(insight);
      
      setIsAnalyzing(false);
    }, 2500);
  };

  const generateSmartSuggestions = (): SmartSuggestion[] => {
    const suggestions: SmartSuggestion[] = [];
    
    // Full payment - always highest confidence for outstanding balances
    if (balance > 0) {
      suggestions.push({
        amount: balance,
        label: 'Complete Settlement',
        description: 'Clear all outstanding fees',
        confidence: 'high',
        reason: 'Eliminates all debt and improves student standing'
      });
    }

    // Strategic partial payments based on AI analysis
    if (balance > 100000) {
      // 60% payment - optimal for large balances
      suggestions.push({
        amount: Math.round(balance * 0.6),
        label: 'Strategic 60%',
        description: 'Substantial progress payment',
        confidence: 'high',
        reason: 'Significantly reduces debt burden while remaining manageable'
      });

      // Monthly installment suggestion
      const monthlyInstallment = Math.round(balance / 3);
      suggestions.push({
        amount: monthlyInstallment,
        label: '3-Month Plan',
        description: 'First of three installments',
        confidence: 'medium',
        reason: 'Spreads payment over manageable periods'
      });
    }

    // Smart round amounts based on common payment patterns
    const smartAmounts = [50000, 100000, 200000, 300000, 500000]
      .filter(amt => amt < balance && amt >= balance * 0.1);
    
    smartAmounts.slice(0, 2).forEach(amount => {
      suggestions.push({
        amount,
        label: `UGX ${amount.toLocaleString()}`,
        description: 'Common payment amount',
        confidence: 'low',
        reason: 'Round figure, easy to process'
      });
    });

    return suggestions.slice(0, 4);
  };

  const generatePersonalizedInsight = (): string => {
    const paymentRatio = balance > 0 ? (studentFee?.total_paid || 0) / (studentFee?.total_assigned_fees || 1) : 1;
    
    const insights = [
      `${student?.full_name} has paid ${(paymentRatio * 100).toFixed(1)}% of required fees. ${
        paymentRatio > 0.7 ? 'Excellent progress! Consider completing the balance.' : 
        paymentRatio > 0.4 ? 'Good progress. A strategic payment could improve standing significantly.' :
        'Early in payment cycle. Consider setting up a structured payment plan.'
      }`,
      
      `Based on payment patterns, students in ${student?.class} typically benefit from ${
        balance > 300000 ? 'installment plans rather than lump sum payments' :
        balance > 100000 ? 'bi-monthly payment schedules' :
        'single payment settlements'
      }.`,
      
      `Financial insight: ${
        studentFee?.payment_status === 'Unpaid' ? 'Priority payment recommended to avoid late fees and maintain good standing.' :
        studentFee?.payment_status === 'Partial' ? 'Momentum is building. Consider accelerating payments to reach full settlement.' :
        'Account in excellent standing. Consider this student as a payment model for others.'
      }`,
      
      `Smart recommendation: ${
        student?.boarding_status === 'Boarding' ? 'Boarding students benefit from consistent payment schedules to ensure uninterrupted accommodation.' :
        student?.transport === 'Yes' ? 'Transport fee components can be prioritized for continued service.' :
        'Day student payments can be more flexible but consistency helps academic focus.'
      }`
    ];
    
    return insights[Math.floor(Math.random() * insights.length)];
  };

  const animateInsightText = (text: string) => {
    let index = 0;
    const animateChar = () => {
      if (index < text.length) {
        setAnimatedText(text.slice(0, index + 1));
        index++;
        setTimeout(animateChar, 30);
      }
    };
    animateChar();
  };

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'high': return 'bg-green-100 text-green-700 border-green-200';
      case 'medium': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  if (isAnalyzing) {
    return (
      <div className="space-y-4">
        <Card className="border-purple-200 bg-gradient-to-r from-purple-50 to-indigo-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative">
                <Brain className="h-5 w-5 text-purple-600 animate-pulse" />
                <div className="absolute -inset-1 bg-purple-400/20 rounded-full animate-ping" />
              </div>
              <h3 className="font-semibold text-purple-800">AI Payment Analysis</h3>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-purple-700">
                <Sparkles className="h-3 w-3 animate-spin" />
                <span className="animate-pulse">Analyzing payment patterns...</span>
              </div>
              
              <div className="space-y-2">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-12 bg-white/50 rounded-lg animate-pulse flex items-center p-3">
                    <div className="h-2 bg-purple-200 rounded animate-pulse mr-3" style={{ width: `${Math.random() * 40 + 60}%` }} />
                    <div className="h-2 bg-purple-100 rounded animate-pulse" style={{ width: `${Math.random() * 20 + 20}%` }} />
                  </div>
                ))}
              </div>
              
              <div className="flex items-center gap-2 text-xs text-purple-600">
                <TrendingUp className="h-3 w-3" />
                <span>Processing {student?.full_name}'s financial profile...</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* AI Suggestions */}
      <Card className="border-purple-200 bg-gradient-to-r from-purple-50 to-indigo-50">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-4 w-4 text-purple-600" />
            <h3 className="font-semibold text-sm text-purple-800">Smart Payment Suggestions</h3>
          </div>
          
          <div className="space-y-2">
            {smartSuggestions.map((suggestion, index) => (
              <div
                key={index}
                onClick={() => onSuggestionApply(suggestion.amount)}
                className="group cursor-pointer p-3 bg-white/70 rounded-lg border border-purple-100 hover:bg-white hover:border-purple-200 hover:shadow-sm transition-all duration-200 animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-sm text-gray-900 group-hover:text-purple-700">
                    {suggestion.label}
                  </span>
                  <Badge 
                    variant="secondary" 
                    className={`text-xs ${getConfidenceColor(suggestion.confidence)}`}
                  >
                    {suggestion.confidence} confidence
                  </Badge>
                </div>
                <p className="text-xs text-gray-600 mb-1">{suggestion.description}</p>
                <p className="text-xs font-medium text-purple-600 mb-1">
                  UGX {suggestion.amount.toLocaleString()}
                </p>
                <p className="text-xs text-gray-500 italic">{suggestion.reason}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Insight */}
      <Card className="border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-2">
            <Lightbulb className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <h4 className="font-medium text-sm text-amber-800 mb-2">AI Financial Insight</h4>
              <p className="text-xs text-amber-700 leading-relaxed min-h-[3rem]">
                {animatedText}
                <span className="animate-pulse">|</span>
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AIPaymentInsights;
