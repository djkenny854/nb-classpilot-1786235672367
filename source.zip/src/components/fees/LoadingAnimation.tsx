
import React from 'react';
import { Loader2, Zap, Brain } from 'lucide-react';

interface LoadingAnimationProps {
  type?: 'payment' | 'ai' | 'data';
  message?: string;
}

const LoadingAnimation: React.FC<LoadingAnimationProps> = ({ 
  type = 'payment', 
  message 
}) => {
  const getIcon = () => {
    switch (type) {
      case 'ai':
        return <Brain className="h-6 w-6 text-purple-600 animate-pulse" />;
      case 'payment':
        return <Zap className="h-6 w-6 text-blue-600 animate-bounce" />;
      default:
        return <Loader2 className="h-6 w-6 text-gray-600 animate-spin" />;
    }
  };

  const getMessage = () => {
    if (message) return message;
    
    switch (type) {
      case 'ai':
        return 'AI analyzing payment patterns...';
      case 'payment':
        return 'Processing payment...';
      default:
        return 'Loading...';
    }
  };

  return (
    <div className="flex items-center justify-center p-8 space-x-3">
      <div className="relative">
        {getIcon()}
        <div className="absolute inset-0 animate-ping opacity-20">
          {getIcon()}
        </div>
      </div>
      <div className="text-gray-700 font-medium">
        {getMessage()}
      </div>
      <div className="flex space-x-1">
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
            style={{ animationDelay: `${i * 0.1}s` }}
          />
        ))}
      </div>
    </div>
  );
};

export default LoadingAnimation;
