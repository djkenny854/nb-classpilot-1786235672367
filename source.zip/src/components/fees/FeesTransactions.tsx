
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Search, Plus, FileText, Edit, Trash2, DollarSign, Download } from 'lucide-react';
import { format } from 'date-fns';
import { v4 as uuidv4 } from 'uuid';
import { PaymentRecord, Student } from '@/types';
import { loadStudentsFromDB, addPaymentToStudent, updatePaymentInStudent, deletePaymentFromStudent } from '@/utils/indexedDB';
import { toast } from '@/components/ui/use-toast';
import { Preloader } from '@/components/ui/preloader';

type PaymentDialogProps = {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payment: Partial<PaymentRecord>) => void;
  defaultValues?: Partial<PaymentRecord>;
  title: string;
  submitLabel: string;
};

const PaymentDialog = ({ 
  isOpen, 
  onClose, 
  onSubmit, 
  defaultValues = {}, 
  title, 
  submitLabel 
}: PaymentDialogProps) => {
  const [payment, setPayment] = useState<Partial<PaymentRecord>>({
    date: format(new Date(), 'yyyy-MM-dd'),
    amount: 0,
    method: 'Cash',
    receiptNo: '',
    notes: '',
    ...defaultValues
  });

  useEffect(() => {
    if (isOpen) {
      setPayment({
        date: format(new Date(), 'yyyy-MM-dd'),
        amount: 0,
        method: 'Cash',
        receiptNo: '',
        notes: '',
        ...defaultValues
      });
    }
  }, [isOpen, defaultValues]);

  const handleChange = (field: string, value: any) => {
    setPayment(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    if (!payment.amount || payment.amount <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid payment amount.',
        variant: 'destructive',
      });
      return;
    }

    if (!payment.date) {
      toast({
        title: 'Invalid Date',
        description: 'Please select a payment date.',
        variant: 'destructive',
      });
      return;
    }

    onSubmit(payment);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            Enter the payment details below.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="amount" className="text-right">
              Amount
            </Label>
            <div className="col-span-3 relative">
              <DollarSign className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                id="amount"
                type="number"
                className="pl-8"
                value={payment.amount || ''}
                onChange={(e) => handleChange('amount', parseFloat(e.target.value) || 0)}
              />
            </div>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="date" className="text-right">
              Date
            </Label>
            <Input
              id="date"
              type="date"
              className="col-span-3"
              value={payment.date}
              onChange={(e) => handleChange('date', e.target.value)}
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="method" className="text-right">
              Method
            </Label>
            <Select
              value={payment.method as string}
              onValueChange={(value) => handleChange('method', value)}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Cash">Cash</SelectItem>
                <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                <SelectItem value="Mobile Money">Mobile Money</SelectItem>
                <SelectItem value="Card">Credit/Debit Card</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="receipt" className="text-right">
              Receipt #
            </Label>
            <Input
              id="receipt"
              className="col-span-3"
              value={payment.receiptNo || ''}
              onChange={(e) => handleChange('receiptNo', e.target.value)}
              placeholder="RCPT-0000"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="notes" className="text-right">
              Notes
            </Label>
            <Textarea
              id="notes"
              className="col-span-3"
              value={payment.notes || ''}
              onChange={(e) => handleChange('notes', e.target.value)}
              placeholder="Additional information..."
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit}>{submitLabel}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

type StudentSelectorDialogProps = {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (student: Student) => void;
  students: Student[];
};

const StudentSelectorDialog = ({ isOpen, onClose, onSelect, students }: StudentSelectorDialogProps) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredStudents = students.filter(student => {
    const studentName = student.name || '';
    const enrollmentNumber = student.enrollmentNumber || '';
    const searchLower = searchQuery.toLowerCase();
    
    return studentName.toLowerCase().includes(searchLower) ||
           enrollmentNumber.toLowerCase().includes(searchLower);
  });

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Select Student</DialogTitle>
          <DialogDescription>
            Choose a student to record a payment for
          </DialogDescription>
        </DialogHeader>
        
        <div className="relative my-2">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name or enrollment number..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="max-h-[300px] overflow-y-auto border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Class</TableHead>
                <TableHead>Balance Due</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStudents.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-4">
                    No students found
                  </TableCell>
                </TableRow>
              ) : (
                filteredStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">
                      {student.name || 'No Name'}
                      <div className="text-xs text-muted-foreground">{student.enrollmentNumber || 'No Enrollment Number'}</div>
                    </TableCell>
                    <TableCell>{student.className || 'No Class'}</TableCell>
                    <TableCell>
                      <Badge variant={student.fees?.due > 0 ? "destructive" : "success"}>
                        ${student.fees?.due || 0}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button size="sm" onClick={() => onSelect(student)}>
                        Select
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const FeesTransactions = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [classFilter, setClassFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  
  // Dialog states
  const [isStudentSelectorOpen, setIsStudentSelectorOpen] = useState(false);
  const [isAddPaymentDialogOpen, setIsAddPaymentDialogOpen] = useState(false);
  const [isEditPaymentDialogOpen, setIsEditPaymentDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<PaymentRecord | null>(null);

  // Load students data
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        const loadedStudents = await loadStudentsFromDB();
        setStudents(loadedStudents);
      } catch (error) {
        console.error("Error loading students:", error);
        toast({
          title: 'Error',
          description: 'Failed to load student data.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, []);

  // Compile transactions from all students
  const allTransactions = React.useMemo(() => {
    const transactions: Array<{
      id: string;
      date: string;
      studentId: string;
      student: string;
      class: string;
      amount: number;
      method: string;
      receiptNo: string;
      notes?: string;
      paymentId: string;
    }> = [];

    students.forEach(student => {
      if (student.payments && student.payments.length > 0) {
        student.payments.forEach(payment => {
          transactions.push({
            id: `${student.id}-${payment.id}`,
            date: payment.date,
            studentId: student.id,
            student: student.name,
            class: student.className,
            amount: payment.amount,
            method: payment.method,
            receiptNo: payment.receiptNo || '-',
            notes: payment.notes,
            paymentId: payment.id,
          });
        });
      }
    });

    return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [students]);

  // Filter transactions
  const filteredTransactions = allTransactions.filter(transaction => {
    const matchesSearch = transaction.student.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          transaction.receiptNo.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesClass = classFilter === 'all' || transaction.class === classFilter;
    
    // Status filter could be based on date or other criteria
    const matchesStatus = statusFilter === 'all';
    
    return matchesSearch && matchesClass && matchesStatus;
  });

  // Unique class list for filtering
  const classes = React.useMemo(() => {
    const uniqueClasses = new Set<string>();
    students.forEach(student => uniqueClasses.add(student.className));
    return Array.from(uniqueClasses).sort();
  }, [students]);

  // Handle adding a new payment
  const handleAddPayment = async (paymentData: Partial<PaymentRecord>) => {
    if (!selectedStudent) {
      toast({
        title: 'Error',
        description: 'No student selected.',
        variant: 'destructive',
      });
      return;
    }

    const newPayment: PaymentRecord = {
      id: uuidv4(),
      date: paymentData.date || format(new Date(), 'yyyy-MM-dd'),
      amount: paymentData.amount || 0,
      method: paymentData.method as 'Cash' | 'Bank Transfer' | 'Mobile Money' | 'Card' | 'Other',
      receiptNo: paymentData.receiptNo || `RCPT-${Math.floor(Math.random() * 10000)}`,
      notes: paymentData.notes,
      createdAt: new Date().toISOString(),
      createdBy: 'admin', // This would ideally be the current user's ID
    };

    try {
      const updatedStudent = await addPaymentToStudent(selectedStudent.id, newPayment);
      if (updatedStudent) {
        // Update the students list with the updated student
        setStudents(prevStudents => 
          prevStudents.map(s => s.id === updatedStudent.id ? updatedStudent : s)
        );
      }
      setIsAddPaymentDialogOpen(false);
      setSelectedStudent(null);
    } catch (error) {
      console.error("Error adding payment:", error);
    }
  };

  // Handle editing a payment
  const handleEditPayment = async (paymentData: Partial<PaymentRecord>) => {
    if (!selectedStudent || !selectedPayment) {
      toast({
        title: 'Error',
        description: 'No payment selected for editing.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const updatedStudent = await updatePaymentInStudent(
        selectedStudent.id,
        selectedPayment.id,
        paymentData
      );
      
      if (updatedStudent) {
        // Update the students list with the updated student
        setStudents(prevStudents => 
          prevStudents.map(s => s.id === updatedStudent.id ? updatedStudent : s)
        );
      }
      
      setIsEditPaymentDialogOpen(false);
      setSelectedPayment(null);
      setSelectedStudent(null);
    } catch (error) {
      console.error("Error updating payment:", error);
    }
  };

  // Handle deleting a payment
  const handleDeletePayment = async () => {
    if (!selectedStudent || !selectedPayment) {
      toast({
        title: 'Error',
        description: 'No payment selected for deletion.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const updatedStudent = await deletePaymentFromStudent(
        selectedStudent.id,
        selectedPayment.id
      );
      
      if (updatedStudent) {
        // Update the students list with the updated student
        setStudents(prevStudents => 
          prevStudents.map(s => s.id === updatedStudent.id ? updatedStudent : s)
        );
      }
      
      setIsDeleteDialogOpen(false);
      setSelectedPayment(null);
      setSelectedStudent(null);
    } catch (error) {
      console.error("Error deleting payment:", error);
    }
  };

  // Open add payment dialog after selecting a student
  const handleStudentSelect = (student: Student) => {
    setSelectedStudent(student);
    setIsStudentSelectorOpen(false);
    setIsAddPaymentDialogOpen(true);
  };

  // Open edit payment dialog
  const handleEditClick = (transaction: any) => {
    const student = students.find(s => s.id === transaction.studentId);
    if (!student || !student.payments) return;
    
    const payment = student.payments.find(p => p.id === transaction.paymentId);
    if (!payment) return;
    
    setSelectedStudent(student);
    setSelectedPayment(payment);
    setIsEditPaymentDialogOpen(true);
  };

  // Open delete payment dialog
  const handleDeleteClick = (transaction: any) => {
    const student = students.find(s => s.id === transaction.studentId);
    if (!student || !student.payments) return;
    
    const payment = student.payments.find(p => p.id === transaction.paymentId);
    if (!payment) return;
    
    setSelectedStudent(student);
    setSelectedPayment(payment);
    setIsDeleteDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <Preloader text="Loading payment data..." />
        </div>
      ) : (
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <CardTitle>Payment Transactions</CardTitle>
                <CardDescription>
                  View and manage all fee payments made by students
                </CardDescription>
              </div>
              <Button onClick={() => setIsStudentSelectorOpen(true)}>
                <Plus className="mr-2 h-4 w-4" /> Add New Payment
              </Button>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 mt-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by student name or receipt number..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Payments</SelectItem>
                  <SelectItem value="recent">Recent (7 days)</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                </SelectContent>
              </Select>
              <Select value={classFilter} onValueChange={setClassFilter}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Filter by class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  {classes.map(cls => (
                    <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Student</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Receipt No.</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">
                        No transactions found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>{new Date(transaction.date).toLocaleDateString()}</TableCell>
                        <TableCell className="font-medium">{transaction.student}</TableCell>
                        <TableCell>{transaction.class}</TableCell>
                        <TableCell>${transaction.amount}</TableCell>
                        <TableCell>{transaction.method}</TableCell>
                        <TableCell>{transaction.receiptNo}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              title="View Receipt"
                              onClick={() => toast({
                                title: "Receipt",
                                description: "Receipt viewer not implemented yet",
                              })}
                            >
                              <FileText className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              title="Edit Payment"
                              onClick={() => handleEditClick(transaction)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              className="text-red-500"
                              title="Delete Payment"
                              onClick={() => handleDeleteClick(transaction)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="text-sm text-muted-foreground">
              Showing {filteredTransactions.length} of {allTransactions.length} transactions
            </div>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Transactions
            </Button>
          </CardFooter>
        </Card>
      )}

      {/* Student Selection Dialog */}
      <StudentSelectorDialog
        isOpen={isStudentSelectorOpen}
        onClose={() => setIsStudentSelectorOpen(false)}
        onSelect={handleStudentSelect}
        students={students}
      />

      {/* Add Payment Dialog */}
      <PaymentDialog
        isOpen={isAddPaymentDialogOpen}
        onClose={() => setIsAddPaymentDialogOpen(false)}
        onSubmit={handleAddPayment}
        title={`Add Payment for ${selectedStudent?.name || ''}`}
        submitLabel="Add Payment"
      />

      {/* Edit Payment Dialog */}
      <PaymentDialog
        isOpen={isEditPaymentDialogOpen}
        onClose={() => setIsEditPaymentDialogOpen(false)}
        onSubmit={handleEditPayment}
        defaultValues={selectedPayment || {}}
        title="Edit Payment"
        submitLabel="Update Payment"
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this payment record. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeletePayment} className="bg-red-600">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default FeesTransactions;
