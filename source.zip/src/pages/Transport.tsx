
import React, { useState } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Bus, Map, Users } from 'lucide-react';
import TransportRoutes from '@/components/transport/TransportRoutes';
import TransportVehicles from '@/components/transport/TransportVehicles';
import TransportDrivers from '@/components/transport/TransportDrivers';

const Transport = () => {
  const [activeTab, setActiveTab] = useState('routes');

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Transport Management</h1>
          <p className="text-muted-foreground mt-2">
            Manage school transportation routes, vehicles, and drivers.
          </p>
        </div>

        <Tabs defaultValue="routes" value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="routes">
              <Map className="mr-2 h-4 w-4" />
              Routes
            </TabsTrigger>
            <TabsTrigger value="vehicles">
              <Bus className="mr-2 h-4 w-4" />
              Vehicles
            </TabsTrigger>
            <TabsTrigger value="drivers">
              <Users className="mr-2 h-4 w-4" />
              Drivers
            </TabsTrigger>
          </TabsList>
          <TabsContent value="routes" className="mt-6">
            <TransportRoutes />
          </TabsContent>
          <TabsContent value="vehicles" className="mt-6">
            <TransportVehicles />
          </TabsContent>
          <TabsContent value="drivers" className="mt-6">
            <TransportDrivers />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default Transport;
