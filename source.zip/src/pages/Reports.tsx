
import React, { useState } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AcademicReports from '@/components/reports/AcademicReports';
import FinancialReports from '@/components/reports/FinancialReports';
import AttendanceReports from '@/components/reports/AttendanceReports';
import { FileText } from 'lucide-react';

const Reports = () => {
  const [activeTab, setActiveTab] = useState('academic');

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
            <p className="text-muted-foreground mt-2">
              Generate and view reports for various school activities.
            </p>
          </div>
        </div>

        <Tabs defaultValue="academic" value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="academic">Academic</TabsTrigger>
            <TabsTrigger value="attendance">Attendance</TabsTrigger>
            <TabsTrigger value="financial">Financial</TabsTrigger>
          </TabsList>
          <TabsContent value="academic" className="mt-6">
            <AcademicReports />
          </TabsContent>
          <TabsContent value="attendance" className="mt-6">
            <AttendanceReports />
          </TabsContent>
          <TabsContent value="financial" className="mt-6">
            <FinancialReports />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default Reports;
