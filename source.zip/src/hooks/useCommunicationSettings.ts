
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface CommunicationSettingsData {
  id?: string;
  email_provider: string;
  email_config: Record<string, any>;
  sms_provider: string;
  sms_config: Record<string, any>;
  notification_frequency: string;
  notification_categories: Record<string, any>;
}

export const useCommunicationSettings = () => {
  const [settings, setSettings] = useState<CommunicationSettingsData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('communication_preferences')
        .select('*')
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      setSettings(data ? {
        ...data,
        email_config: typeof data.email_config === 'object' ? data.email_config as Record<string, any> : {},
        sms_config: typeof data.sms_config === 'object' ? data.sms_config as Record<string, any> : {},
        notification_categories: typeof data.notification_categories === 'object' ? data.notification_categories as Record<string, any> : {}
      } : {
        email_provider: 'smtp',
        email_config: {},
        sms_provider: 'twilio',
        sms_config: {},
        notification_frequency: 'daily',
        notification_categories: {}
      });
    } catch (error) {
      console.error('Error fetching communication settings:', error);
      toast.error('Failed to load communication settings');
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (settingsData: Partial<CommunicationSettingsData>) => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('communication_preferences')
        .upsert(settingsData)
        .select()
        .single();

      if (error) throw error;

      setSettings({
        ...data,
        email_config: typeof data.email_config === 'object' ? data.email_config as Record<string, any> : {},
        sms_config: typeof data.sms_config === 'object' ? data.sms_config as Record<string, any> : {},
        notification_categories: typeof data.notification_categories === 'object' ? data.notification_categories as Record<string, any> : {}
      });
      toast.success('Communication settings updated successfully');
      return data;
    } catch (error) {
      console.error('Error updating communication settings:', error);
      toast.error('Failed to update communication settings');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  return {
    settings,
    loading,
    updateSettings,
    refetch: fetchSettings
  };
};
