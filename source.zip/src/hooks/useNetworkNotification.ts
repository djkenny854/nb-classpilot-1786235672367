
import { useEffect, useRef } from "react";
import { toast } from "sonner";

// Path to your notification sound
const SOUND_PATH = "/notification.mp3";

export function useNetworkNotification() {
  const prevOnline = useRef<boolean>(navigator.onLine);
  const soundRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    soundRef.current = new Audio(SOUND_PATH);

    const handleStatusChange = () => {
      const isOnline = navigator.onLine;

      if (prevOnline.current !== isOnline) {
        // Play sound (reset and play)
        if (soundRef.current) {
          soundRef.current.currentTime = 0;
          soundRef.current.play().catch(() => {});
        }

        // Show toast notification
        if (isOnline) {
          toast.success("Connection Restored", {
            description: "You are back online! Supabase backend available.",
            duration: 5000
          });
        } else {
          toast.error("No Connection", {
            description: "You are offline. Supabase backend unreachable.",
            duration: 7000
          });
        }
      }

      prevOnline.current = isOnline;
    };

    window.addEventListener("online", handleStatusChange);
    window.addEventListener("offline", handleStatusChange);

    return () => {
      window.removeEventListener("online", handleStatusChange);
      window.removeEventListener("offline", handleStatusChange);
    };
  }, []);
}
