
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface AttendanceSettingsData {
  id?: string;
  policy_type: 'strict' | 'flexible' | 'custom';
  late_threshold_minutes: number;
  absent_threshold_minutes: number;
  auto_mark_absent: boolean;
  require_reason: boolean;
  notification_settings: Record<string, any>;
}

export const useAttendanceSettings = () => {
  const [settings, setSettings] = useState<AttendanceSettingsData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('attendance_policies')
        .select('*')
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      setSettings(data ? {
        ...data,
        notification_settings: typeof data.notification_settings === 'object' ? data.notification_settings as Record<string, any> : {}
      } : {
        policy_type: 'flexible',
        late_threshold_minutes: 15,
        absent_threshold_minutes: 60,
        auto_mark_absent: true,
        require_reason: false,
        notification_settings: {}
      });
    } catch (error) {
      console.error('Error fetching attendance settings:', error);
      toast.error('Failed to load attendance settings');
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (settingsData: Partial<AttendanceSettingsData>) => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('attendance_policies')
        .upsert(settingsData)
        .select()
        .single();

      if (error) throw error;

      setSettings({
        ...data,
        notification_settings: typeof data.notification_settings === 'object' ? data.notification_settings as Record<string, any> : {}
      });
      toast.success('Attendance settings updated successfully');
      return data;
    } catch (error) {
      console.error('Error updating attendance settings:', error);
      toast.error('Failed to update attendance settings');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  return {
    settings,
    loading,
    updateSettings,
    refetch: fetchSettings
  };
};
