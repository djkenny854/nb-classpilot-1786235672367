
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface SecuritySettingsData {
  id?: string;
  auto_logout_minutes: number;
  password_policy: Record<string, any>;
  two_factor_enabled: boolean;
  session_settings: Record<string, any>;
  audit_logging: boolean;
  log_retention_days: number;
}

export const useSecuritySettings = () => {
  const [settings, setSettings] = useState<SecuritySettingsData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('security_settings')
        .select('*')
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      setSettings(data ? {
        ...data,
        password_policy: typeof data.password_policy === 'object' ? data.password_policy as Record<string, any> : {
          min_length: 8,
          require_uppercase: true,
          require_numbers: true
        },
        session_settings: typeof data.session_settings === 'object' ? data.session_settings as Record<string, any> : {}
      } : {
        auto_logout_minutes: 30,
        password_policy: {
          min_length: 8,
          require_uppercase: true,
          require_numbers: true
        },
        two_factor_enabled: false,
        session_settings: {},
        audit_logging: true,
        log_retention_days: 90
      });
    } catch (error) {
      console.error('Error fetching security settings:', error);
      toast.error('Failed to load security settings');
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (settingsData: Partial<SecuritySettingsData>) => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('security_settings')
        .upsert(settingsData)
        .select()
        .single();

      if (error) throw error;

      setSettings({
        ...data,
        password_policy: typeof data.password_policy === 'object' ? data.password_policy as Record<string, any> : {
          min_length: 8,
          require_uppercase: true,
          require_numbers: true
        },
        session_settings: typeof data.session_settings === 'object' ? data.session_settings as Record<string, any> : {}
      });
      toast.success('Security settings updated successfully');
      return data;
    } catch (error) {
      console.error('Error updating security settings:', error);
      toast.error('Failed to update security settings');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  return {
    settings,
    loading,
    updateSettings,
    refetch: fetchSettings
  };
};
