
import React, { createContext, useContext, useState, useEffect } from 'react';
import { SiteSettings, defaultSettings } from '@/types/settings';

interface SiteSettingsContextType {
  isSidebarOpen: boolean;
  sidebarMode: 'normal' | 'hover';
  isRightSidebarOpen: boolean;
  isGeminiPanelOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  toggleRightSidebar: () => void;
  toggleGeminiPanel: () => void;
  setSidebarMode: (mode: 'normal' | 'hover') => void;
  settings: SiteSettings;
  updateSettings: (newSettings: SiteSettings) => Promise<void>;
  loading: boolean;
}

const SiteSettingsContext = createContext<SiteSettingsContextType | undefined>(undefined);

export const useSiteSettings = () => {
  const context = useContext(SiteSettingsContext);
  if (!context) {
    throw new Error('useSiteSettings must be used within a SiteSettingsProvider');
  }
  return context;
};

export const SiteSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [sidebarMode, setSidebarModeState] = useState<'normal' | 'hover'>('normal');
  const [isRightSidebarOpen, setIsRightSidebarOpen] = useState(false);
  const [isGeminiPanelOpen, setIsGeminiPanelOpen] = useState(false);
  const [settings, setSettings] = useState<SiteSettings>(defaultSettings);
  const [loading, setLoading] = useState(false);

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSidebarOpen = localStorage.getItem('sidebar-open');
    const savedSidebarMode = localStorage.getItem('sidebar-mode') as 'normal' | 'hover';
    const savedRightSidebarOpen = localStorage.getItem('right-sidebar-open');
    const savedGeminiPanelOpen = localStorage.getItem('gemini-panel-open');
    const savedSettings = localStorage.getItem('site-settings');
    
    if (savedSidebarOpen !== null) {
      setIsSidebarOpen(JSON.parse(savedSidebarOpen));
    }
    
    if (savedSidebarMode) {
      setSidebarModeState(savedSidebarMode);
    }

    if (savedRightSidebarOpen !== null) {
      setIsRightSidebarOpen(JSON.parse(savedRightSidebarOpen));
    }

    if (savedGeminiPanelOpen !== null) {
      setIsGeminiPanelOpen(JSON.parse(savedGeminiPanelOpen));
    }

    if (savedSettings) {
      try {
        const parsedSettings = JSON.parse(savedSettings);
        setSettings({ ...defaultSettings, ...parsedSettings });
      } catch (error) {
        console.error('Error parsing saved settings:', error);
        setSettings(defaultSettings);
      }
    }
  }, []);

  // Save settings to localStorage when they change
  useEffect(() => {
    localStorage.setItem('sidebar-open', JSON.stringify(isSidebarOpen));
  }, [isSidebarOpen]);

  useEffect(() => {
    localStorage.setItem('sidebar-mode', sidebarMode);
  }, [sidebarMode]);

  useEffect(() => {
    localStorage.setItem('right-sidebar-open', JSON.stringify(isRightSidebarOpen));
  }, [isRightSidebarOpen]);

  useEffect(() => {
    localStorage.setItem('gemini-panel-open', JSON.stringify(isGeminiPanelOpen));
  }, [isGeminiPanelOpen]);

  useEffect(() => {
    localStorage.setItem('site-settings', JSON.stringify(settings));
  }, [settings]);

  const toggleSidebar = () => {
    setIsSidebarOpen(prev => !prev);
  };

  const toggleRightSidebar = () => {
    setIsRightSidebarOpen(prev => !prev);
  };

  const toggleGeminiPanel = () => {
    setIsGeminiPanelOpen(prev => !prev);
  };

  const setSidebarMode = (mode: 'normal' | 'hover') => {
    setSidebarModeState(mode);
    // If switching to hover mode, close the sidebar
    if (mode === 'hover') {
      setIsSidebarOpen(false);
    }
  };

  const updateSettings = async (newSettings: SiteSettings) => {
    setLoading(true);
    try {
      // Simulate async operation
      await new Promise(resolve => setTimeout(resolve, 500));
      setSettings(newSettings);
    } catch (error) {
      console.error('Error updating settings:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return (
    <SiteSettingsContext.Provider
      value={{
        isSidebarOpen,
        sidebarMode,
        isRightSidebarOpen,
        isGeminiPanelOpen,
        toggleSidebar,
        setSidebarOpen: setIsSidebarOpen,
        toggleRightSidebar,
        toggleGeminiPanel,
        setSidebarMode,
        settings,
        updateSettings,
        loading,
      }}
    >
      {children}
    </SiteSettingsContext.Provider>
  );
};
