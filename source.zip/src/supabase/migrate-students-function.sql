
-- Create a function to update student class in bulk
CREATE OR REPLACE FUNCTION migrate_students(
  student_ids UUID[],
  target_class_id TEXT,
  target_class_name TEXT
)
RETURNS TABLE(
  student_id UUID,
  success BOOLEAN,
  message TEXT
) LANGUAGE plpgsql
AS $$
DECLARE
  student_id UUID;
  student_record RECORD;
BEGIN
  -- Loop through each student ID
  FOREACH student_id IN ARRAY student_ids LOOP
    BEGIN
      -- Check if student exists
      SELECT * INTO student_record FROM students WHERE id = student_id;
      
      IF student_record IS NULL THEN
        -- Student not found
        student_id, FALSE, 'Student not found'
        INTO student_id, success, message;
        RETURN NEXT;
      ELSE
        -- Update the student's class
        UPDATE students 
        SET class_id = target_class_id, 
            class_name = target_class_name,
            updated_at = NOW()
        WHERE id = student_id;
        
        -- Return success
        student_id, TRUE, 'Updated successfully'
        INTO student_id, success, message;
        RETURN NEXT;
      END IF;
      
    EXCEPTION WHEN OTHERS THEN
      -- Handle any errors
      student_id, FALSE, 'Error: ' || SQLERRM
      INTO student_id, success, message;
      RETURN NEXT;
    END;
  END LOOP;
  
  RETURN;
END;
$$;

-- Example usage:
-- SELECT * FROM migrate_students(
--   ARRAY['123e4567-e89b-12d3-a456-426614174000'::UUID, '223e4567-e89b-12d3-a456-426614174000'::UUID],
--   'new-class-id',
--   'New Class Name'
-- );
