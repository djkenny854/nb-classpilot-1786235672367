
// Utility types for student bulk actions
export interface BulkActionStudent {
  id: string;
  full_name: string;
  class: string;
}

// Helper function to transform Student to BulkActionStudent
export const transformToBulkActionStudent = (students: import('@/types').Student[]): BulkActionStudent[] => {
  return students.map(student => ({
    id: student.id,
    full_name: student.name,
    class: student.className
  }));
};
