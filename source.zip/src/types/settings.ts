
export interface SiteSettings {
  classLabelFormat: 'Grade' | 'Class' | 'Year';
  currency: string;
  dateFormat: 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD';
  theme: 'light' | 'dark' | 'system';
  schoolName: string;
}

export const defaultSettings: SiteSettings = {
  classLabelFormat: 'Class',
  currency: 'UGX',
  dateFormat: 'MM/DD/YYYY',
  theme: 'system',
  schoolName: 'School Name'
};
